"""
ملف تشغيل خادم بايثون على استضافة هوستنجر (Hostinger Passenger WSGI).
"""
import os
import sys

# تحديد المسار الحالي للمشروع
APP_PATH = os.path.dirname(os.path.abspath(__file__))
if APP_PATH not in sys.path:
    sys.path.insert(0, APP_PATH)

# تعيين إعدادات جانغو
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mudarris.settings")

# تشغيل تطبيق WSGI
from django.core.wsgi import get_wsgi_application

application = get_wsgi_application()
