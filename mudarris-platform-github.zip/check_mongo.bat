@echo off
chcp 65001 >nul
cd /d "%~dp0"
title فحص MongoDB

echo ============================================
echo   فحص حالة MongoDB على الجهاز
echo ============================================
echo.

echo [1] خدمة MongoDB في ويندوز:
sc query MongoDB 2>nul | find "STATE"
if errorlevel 1 (
  echo     [!] الخدمة مش متسجّلة — يعني MongoDB غالباً مش متثبّت
  echo         أو متثبّت من غير خيار "Install as a Service".
)
echo.

echo [2] المنفذ 27017:
netstat -ano | find "27017" | find "LISTENING"
if errorlevel 1 (
  echo     [!] مفيش حاجة بتسمع على المنفذ 27017.
) else (
  echo     [OK] فيه سيرفر شغّال على المنفذ.
)
echo.

echo [3] اختبار اتصال فعلي من المشروع:
if not exist ".venv" (
  echo     [!] البيئة الافتراضية مش موجودة — شغّل run.bat الأول.
  goto :end
)
call .venv\Scripts\activate.bat
python -c "from pymongo import MongoClient; import os; uri=os.environ.get('MONGODB_URI','mongodb://localhost:27017'); c=MongoClient(uri, serverSelectionTimeoutMS=3000); print('     [OK] الاتصال ناجح — إصدار MongoDB:', c.server_info()['version']); print('     قواعد البيانات الموجودة:', ', '.join(c.list_database_names()))" 2>nul
if errorlevel 1 echo     [!] فشل الاتصال — MongoDB مش شغّال.
echo.

echo [4] المشروع هيستخدم إيه:
python -c "import os,django; os.environ.setdefault('DJANGO_SETTINGS_MODULE','mudarris.settings'); django.setup(); from django.conf import settings; print('     ->', 'MongoDB (' + settings.MONGODB_NAME + ')' if settings.USE_MONGODB else '-> SQLite (ملف db.sqlite3)')" 2>nul

:end
echo.
echo ============================================
echo  لو MongoDB مش متثبّت:
echo  https://www.mongodb.com/try/download/community
echo  اختار: Windows / msi  +  فعّل "Install MongoDB as a Service"
echo ============================================
pause
