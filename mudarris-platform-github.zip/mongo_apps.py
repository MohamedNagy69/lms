"""
تعريفات التطبيقات الجاهزة في Django لكن بمفتاح ObjectId بتاع MongoDB.

بتُستخدم تلقائياً لما المشروع يشتغل على MongoDB (شوف mudarris/settings.py).
"""

from django.contrib.admin.apps import AdminConfig
from django.contrib.auth.apps import AuthConfig
from django.contrib.contenttypes.apps import ContentTypesConfig
from django.contrib.messages.apps import MessagesConfig
from django.contrib.sessions.apps import SessionsConfig
from django.contrib.staticfiles.apps import StaticFilesConfig

OBJECT_ID = "django_mongodb_backend.fields.ObjectIdAutoField"


class MongoAdminConfig(AdminConfig):
    default_auto_field = OBJECT_ID


class MongoAuthConfig(AuthConfig):
    default_auto_field = OBJECT_ID


class MongoContentTypesConfig(ContentTypesConfig):
    default_auto_field = OBJECT_ID


class MongoSessionsConfig(SessionsConfig):
    default_auto_field = OBJECT_ID


class MongoMessagesConfig(MessagesConfig):
    default_auto_field = OBJECT_ID


class MongoStaticFilesConfig(StaticFilesConfig):
    default_auto_field = OBJECT_ID
