@echo off
chcp 65001 >nul
cd /d "%~dp0"
call .venv\Scripts\activate.bat
echo إعادة تعبئة البيانات التجريبية...
python manage.py seed_demo
echo ok> .seeded
echo تم.
pause
