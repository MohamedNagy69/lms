"""فحص سريع لكل صفحات الموقع (للتطوير فقط): python manage.py shell < smoke_test.py"""
import django
from django.test import Client

from academy.models import Course, Enrollment, Exam, ExamAttempt, Lecture, Lesson, Question, User

fails = []


def check(label, response, expected=(200,)):
    code = response.status_code
    ok = code in expected
    if not ok:
        fails.append((label, code, getattr(response, "url", "")))
    print(("✅" if ok else "❌"), label, code, getattr(response, "url", ""))


anon = Client()
course = Course.objects.first()
lecture = Lecture.objects.first()
lesson = Lesson.objects.first()
exam = Exam.objects.first()

check("home", anon.get("/"))
check("courses", anon.get("/courses/"))
check("courses filter", anon.get("/courses/?grade=grade-1&q=فيزياء"))
check("login page", anon.get("/login/"))
check("register page", anon.get("/register/"))
check("course detail (anon)", anon.get(f"/course/{course.slug}/"))
check("dashboard (anon → redirect)", anon.get("/dashboard/"), (302,))
check("contact post", anon.post("/contact/", {"name": "تجربة", "phone": "0100", "message": "مرحبا"}), (302,))

# تسجيل حساب جديد
User.objects.filter(username="smoketest").delete()
new = Client()
check("register post", new.post("/register/", {
    "first_name": "طالب", "last_name": "تجريبي", "username": "smoketest",
    "phone": "01234509876", "parent_phone": "01234509877", "city": "طنطا",
    "grade": str(Course.objects.first().grade_id),
    "password1": "Test@12345", "password2": "Test@12345",
}), (302,))

# طالب
enrollment = Enrollment.objects.filter(status="active").select_related("course", "student").first()
student = enrollment.student
sc = Client()
sc.force_login(student)
check("student dashboard", sc.get("/dashboard/"))
check("student profile", sc.get("/profile/"))
check("password change page", sc.get("/profile/password/"))
check("student exams", sc.get("/exams/"))
check("student results", sc.get("/results/"))
enrolled_course = enrollment.course
check("course detail (student)", sc.get(f"/course/{enrolled_course.slug}/"))
first_lesson = Lesson.objects.filter(lecture__course=enrolled_course).first()
if first_lesson:
    check("lesson detail", sc.get(f"/course/{enrolled_course.slug}/lesson/{first_lesson.pk}/"))
    check("toggle lesson", sc.post(f"/lesson/{first_lesson.pk}/done/"), (302,))
    check("toggle lesson back", sc.post(f"/lesson/{first_lesson.pk}/done/"), (302,))
    check("unauthorized stream", anon.get(f"/lesson/{first_lesson.pk}/stream/"), (302,))

# اشتراك في كورس مجاني
free = Course.objects.filter(is_free=True).exclude(pk=enrolled_course.pk).first()
if free:
    check("enroll free", sc.get(f"/course/{free.slug}/enroll/"), (302,))
paid = Course.objects.filter(is_free=False).exclude(enrollments__student=student, enrollments__status="active").first()
if not paid:
    paid = Course.objects.filter(is_free=False).first()
    Enrollment.objects.filter(student=student, course=paid).delete()
if paid:
    check("enroll paid page", sc.get(f"/course/{paid.slug}/enroll/"))
    check("enroll bad code", sc.post(f"/course/{paid.slug}/enroll/", {"code": "WRONG"}))
    from academy.models import AccessCode
    code = AccessCode.objects.filter(is_used=False, course=paid).first() or AccessCode.objects.create(
        code=AccessCode.generate_code(), course=paid)
    check("enroll good code", sc.post(f"/course/{paid.slug}/enroll/", {"code": code.code}), (302,))

# امتحان كامل
exam = Exam.objects.filter(course__in=[enrolled_course]).first() or Exam.objects.first()
Enrollment.objects.update_or_create(student=student, course=exam.course, defaults={"status": "active"})
resp = sc.get(f"/exam/{exam.pk}/start/")
check("exam start", resp, (302,))
attempt_url = resp.url
check("exam take", sc.get(attempt_url))
attempt = ExamAttempt.objects.filter(student=student, exam=exam).order_by("-started_at").first()
payload = {}
for question in exam.questions.all():
    correct = question.choices.filter(is_correct=True).first()
    payload[f"q_{question.pk}"] = str(correct.pk)
resp = sc.post(f"/attempt/{attempt.pk}/submit/", payload)
check("exam submit", resp, (302,))
attempt.refresh_from_db()
print("   النتيجة:", attempt.score, "/", attempt.max_score, "=", attempt.percent, "%")
assert attempt.percent == 100, "التصحيح غلط!"
check("exam result", sc.get(f"/attempt/{attempt.pk}/result/"))

# المدرس
teacher = User.objects.filter(role="teacher").first()
tc = Client()
tc.force_login(teacher)
for label, url in [
    ("teacher dashboard", "/teacher/"),
    ("teacher courses", "/teacher/courses/"),
    ("teacher course new", "/teacher/courses/new/"),
    ("teacher exams", "/teacher/exams/"),
    ("teacher exam new", "/teacher/exams/new/"),
    ("teacher students", "/teacher/students/"),
    ("teacher students search", "/teacher/students/?q=محمود"),
    ("teacher codes", "/teacher/codes/"),
    ("teacher announcements", "/teacher/announcements/"),
    ("teacher inbox", "/teacher/inbox/"),
    ("teacher grades", "/teacher/grades/"),
    ("admin", "/admin/"),
]:
    check(label, tc.get(url), (200, 302))

check("teacher course manage", tc.get(f"/teacher/courses/{course.pk}/"))
check("teacher course edit", tc.get(f"/teacher/courses/{course.pk}/edit/"))
check("teacher lecture new", tc.get(f"/teacher/courses/{course.pk}/lectures/new/"))
lecture = course.lectures.first()
if lecture:
    check("teacher lecture edit", tc.get(f"/teacher/courses/{course.pk}/lectures/{lecture.pk}/edit/"))
    check("teacher lesson new", tc.get(f"/teacher/lectures/{lecture.pk}/lessons/new/"))
    lesson = lecture.lessons.first()
    if lesson:
        check("teacher lesson edit", tc.get(f"/teacher/lectures/{lecture.pk}/lessons/{lesson.pk}/edit/"))
check("teacher exam manage", tc.get(f"/teacher/exams/{exam.pk}/"))
check("teacher question new", tc.get(f"/teacher/exams/{exam.pk}/questions/new/"))
question = exam.questions.first()
check("teacher question edit", tc.get(f"/teacher/exams/{exam.pk}/questions/{question.pk}/edit/"))
check("teacher student detail", tc.get(f"/teacher/students/{student.pk}/"))

# إنشاء كورس ومحاضرة ودرس وسؤال من لوحة المدرس
grade_id = str(course.grade_id)
resp = tc.post("/teacher/courses/new/", {
    "title": "كورس تجريبي من الاختبار", "grade": grade_id, "summary": "ملخص",
    "description": "وصف", "price": "100", "emoji": "🧪", "accent": "brand", "order": "9",
    "is_published": "on",
})
check("create course", resp, (302,))
new_course = Course.objects.filter(title="كورس تجريبي من الاختبار").first()
assert new_course, "الكورس متعملش!"

resp = tc.post(f"/teacher/courses/{new_course.pk}/lectures/new/", {
    "title": "محاضرة تجريبية", "description": "وصف المحاضرة", "order": "0",
})
check("create lecture", resp, (302,))
new_lecture = new_course.lectures.first()
assert new_lecture, "المحاضرة متعملتش!"

from django.core.files.uploadedfile import SimpleUploadedFile

resp = tc.post(f"/teacher/lectures/{new_lecture.pk}/lessons/new/", {
    "title": "درس يوتيوب", "description": "شرح", "video_source": "youtube",
    "youtube_id": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "duration_minutes": "12", "order": "0",
})
check("create lesson (youtube)", resp, (302,))

resp = tc.post(f"/teacher/lectures/{new_lecture.pk}/lessons/new/", {
    "title": "درس درايف", "description": "شرح", "video_source": "drive",
    "drive_url": "https://drive.google.com/file/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/view",
    "duration_minutes": "15", "order": "1",
})
check("create lesson (drive)", resp, (302,))

fake_video = SimpleUploadedFile("sample.mp4", b"\x00\x00\x00\x18ftypmp42", content_type="video/mp4")
resp = tc.post(f"/teacher/lectures/{new_lecture.pk}/lessons/new/", {
    "title": "درس ملف فيديو", "description": "شرح", "video_source": "file",
    "video_file": fake_video,
    "duration_minutes": "20", "order": "2",
})
check("create lesson (file upload)", resp, (302,))
assert new_lecture.lessons.count() == 3

resp = tc.post("/teacher/exams/new/", {
    "title": "امتحان تجريبي", "course": str(new_course.pk), "description": "تعليمات",
    "duration_minutes": "10", "pass_percent": "50", "is_published": "on", "allow_retake": "on",
})
check("create exam", resp, (302,))
new_exam = Exam.objects.filter(title="امتحان تجريبي").first()
data = {
    "text": "سؤال تجريبي؟", "points": "1", "order": "0", "explanation": "شرح",
    "choices-TOTAL_FORMS": "4", "choices-INITIAL_FORMS": "0", "choices-MIN_NUM_FORMS": "0",
    "choices-MAX_NUM_FORMS": "6",
}
for i in range(4):
    data[f"choices-{i}-text"] = f"اختيار {i + 1}"
    data[f"choices-{i}-order"] = str(i)
data["choices-0-is_correct"] = "on"
resp = tc.post(f"/teacher/exams/{new_exam.pk}/questions/new/", data)
check("create question", resp, (302,))
assert new_exam.questions.count() == 1, "السؤال متعملش"
assert new_exam.questions.first().choices.count() == 4, "الاختيارات متعملتش"

# توليد أكواد + إعلان
check("generate codes", tc.post("/teacher/codes/", {"count": "3", "course": ""}), (302,))
check("create announcement", tc.post("/teacher/announcements/", {
    "title": "إعلان تجريبي", "body": "نص", "grade": "", }), (302,))
Grade.objects.filter(name="صف تجريبي").delete()
check("add grade", tc.post("/teacher/grades/", {"name": "صف تجريبي", "order": "9", "is_active": "on"}), (302,))

# حذف
check("delete question", tc.get(f"/teacher/questions/{new_exam.questions.first().pk}/delete/"), (302,))
check("delete lesson confirm", tc.get(f"/teacher/lessons/{new_lecture.lessons.first().pk}/delete/"))
check("delete lesson", tc.post(f"/teacher/lessons/{new_lecture.lessons.first().pk}/delete/"), (302,))
check("delete lecture confirm", tc.get(f"/teacher/lectures/{new_lecture.pk}/delete/"))
check("delete lecture", tc.post(f"/teacher/lectures/{new_lecture.pk}/delete/"), (302,))
check("delete exam", tc.post(f"/teacher/exams/{new_exam.pk}/delete/"), (302,))
check("delete course", tc.post(f"/teacher/courses/{new_course.pk}/delete/"), (302,))

# منع الطالب من لوحة المدرس
check("student blocked from teacher", sc.get("/teacher/"), (403,))
check("logout", sc.get("/logout/"), (302,))

print("\n" + ("🎉 كل الاختبارات نجحت" if not fails else f"❌ فشل {len(fails)}: {fails}"))
