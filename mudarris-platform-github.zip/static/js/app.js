// ══════════════════════════════════════════════════════════════
// App JS — Dark Mode Only
// ══════════════════════════════════════════════════════════════
(function () {

  // قائمة الموبايل في لوحات التحكم

  document.querySelectorAll("[data-sidebar-toggle]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var sidebar = document.getElementById("app-sidebar");
      if (sidebar) sidebar.classList.toggle("hidden");
    });
  });

  // مؤقّت الامتحان
  var timer = document.getElementById("exam-timer");
  if (timer) {
    var left = parseInt(timer.dataset.seconds || "0", 10);
    var form = document.getElementById("exam-form");
    var tick = function () {
      var m = Math.floor(left / 60);
      var s = left % 60;
      timer.textContent = (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s;
      if (left <= 60) timer.classList.add("text-rose-600", "animate-pulse");
      if (left <= 0) {
        clearInterval(interval);
        if (form) form.submit();
        return;
      }
      left -= 1;
    };
    tick();
    var interval = setInterval(tick, 1000);
  }

  // عدّاد الأسئلة المُجابة
  var form = document.getElementById("exam-form");
  if (form) {
    var counter = document.getElementById("answered-count");
    var update = function () {
      if (!counter) return;
      var answered = new Set();
      form.querySelectorAll("input[type=radio]:checked").forEach(function (input) {
        answered.add(input.name);
      });
      counter.textContent = answered.size;
    };
    form.addEventListener("change", update);
    update();
  }

  // نسخ كود التفعيل
  document.querySelectorAll("[data-copy]").forEach(function (el) {
    el.addEventListener("click", function () {
      var value = el.dataset.copy;
      if (navigator.clipboard) navigator.clipboard.writeText(value);
      var old = el.textContent;
      el.textContent = "تم النسخ ✓";
      setTimeout(function () { el.textContent = old; }, 1200);
    });
  });

  // ------------------------------------------------------------------
  // 21st.dev UI Animations & Interactions
  // ------------------------------------------------------------------

  // 1. Spotlight Mouse Tracker
  var handleMouseMove = function (e) {
    var rect = this.getBoundingClientRect();
    var x = e.clientX - rect.left;
    var y = e.clientY - rect.top;
    this.style.setProperty("--mouse-x", x + "px");
    this.style.setProperty("--mouse-y", y + "px");
  };

  document.querySelectorAll(".spotlight-card, .card-hoverable").forEach(function (card) {
    card.addEventListener("mousemove", handleMouseMove);
  });

  // 2. Animated Number Counter on View
  var animateCounter = function (el) {
    var target = parseInt(el.dataset.counter || el.textContent.replace(/[^\d]/g, ""), 10);
    if (isNaN(target) || target === 0) return;
    var duration = 1500;
    var start = 0;
    var startTime = null;

    var step = function (timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      var easeOutQuad = 1 - (1 - progress) * (1 - progress);
      var current = Math.floor(easeOutQuad * target);
      el.textContent = current.toLocaleString("ar-EG");
      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        el.textContent = target.toLocaleString("ar-EG");
      }
    };
    window.requestAnimationFrame(step);
  };

  if ("IntersectionObserver" in window) {
    var counterObserver = new IntersectionObserver(function (entries, observer) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });

    document.querySelectorAll("[data-counter]").forEach(function (el) {
      counterObserver.observe(el);
    });

    // 3. Scroll Reveal Elements
    var revealObserver = new IntersectionObserver(function (entries, observer) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll(".reveal-item").forEach(function (el) {
      revealObserver.observe(el);
    });
  }

  // 4. Interactive Curriculum Filter Tabs
  document.querySelectorAll("[data-filter-btn]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var target = btn.dataset.filterBtn;
      document.querySelectorAll("[data-filter-btn]").forEach(function (b) {
        b.classList.remove("bg-brand-500", "text-white", "shadow-btn-3d");
        b.classList.add("bg-surface", "text-muted");
      });
      btn.classList.add("bg-brand-500", "text-white", "shadow-btn-3d");
      btn.classList.remove("bg-surface", "text-muted");

      document.querySelectorAll("[data-course-grade]").forEach(function (card) {
        if (target === "all" || card.dataset.courseGrade === target) {
          card.style.display = "";
          card.classList.add("is-visible");
        } else {
          card.style.display = "none";
        }
      });
    });
  });


  // 6. FAQ Accordion Toggle
  document.querySelectorAll("[data-faq-toggle]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var content = btn.nextElementSibling;
      var icon = btn.querySelector("span:last-child");
      if (!content) return;
      var isHidden = content.classList.contains("hidden");
      
      // Close other open faqs
      document.querySelectorAll("#faq-accordion > div").forEach(function (item) {
        var c = item.querySelector("div:last-child");
        var i = item.querySelector("button span:last-child");
        if (c && c !== content) c.classList.add("hidden");
        if (i && i !== icon) { i.textContent = "+"; i.style.transform = "rotate(0deg)"; }
      });

      if (isHidden) {
        content.classList.remove("hidden");
        if (icon) { icon.textContent = "−"; icon.style.transform = "rotate(180deg)"; }
      } else {
        content.classList.add("hidden");
        if (icon) { icon.textContent = "+"; icon.style.transform = "rotate(0deg)"; }
      }
    });
  });

  // ═══════════════ LIQUID METAL CANVAS ═══════════════
  // Animated mesh of points deformed by layered sine waves (Perlin-like).
  // Each cell is shaded with a chrome/silver gradient based on its normal vector,
  // creating the "liquid metal" effect from 21st.dev's component.
  (function () {
    var canvas = document.getElementById("liquid-metal-canvas");
    if (!canvas) return;
    var ctx = canvas.getContext("2d");

    var W, H, cols, rows, pts;
    var CELL = 52;          // grid cell size px
    var mx = 0, my = 0;     // mouse 0‒1
    var tmx = 0.5, tmy = 0.5;
    var t = 0;

    function resize() {
      W = canvas.width  = canvas.offsetWidth;
      H = canvas.height = canvas.offsetHeight;
      cols = Math.ceil(W / CELL) + 2;
      rows = Math.ceil(H / CELL) + 2;
      pts = [];
      for (var r = 0; r < rows; r++) {
        pts[r] = [];
        for (var c = 0; c < cols; c++) {
          pts[r][c] = { bx: (c - 0.5) * CELL, by: (r - 0.5) * CELL };
        }
      }
    }
    resize();
    window.addEventListener("resize", resize);

    window.addEventListener("mousemove", function (e) {
      var rect = canvas.getBoundingClientRect();
      tmx = (e.clientX - rect.left) / W;
      tmy = (e.clientY - rect.top)  / H;
    });

    // Smooth noise helper — layered sines
    function noise(x, y, t2) {
      return (
        Math.sin(x * 0.018 + t2 * 0.9)   * 18 +
        Math.sin(y * 0.022 - t2 * 0.7)   * 14 +
        Math.sin((x + y) * 0.012 + t2)   * 10 +
        Math.cos(x * 0.03  - y * 0.025 + t2 * 1.3) * 7
      );
    }

    // Deep Midnight Blue & Diamond White Glass Palette
    function chromeColor(z, alpha) {
      var n = (z + 49) / 98;   // 0‒1
      var r, g, b;
      if (n < 0.35) {
        var p = n / 0.35;
        r = Math.round(5  + p * 25);
        g = Math.round(8  + p * 60);
        b = Math.round(20 + p * 150);
      } else if (n < 0.70) {
        var p = (n - 0.35) / 0.35;
        r = Math.round(30  + p * 26);
        g = Math.round(68  + p * 121);
        b = Math.round(170 + p * 78);
      } else {
        var p = (n - 0.70) / 0.30;
        r = Math.round(56  + p * 199);
        g = Math.round(189 + p * 66);
        b = Math.round(248 + p * 7);
      }
      return "rgba(" + r + "," + g + "," + b + "," + alpha.toFixed(2) + ")";
    }

    function frame() {
      t += 0.008;
      mx += (tmx - mx) * 0.04;
      my += (tmy - my) * 0.04;

      ctx.clearRect(0, 0, W, H);

      // Build displaced point grid
      var z = [];
      for (var r = 0; r < rows; r++) {
        z[r] = [];
        for (var c = 0; c < cols; c++) {
          var p  = pts[r][c];
          var dx = (mx - 0.5) * 60;
          var dy = (my - 0.5) * 60;
          var zv = noise(p.bx + dx, p.by + dy, t);
          // mouse proximity ripple
          var mdx = p.bx / W - mx;
          var mdy = p.by / H - my;
          var md  = Math.sqrt(mdx * mdx + mdy * mdy);
          zv += Math.sin(md * 14 - t * 3) * 12 * Math.max(0, 1 - md * 2.5);
          z[r][c] = { x: p.bx, y: p.by + zv * 0.5, z: zv };
        }
      }

      // Draw triangles
      for (var r = 0; r < rows - 1; r++) {
        for (var c = 0; c < cols - 1; c++) {
          var p00 = z[r][c],   p10 = z[r][c+1];
          var p01 = z[r+1][c], p11 = z[r+1][c+1];

          // Upper triangle
          var avgZ1 = (p00.z + p10.z + p01.z) / 3;
          var alpha1 = 0.045 + Math.max(0, avgZ1 / 98) * 0.09;
          ctx.beginPath();
          ctx.moveTo(p00.x, p00.y);
          ctx.lineTo(p10.x, p10.y);
          ctx.lineTo(p01.x, p01.y);
          ctx.closePath();
          ctx.fillStyle = chromeColor(avgZ1, alpha1);
          ctx.fill();

          // Edge highlight
          ctx.strokeStyle = chromeColor(avgZ1 + 8, Math.min(0.18, alpha1 * 1.5));
          ctx.lineWidth = 0.5;
          ctx.stroke();

          // Lower triangle
          var avgZ2 = (p10.z + p11.z + p01.z) / 3;
          var alpha2 = 0.045 + Math.max(0, avgZ2 / 98) * 0.09;
          ctx.beginPath();
          ctx.moveTo(p10.x, p10.y);
          ctx.lineTo(p11.x, p11.y);
          ctx.lineTo(p01.x, p01.y);
          ctx.closePath();
          ctx.fillStyle = chromeColor(avgZ2, alpha2);
          ctx.fill();
          ctx.strokeStyle = chromeColor(avgZ2 + 8, Math.min(0.18, alpha2 * 1.5));
          ctx.stroke();
        }
      }

      // Specular highlight orbs — "hot spots" on liquid surface
      var spots = [
        { rx: 0.35 + Math.sin(t * 0.7) * 0.06, ry: 0.4 + Math.cos(t * 0.5) * 0.06, r: 110 },
        { rx: 0.65 + Math.cos(t * 0.6) * 0.05, ry: 0.55 + Math.sin(t * 0.8) * 0.05, r: 80 }
      ];
      spots.forEach(function (s) {
        var gx = s.rx * W, gy = s.ry * H;
        var grad = ctx.createRadialGradient(gx, gy, 0, gx, gy, s.r);
        grad.addColorStop(0,   "rgba(180,210,255,0.08)");
        grad.addColorStop(0.5, "rgba(100,160,255,0.04)");
        grad.addColorStop(1,   "rgba(0,0,0,0)");
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);
      });

      requestAnimationFrame(frame);
    }
    frame();
  })();

  // ═══════════════ END LIQUID METAL ═══════════════
})();
