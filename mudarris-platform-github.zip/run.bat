@echo off
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
title Mudarris - المنصة التعليمية

echo ============================================
echo   تشغيل المنصة التعليمية
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [خطأ] Python مش متثبت على الجهاز.
  echo حمّله من: https://www.python.org/downloads/  وفعّل خيار "Add to PATH"
  pause
  exit /b 1
)

if not exist ".venv" (
  echo [1/5] إنشاء البيئة الافتراضية...
  python -m venv .venv
)

call .venv\Scripts\activate.bat

echo [2/5] تثبيت المكتبات...
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet

echo [3/5] تجهيز قاعدة البيانات...
python manage.py migrate

if not exist ".seeded" (
  echo [4/5] إضافة البيانات التجريبية...
  python manage.py seed_demo
  echo ok> .seeded
) else (
  echo [4/5] البيانات موجودة بالفعل - تخطي.
)

echo [5/5] تشغيل السيرفر...
echo.
echo   افتح المتصفح على:  http://127.0.0.1:8000
echo   المدرس:  teacher / teacher123
echo   طالب:    student1 / student123
echo.
start "" http://127.0.0.1:8000
python manage.py runserver

pause
