"""لوحة تحكم المدرس: إدارة الكورسات والدروس والامتحانات والطلبة."""

import urllib.parse
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone

from ..forms import (
    AnnouncementForm,
    AttachmentForm,
    ChoiceFormSet,
    CodeGenerateForm,
    CourseForm,
    ExamForm,
    GradeForm,
    LectureForm,
    LessonForm,
    QuestionForm,
)
from ..models import (
    AccessCode,
    Announcement,
    Attachment,
    ContactMessage,
    Course,
    Enrollment,
    Exam,
    ExamAttempt,
    Grade,
    Lecture,
    Lesson,
    LessonProgress,
    Question,
    ParentReportView,
    StudentDevice,
    User,
)
from ..services.reports import format_arabic_date, get_student_weekly_data, get_week_bounds


def teacher_required(view):
    @wraps(view)
    @login_required
    def wrapper(request, *args, **kwargs):
        if not request.user.is_teacher:
            return render(request, "403.html", {"user": request.user}, status=403)
        return view(request, *args, **kwargs)

    return wrapper


# ---------------------------------------------------------------------------
# الرئيسية
# ---------------------------------------------------------------------------
@teacher_required
def dashboard(request):
    students = User.objects.filter(role=User.ROLE_STUDENT)
    courses = list(Course.objects.select_related("grade"))
    attempts = list(ExamAttempt.objects.filter(submitted_at__isnull=False).select_related("exam"))
    pending = (
        Enrollment.objects.filter(status=Enrollment.STATUS_PENDING)
        .select_related("student", "course")
        .order_by("-created_at")[:8]
    )

    avg = round(sum(a.percent for a in attempts) / len(attempts)) if attempts else 0
    week_ago = timezone.now() - timezone.timedelta(days=7)

    # عدد الطلبة في كل كورس (لرسم بياني بسيط)
    chart_rows = []
    for course in courses:
        count = Enrollment.objects.filter(course=course, status=Enrollment.STATUS_ACTIVE).count()
        chart_rows.append({"label": course.title, "value": count, "accent": course.accent})
    chart_rows.sort(key=lambda row: row["value"], reverse=True)
    chart_rows = chart_rows[:6]
    chart_max = max([row["value"] for row in chart_rows], default=0) or 1
    for row in chart_rows:
        row["width"] = round(row["value"] * 100 / chart_max)

    context = {
        "stats": {
            "students": students.count(),
            "new_students": students.filter(created_at__gte=week_ago).count(),
            "courses": len(courses),
            "lessons": Lesson.objects.count(),
            "exams": Exam.objects.count(),
            "attempts": len(attempts),
            "avg": avg,
            "views": LessonProgress.objects.count(),
            "unread": ContactMessage.objects.filter(is_read=False).count(),
            "pending": Enrollment.objects.filter(status=Enrollment.STATUS_PENDING).count(),
        },
        "chart_rows": chart_rows,
        "pending_enrollments": pending,
        "latest_students": students.order_by("-created_at")[:6],
        "latest_attempts": sorted(attempts, key=lambda a: a.submitted_at, reverse=True)[:6],
        "courses": courses,
    }
    return render(request, "teacher/dashboard.html", context)


# ---------------------------------------------------------------------------
# الكورسات والدروس
# ---------------------------------------------------------------------------
@teacher_required
def course_list(request):
    courses = Course.objects.select_related("grade")
    rows = [
        {
            "course": course,
            "lectures": course.lectures.count(),
            "lessons": Lesson.objects.filter(lecture__course=course).count(),
            "students": Enrollment.objects.filter(
                course=course, status=Enrollment.STATUS_ACTIVE
            ).count(),
        }
        for course in courses
    ]
    return render(request, "teacher/courses.html", {"rows": rows})


@teacher_required
def course_form(request, pk=None):
    course = get_object_or_404(Course, pk=pk) if pk else None
    form = CourseForm(request.POST or None, instance=course)
    if request.method == "POST" and form.is_valid():
        course = form.save()
        messages.success(request, "تم حفظ الكورس ✅")
        return redirect("academy:teacher_course_manage", pk=course.pk)
    return render(request, "teacher/course_form.html", {"form": form, "course": course})


@teacher_required
def course_manage(request, pk):
    course = get_object_or_404(Course.objects.select_related("grade"), pk=pk)

    # تحديث كود الكورس الموحد سريعاً
    if request.method == "POST" and "update_master_code" in request.POST:
        code = request.POST.get("master_access_code", "").strip()
        course.master_access_code = code
        course.save()
        if code:
            messages.success(request, f"تم تعيين كود الاشتراك الموحد للكورس: {code} ✅")
        else:
            messages.info(request, "تم إزالة كود الاشتراك الموحد للكورس.")
        return redirect("academy:teacher_course_manage", pk=course.pk)

    lectures = course.lectures.prefetch_related("lessons").all()
    context = {
        "course": course,
        "lectures": lectures,
        "exams": course.exams.all(),
        "students": Enrollment.objects.filter(course=course).select_related("student"),
    }
    return render(request, "teacher/course_manage.html", context)


@teacher_required
def course_delete(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == "POST":
        course.delete()
        messages.success(request, "تم حذف الكورس.")
        return redirect("academy:teacher_courses")
    return render(request, "teacher/confirm_delete.html", {"object": course, "kind": "الكورس"})


@teacher_required
def lecture_form(request, course_pk, pk=None):
    course = get_object_or_404(Course, pk=course_pk)
    lecture = get_object_or_404(Lecture, pk=pk, course=course) if pk else None
    form = LectureForm(request.POST or None, instance=lecture)
    if request.method == "POST" and form.is_valid():
        lecture = form.save(commit=False)
        lecture.course = course
        lecture.save()
        messages.success(request, "تم حفظ المحاضرة ✅")
        return redirect("academy:teacher_course_manage", pk=course.pk)
    return render(request, "teacher/lecture_form.html", {"form": form, "course": course, "lecture": lecture})


@teacher_required
def lecture_delete(request, pk):
    lecture = get_object_or_404(Lecture, pk=pk)
    course_pk = lecture.course_id
    if request.method == "POST":
        lecture.delete()
        messages.success(request, "تم حذف المحاضرة.")
        return redirect("academy:teacher_course_manage", pk=course_pk)
    return render(request, "teacher/confirm_delete.html", {"object": lecture, "kind": "المحاضرة"})


@teacher_required
def lesson_form(request, lecture_pk, pk=None):
    lecture = get_object_or_404(Lecture, pk=lecture_pk)
    course = lecture.course
    lesson = get_object_or_404(Lesson, pk=pk, lecture=lecture) if pk else None
    form = LessonForm(request.POST or None, request.FILES or None, instance=lesson)
    if request.method == "POST" and form.is_valid():
        lesson = form.save(commit=False)
        lesson.lecture = lecture
        lesson.save()

        action = request.POST.get("action", "save")
        if action == "save_and_add_exam":
            messages.success(request, f"تم حفظ الدرس بنجاح ✅ يمكنك الآن إنشاء كويز لدرس «{lesson.title}».")
            exam_url = reverse("academy:teacher_exam_new")
            query = urllib.parse.urlencode({
                "course": course.pk,
                "lesson": lesson.pk,
                "title": f"كويز: {lesson.title}",
            })
            return redirect(f"{exam_url}?{query}")

        messages.success(request, "تم حفظ الدرس ✅")
        return redirect("academy:teacher_course_manage", pk=course.pk)

    attachments = lesson.attachments.all() if lesson else []
    lesson_exams = lesson.exams.all() if lesson else []
    context = {
        "form": form,
        "course": course,
        "lecture": lecture,
        "lesson": lesson,
        "attachments": attachments,
        "lesson_exams": lesson_exams,
        "attachment_form": AttachmentForm(),
    }
    return render(request, "teacher/lesson_form.html", context)


@teacher_required
def lesson_delete(request, pk):
    lesson = get_object_or_404(Lesson, pk=pk)
    course_pk = lesson.lecture.course_id
    if request.method == "POST":
        lesson.delete()
        messages.success(request, "تم حذف الدرس.")
        return redirect("academy:teacher_course_manage", pk=course_pk)
    return render(request, "teacher/confirm_delete.html", {"object": lesson, "kind": "الدرس"})


@teacher_required
def attachment_add(request, lesson_pk):
    lesson = get_object_or_404(Lesson, pk=lesson_pk)
    form = AttachmentForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        attachment = form.save(commit=False)
        attachment.lesson = lesson
        attachment.save()
        messages.success(request, "تم إضافة المرفق.")
    else:
        messages.error(request, "تأكد من بيانات المرفق.")
    return redirect("academy:teacher_lesson_edit", lecture_pk=lesson.lecture_id, pk=lesson.pk)


@teacher_required
def attachment_delete(request, pk):
    attachment = get_object_or_404(Attachment, pk=pk)
    lesson = attachment.lesson
    attachment.delete()
    messages.success(request, "تم حذف المرفق.")
    return redirect("academy:teacher_lesson_edit", lecture_pk=lesson.lecture_id, pk=lesson.pk)


# ---------------------------------------------------------------------------
# الامتحانات
# ---------------------------------------------------------------------------
@teacher_required
def exam_list(request):
    exams = Exam.objects.select_related("course")
    rows = [
        {
            "exam": exam,
            "questions": exam.questions.count(),
            "attempts": exam.attempts.filter(submitted_at__isnull=False).count(),
        }
        for exam in exams
    ]
    return render(request, "teacher/exams.html", {"rows": rows})


@teacher_required
def exam_form(request, pk=None):
    exam = get_object_or_404(Exam, pk=pk) if pk else None
    initial = {}
    if not exam and request.method == "GET":
        course_id = request.GET.get("course") or request.GET.get("course_id")
        lesson_id = request.GET.get("lesson") or request.GET.get("lesson_id")
        title = request.GET.get("title")
        if course_id:
            try:
                initial["course"] = int(course_id)
            except ValueError:
                pass
        if lesson_id:
            try:
                initial["lesson"] = int(lesson_id)
            except ValueError:
                pass
        if title:
            initial["title"] = title

    form = ExamForm(request.POST or None, instance=exam, initial=initial)
    if request.method == "POST" and form.is_valid():
        exam = form.save()
        messages.success(request, "تم حفظ الامتحان ✅")
        return redirect("academy:teacher_exam_manage", pk=exam.pk)
    return render(request, "teacher/exam_form.html", {"form": form, "exam": exam})


@teacher_required
def exam_manage(request, pk):
    exam = get_object_or_404(Exam.objects.select_related("course"), pk=pk)
    questions = exam.questions.prefetch_related("choices")
    attempts = exam.attempts.filter(submitted_at__isnull=False).select_related("student")
    return render(
        request,
        "teacher/exam_manage.html",
        {"exam": exam, "questions": questions, "attempts": attempts},
    )


@teacher_required
def exam_results(request):
    """لوحة مركزية شاملة لجميع نتائج امتحانات الطلاب مع إرسال الواتساب المباشر للأب والأم."""
    attempts = (
        ExamAttempt.objects.filter(submitted_at__isnull=False)
        .select_related("student", "student__grade", "exam", "exam__course")
        .order_by("-submitted_at")
    )
    exam_id = request.GET.get("exam")
    if exam_id:
        attempts = attempts.filter(exam_id=exam_id)

    exams = Exam.objects.all().order_by("title")
    return render(
        request,
        "teacher/results.html",
        {
            "attempts": attempts,
            "exams": exams,
            "selected_exam": exam_id,
            "total_attempts": attempts.count(),
        },
    )


@teacher_required
def exam_toggle_retake(request, pk):
    exam = get_object_or_404(Exam, pk=pk)
    exam.allow_retake = not exam.allow_retake
    exam.save()
    if exam.allow_retake:
        messages.success(request, "تم تفعيل إمكانية إعادة الامتحان للطلاب ✅")
    else:
        messages.warning(request, "تم إلغاء إعادة الامتحان — متاح للمحاولة لمرة واحدة فقط 🔒")
    return redirect("academy:teacher_exam_manage", pk=exam.pk)


@teacher_required
def exam_toggle_feature(request, pk):
    """تبديل أي ميزة أمنية للامتحان أو ضبط حد الإنذارات فورياً عبر AJAX أو إعادة توجيه."""
    exam = get_object_or_404(Exam, pk=pk)
    feature = request.POST.get("feature") or request.GET.get("feature")

    # تعديل الحد الأقصى للإنذارات الأمنية
    if feature == "max_infractions":
        val = request.POST.get("value") or request.GET.get("value")
        if val is not None:
            try:
                val_int = max(1, min(50, int(val)))
                exam.max_infractions = val_int
                exam.save(update_fields=["max_infractions"])
                plural_word = "إنذار" if val_int <= 2 else ("إنذارات" if val_int <= 10 else "إنذاراً")
                msg = f"تم ضبط الحد الأقصى للإنذارات: {val_int} {plural_word} ✅"
                if request.headers.get("x-requested-with") == "XMLHttpRequest" or request.GET.get("format") == "json":
                    return JsonResponse({
                        "status": "success",
                        "feature": "max_infractions",
                        "value": val_int,
                        "message": msg,
                    })
                messages.success(request, msg)
            except (ValueError, TypeError):
                pass
        return redirect("academy:teacher_exam_manage", pk=exam.pk)

    allowed_features = {
        "require_webcam": "المراقبة الحية بالكاميرا",
        "ai_multi_person_detection": "رصد الأشخاص بالذكاء الاصطناعي",
        "ai_absence_and_camera_block": "رصد مغادرة الطالب وحجب الكاميرا",
        "require_fullscreen": "إلزام ملء الشاشة وقفل التبويب",
        "prevent_copy_paste": "منع النسخ والسيلكت وتصوير الشاشة",
        "prevent_multiple_screens": "منع الشاشات المتعددة (شاشة واحدة فقط)",
        "shuffle_questions": "الترتيب العشوائي للأسئلة",
        "allow_retake": "السماح بإعادة المحاولة",
        "auto_send_result": "إرسال النتيجة تلقائياً لأولياء الأمور",
    }

    if feature in allowed_features:
        current_val = getattr(exam, feature)
        new_val = not current_val
        setattr(exam, feature, new_val)
        updated_fields = [feature]
        if feature in ("ai_absence_and_camera_block", "ai_multi_person_detection") and new_val and not exam.require_webcam:
            exam.require_webcam = True
            updated_fields.append("require_webcam")
        exam.save(update_fields=updated_fields)

        label = allowed_features[feature]
        msg = f"تم تفعيل «{label}» بنجاح ✅" if new_val else f"تم تعطيل «{label}» 🔒"

        if request.headers.get("x-requested-with") == "XMLHttpRequest" or request.GET.get("format") == "json":
            return JsonResponse({
                "status": "success",
                "feature": feature,
                "is_active": new_val,
                "message": msg,
            })

        messages.success(request, msg)

    return redirect("academy:teacher_exam_manage", pk=exam.pk)


@teacher_required
def exam_delete(request, pk):
    exam = get_object_or_404(Exam, pk=pk)
    if request.method == "POST":
        exam.delete()
        messages.success(request, "تم حذف الامتحان.")
        return redirect("academy:teacher_exams")
    return render(request, "teacher/confirm_delete.html", {"object": exam, "kind": "الامتحان"})


@teacher_required
def question_form(request, exam_pk, pk=None):
    exam = get_object_or_404(Exam, pk=exam_pk)
    question = get_object_or_404(Question, pk=pk, exam=exam) if pk else None
    form = QuestionForm(request.POST or None, request.FILES or None, instance=question)
    formset = ChoiceFormSet(request.POST or None, instance=question)
    if request.method == "POST" and form.is_valid():
        question = form.save(commit=False)
        question.exam = exam
        question.save()
        if question.is_mcq:
            formset = ChoiceFormSet(request.POST, instance=question)
            if formset.is_valid():
                formset.save()
                messages.success(request, "تم حفظ السؤال وخياراته بنجاح ✅")
                return redirect("academy:teacher_exam_manage", pk=exam.pk)
        else:
            messages.success(request, "تم حفظ السؤال المقالي بنجاح ✅")
            return redirect("academy:teacher_exam_manage", pk=exam.pk)
    return render(
        request,
        "teacher/question_form.html",
        {"form": form, "formset": formset, "exam": exam, "question": question},
    )


@teacher_required
def question_delete(request, pk):
    question = get_object_or_404(Question, pk=pk)
    exam_pk = question.exam_id
    question.delete()
    messages.success(request, "تم حذف السؤال.")
    return redirect("academy:teacher_exam_manage", pk=exam_pk)


# ---------------------------------------------------------------------------
# الطلبة والاشتراكات
# ---------------------------------------------------------------------------
@teacher_required
def student_list(request):
    query = request.GET.get("q", "").strip()
    students = User.objects.filter(role=User.ROLE_STUDENT).select_related("grade")
    if query:
        students = students.filter(
            Q(username__icontains=query)
            | Q(first_name__icontains=query)
            | Q(last_name__icontains=query)
            | Q(phone__icontains=query)
        )
    rows = []
    for student in students.order_by("-created_at"):
        rows.append({
            "student": student,
            "courses": Enrollment.objects.filter(
                student=student, status=Enrollment.STATUS_ACTIVE
            ).count(),
            "exams": ExamAttempt.objects.filter(
                student=student, submitted_at__isnull=False
            ).count(),
        })
    return render(request, "teacher/students.html", {"rows": rows, "query": query})


@teacher_required
def student_detail(request, pk):
    student = get_object_or_404(User, pk=pk)
    enrollments = Enrollment.objects.filter(student=student).select_related("course")
    attempts = ExamAttempt.objects.filter(
        student=student, submitted_at__isnull=False
    ).select_related("exam")
    devices = student.devices.all().order_by("-last_login")
    recent_reset = request.session.pop("just_reset_password", None)
    new_password_info = None
    if recent_reset and str(recent_reset.get("student_pk")) == str(student.pk):
        new_password_info = recent_reset.get("password")

    return render(
        request,
        "teacher/student_detail.html",
        {
            "student_obj": student,
            "enrollments": enrollments,
            "attempts": attempts,
            "devices": devices,
            "active_devices_count": devices.filter(is_active=True).count(),
            "new_password_info": new_password_info,
        },
    )


@teacher_required
def reset_student_devices(request, pk):
    """تسجيل خروج الطالب من كافة الأجهزة وإعادة تعيين أجهزته المصرح بها."""
    student = get_object_or_404(User, pk=pk)
    if request.method == "POST":
        from django.contrib.sessions.models import Session
        for dev in student.devices.filter(is_active=True):
            if dev.session_key:
                try:
                    Session.objects.filter(session_key=dev.session_key).delete()
                except Exception:
                    pass
        student.devices.all().update(is_active=False, session_key="")
        messages.success(
            request,
            f"تم تسجيل خروج الطالب {student.display_name} من كافة الأجهزة وإعادة تعيين أجهزته بنجاح ✅",
        )
    return redirect("academy:teacher_student_detail", pk=student.pk)


@teacher_required
def teacher_reset_student_password(request, pk):
    """إعادة تعيين كلمة مرور الطالب من قبل المدرس مع حفظها وإتاحة إرسالها عبر الواتساب."""
    student = get_object_or_404(User, pk=pk, role=User.ROLE_STUDENT)
    if request.method == "POST":
        new_password = (request.POST.get("new_password") or "").strip()
        if len(new_password) < 4:
            messages.error(request, "يجب أن تكون كلمة المرور 4 أحرف أو أرقام على الأقل.")
            return redirect("academy:teacher_student_detail", pk=student.pk)

        student.set_password(new_password)
        student.save()

        request.session["just_reset_password"] = {
            "student_pk": student.pk,
            "password": new_password,
        }
        messages.success(
            request,
            f"تم تغيير كلمة مرور الطالب {student.display_name} بنجاح إلى: ({new_password}) ✅",
        )
    return redirect("academy:teacher_student_detail", pk=student.pk)



@teacher_required
def enrollment_action(request, pk, action):
    enrollment = get_object_or_404(Enrollment, pk=pk)
    if action == "activate":
        enrollment.status = Enrollment.STATUS_ACTIVE
        enrollment.save()
        messages.success(request, "تم تفعيل الاشتراك.")
    elif action == "remove":
        enrollment.delete()
        messages.info(request, "تم إلغاء الاشتراك.")
    return redirect(request.META.get("HTTP_REFERER", "academy:teacher_dashboard"))


@teacher_required
def enrollment_add(request, course_pk):
    course = get_object_or_404(Course, pk=course_pk)
    student_id = request.POST.get("student")
    student = User.objects.filter(pk=student_id).first()
    if student:
        Enrollment.objects.update_or_create(
            student=student, course=course,
            defaults={"status": Enrollment.STATUS_ACTIVE},
        )
        messages.success(request, f"تم اشتراك {student.display_name} في الكورس.")
    return redirect("academy:teacher_course_manage", pk=course.pk)


# ---------------------------------------------------------------------------
# أكواد التفعيل والإعلانات والرسائل
# ---------------------------------------------------------------------------
@teacher_required
def codes(request):
    # 1. تحديث كود الكورس الموحد من صفحة الأكواد
    if request.method == "POST" and "update_master_code" in request.POST:
        course_id = request.POST.get("course_id")
        course = get_object_or_404(Course, pk=course_id)
        master_code = request.POST.get("master_code", "").strip()
        course.master_access_code = master_code
        course.save()
        if master_code:
            messages.success(request, f"تم حفظ كود الكورس الموحد لـ «{course.title}»: {master_code} ✅")
        else:
            messages.info(request, f"تم إزالة كود الكورس الموحد لـ «{course.title}».")
        return redirect("academy:teacher_codes")

    form = CodeGenerateForm(request.POST or None)
    if request.method == "POST" and "generate_codes" in request.POST and form.is_valid():
        course = form.cleaned_data["course"]
        count = form.cleaned_data["count"]
        prefix = form.cleaned_data.get("prefix") or "PH"
        download_excel = form.cleaned_data.get("download_excel", False)

        existing_set = set()
        new_codes = [
            AccessCode(code=AccessCode.generate_code(prefix=prefix, existing_set=existing_set), course=course)
            for _ in range(count)
        ]
        created_objs = AccessCode.objects.bulk_create(new_codes)

        if download_excel:
            from ..services.excel import export_codes_to_excel
            course_label = course.title if course else "عام"
            filename = f"اكواد_{course_label}_{count}_كود.xlsx"
            return export_codes_to_excel(created_objs, filename=filename)

        messages.success(request, f"تم توليد {count} كود بنجاح ✅")
        return redirect("academy:teacher_codes")

    # تصفية الأكواد المعروضة
    course_filter = request.GET.get("course")
    status_filter = request.GET.get("status")

    codes_qs = AccessCode.objects.select_related("course", "used_by")
    if course_filter:
        codes_qs = codes_qs.filter(course_id=course_filter)
    if status_filter == "unused":
        codes_qs = codes_qs.filter(is_used=False)
    elif status_filter == "used":
        codes_qs = codes_qs.filter(is_used=True)

    courses = Course.objects.all().order_by("order", "title")

    return render(
        request,
        "teacher/codes.html",
        {
            "form": form,
            "codes": codes_qs[:500],
            "total_count": AccessCode.objects.count(),
            "unused": AccessCode.objects.filter(is_used=False).count(),
            "used_count": AccessCode.objects.filter(is_used=True).count(),
            "courses": courses,
            "current_course_id": course_filter,
            "current_status": status_filter,
        },
    )


@teacher_required
def codes_export(request):
    from ..services.excel import export_codes_to_excel
    codes_qs = AccessCode.objects.select_related("course", "used_by").all()
    course_id = request.GET.get("course")
    if course_id:
        codes_qs = codes_qs.filter(course_id=course_id)
    status = request.GET.get("status")
    if status == "unused":
        codes_qs = codes_qs.filter(is_used=False)
    elif status == "used":
        codes_qs = codes_qs.filter(is_used=True)

    course_label = "كل_الكورسات"
    if course_id:
        c = Course.objects.filter(pk=course_id).first()
        if c:
            course_label = c.title

    status_label = "المتاحة" if status == "unused" else ("المستخدمة" if status == "used" else "الكل")
    filename = f"اكواد_{course_label}_{status_label}_{codes_qs.count()}_كود.xlsx"
    return export_codes_to_excel(codes_qs, filename=filename)


@teacher_required
def announcements(request):
    form = AnnouncementForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "تم نشر الإعلان ✅")
        return redirect("academy:teacher_announcements")
    return render(
        request,
        "teacher/announcements.html",
        {"form": form, "announcements": Announcement.objects.all()},
    )


@teacher_required
def announcement_delete(request, pk):
    announcement = get_object_or_404(Announcement, pk=pk)
    announcement.delete()
    messages.info(request, "تم حذف الإعلان.")
    return redirect("academy:teacher_announcements")


@teacher_required
def inbox(request):
    ContactMessage.objects.filter(is_read=False).update(is_read=True)
    return render(request, "teacher/inbox.html", {"messages_list": ContactMessage.objects.all()})


@teacher_required
def grades(request):
    form = GradeForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "تم إضافة الصف ✅")
        return redirect("academy:teacher_grades")
    rows = [
        {
            "grade": grade,
            "courses": grade.courses.count(),
            "students": grade.students.count(),
        }
        for grade in Grade.objects.all()
    ]
    return render(request, "teacher/grades.html", {"form": form, "rows": rows})


@teacher_required
def security_logs(request):
    """سجل المخالفات الأمنية والطلاب المحظورين لتصوير الشاشة."""
    banned_students = User.objects.filter(is_security_banned=True).select_related("grade")
    locked_students = User.objects.filter(
        locked_until__gt=timezone.now(), is_security_banned=False
    ).select_related("grade")
    all_violators = User.objects.filter(screenshot_strikes__gt=0).select_related("grade").order_by("-screenshot_strikes")

    context = {
        "banned_students": banned_students,
        "locked_students": locked_students,
        "all_violators": all_violators,
    }
    return render(request, "teacher/security_logs.html", context)


@teacher_required
def unban_student(request, pk):
    """إلغاء حظر الطالب أمنياً وتصفير سجل المخالفات والقفل."""
    student = get_object_or_404(User, pk=pk)
    if request.method == "POST":
        student.is_security_banned = False
        student.banned_until = None
        student.locked_until = None
        student.screenshot_strikes = 0
        student.save(update_fields=["is_security_banned", "banned_until", "locked_until", "screenshot_strikes"])
        messages.success(request, f"تم إلغاء الحظر وتصفير سجل المخالفات للطالب {student.display_name} بنجاح ✅")
        return redirect("academy:teacher_security_logs")
    return render(request, "teacher/confirm_unban.html", {"student": student})


@teacher_required
def student_weekly_report(request, pk):
    """عرض تقرير المتابعة الأسبوعي للطالب مع كشف المحاضرات والامتحانات وإرسال الواتساب وحالة فتح ولي الأمر."""
    student_obj = get_object_or_404(User, pk=pk, role=User.ROLE_STUDENT)

    course_id = request.GET.get("course", "")
    try:
        week_offset = int(request.GET.get("offset", 0))
    except (ValueError, TypeError):
        week_offset = 0

    start_date = request.GET.get("start", "")
    end_date = request.GET.get("end", "")

    data = get_student_weekly_data(
        student=student_obj,
        course=course_id or None,
        week_offset=week_offset,
        start_date=start_date or None,
        end_date=end_date or None,
        request=request,
    )

    all_courses = Course.objects.all().order_by("title")

    context = {
        "student_obj": student_obj,
        "all_courses": all_courses,
        "prev_offset": week_offset - 1,
        "next_offset": week_offset + 1,
        **data,
    }
    return render(request, "teacher/student_report.html", context)


@teacher_required
def students_weekly_overview(request):
    """لوحة متابعة أسبوعية عامة لجميع الطلاب: كشف نسبة الإنجاز والامتحانات وحالة اطلاع أولياء الأمور."""
    try:
        week_offset = int(request.GET.get("offset", 0))
    except (ValueError, TypeError):
        week_offset = 0

    grade_id = request.GET.get("grade", "")
    course_id = request.GET.get("course", "")
    query = request.GET.get("q", "").strip()

    students_qs = (
        User.objects.filter(role=User.ROLE_STUDENT)
        .select_related("grade")
        .order_by("first_name", "last_name", "username")
    )
    if grade_id:
        students_qs = students_qs.filter(grade_id=grade_id)
    if query:
        students_qs = students_qs.filter(
            Q(first_name__icontains=query)
            | Q(last_name__icontains=query)
            | Q(username__icontains=query)
            | Q(phone__icontains=query)
            | Q(parent_phone__icontains=query)
        )

    all_courses = Course.objects.all().order_by("title")
    all_grades = Grade.objects.filter(is_active=True).order_by("order", "name")

    # جلب بيانات المتابعة لكل طالب
    students_data = []
    for std in students_qs:
        std_data = get_student_weekly_data(
            student=std,
            course=course_id or None,
            week_offset=week_offset,
            request=request,
        )
        students_data.append(std_data)

    week_start, week_end = get_week_bounds(offset=week_offset)

    context = {
        "students_data": students_data,
        "week_offset": week_offset,
        "prev_offset": week_offset - 1,
        "next_offset": week_offset + 1,
        "week_start": week_start,
        "week_end": week_end,
        "week_start_str": format_arabic_date(week_start),
        "week_end_str": format_arabic_date(week_end),
        "grades": all_grades,
        "courses": all_courses,
        "selected_grade": grade_id,
        "selected_course": course_id,
        "query": query,
    }
    return render(request, "teacher/reports_overview.html", context)
