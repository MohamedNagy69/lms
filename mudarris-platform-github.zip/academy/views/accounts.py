"""تسجيل الدخول والحساب الشخصي."""

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, PasswordChangeView
from django.shortcuts import redirect, render
from django.urls import reverse_lazy

from django.utils.decorators import method_decorator
from django.views.decorators.csrf import ensure_csrf_cookie

from ..forms import (
    LoginForm,
    ProfileForm,
    RegisterForm,
    StudentPasswordResetForm,
)


from django.contrib.sessions.models import Session
from ..models import StudentDevice
from ..services.device import handle_student_device_login, set_device_cookie


@method_decorator(ensure_csrf_cookie, name="dispatch")
class AcademyLoginView(LoginView):
    template_name = "account/login.html"
    form_class = LoginForm
    redirect_authenticated_user = True

    def form_valid(self, form):
        response = super().form_valid(form)
        user = self.request.user
        if not user.is_teacher:
            device, logged_out_others = handle_student_device_login(user, self.request)
            if logged_out_others:
                messages.info(
                    self.request,
                    "ℹ️ تم تسجيل الدخول بنجاح. تم تسجيل الخروج تلقائياً من الأجهزة السابقة لحماية أمان وخصوصية حسابك.",
                )
            set_device_cookie(response, device.device_id)
        return response

    def get_success_url(self):
        next_url = self.request.GET.get("next") or self.request.POST.get("next")
        if next_url and next_url.startswith("/"):
            return next_url
        if self.request.user.is_teacher:
            return reverse_lazy("academy:teacher_dashboard")
        return reverse_lazy("academy:dashboard")


def register(request):
    if request.user.is_authenticated:
        return redirect("academy:dashboard")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user, backend="academy.auth_backends.UsernameOrPhoneBackend")
        response = redirect("academy:dashboard")
        if not user.is_teacher:
            device, _ = handle_student_device_login(user, request)
            set_device_cookie(response, device.device_id)
        messages.success(request, f"أهلاً بيك يا {user.first_name} 🎉 حسابك اتفتح بنجاح.")
        return response
    return render(request, "account/register.html", {"form": form})


def logout_view(request):
    if request.user.is_authenticated and not request.user.is_teacher:
        device_id = request.COOKIES.get("mudarris_device_id")
        if device_id:
            StudentDevice.objects.filter(student=request.user, device_id=device_id).update(
                is_active=False, session_key=""
            )
    logout(request)
    messages.info(request, "تم تسجيل الخروج، في انتظارك مرة تانية.")
    next_url = request.GET.get("next") or request.POST.get("next")
    if next_url and next_url.startswith("/"):
        return redirect(next_url)
    return redirect("academy:home")


@login_required
def profile(request):
    form = ProfileForm(request.POST or None, instance=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "تم حفظ بياناتك.")
        return redirect("academy:profile")
    devices = request.user.devices.all().order_by("-last_login") if not request.user.is_teacher else []
    return render(
        request,
        "account/profile.html",
        {
            "form": form,
            "devices": devices,
            "current_device_id": request.COOKIES.get("mudarris_device_id"),
        },
    )


class AcademyPasswordChangeView(PasswordChangeView):
    template_name = "account/password_change.html"
    success_url = reverse_lazy("academy:profile")

    def form_valid(self, form):
        messages.success(self.request, "تم تغيير كلمة السر بنجاح.")
        return super().form_valid(form)

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        for field in form.fields.values():
            field.widget.attrs.setdefault("class", "form-control")
        return form


@ensure_csrf_cookie
def student_password_reset(request):

    """استعادة كلمة المرور للطالب عبر التحقق من رقم ولي الأمر."""
    if request.user.is_authenticated:
        return redirect("academy:dashboard")

    form = StudentPasswordResetForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.target_user
        new_pass = form.cleaned_data["new_password1"]
        user.set_password(new_pass)
        user.save()
        messages.success(
            request,
            f"تم تغيير كلمة المرور بنجاح لحساب ({user.username}) 🎉 يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة.",
        )
        return redirect("academy:login")

    site_info = getattr(settings, "SITE_INFO", {})
    support_whatsapp = site_info.get("whatsapp") or "201005209526"
    return render(
        request,
        "account/password_reset.html",
        {
            "form": form,
            "support_whatsapp": support_whatsapp,
        },
    )

