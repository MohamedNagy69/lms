"""الصفحات العامة اللي أي زائر يقدر يشوفها."""

from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render

from ..forms import ContactForm
from ..models import Announcement, Course, Grade, Lesson, ParentReportView, Testimonial, User
from ..services.reports import get_student_weekly_data


def home(request):
    courses = (
        Course.objects.filter(is_published=True)
        .select_related("grade")
        .order_by("order", "-created_at")[:6]
    )
    stats = {
        "students": User.objects.filter(role=User.ROLE_STUDENT).count(),
        "courses": Course.objects.filter(is_published=True).count(),
        "lessons": Lesson.objects.count(),
        "hours": round(sum(Lesson.objects.values_list("duration_minutes", flat=True)) / 60),
    }
    context = {
        "courses": courses,
        "grades": Grade.objects.filter(is_active=True),
        "testimonials": Testimonial.objects.filter(is_visible=True)[:6],
        "announcements": Announcement.objects.all()[:3],
        "stats": stats,
        "contact_form": ContactForm(),
    }
    return render(request, "pages/home.html", context)


def course_catalog(request):
    """كل الكورسات مع فلترة بالصف الدراسي."""
    grade_slug = request.GET.get("grade", "")
    query = request.GET.get("q", "").strip()
    courses = Course.objects.filter(is_published=True).select_related("grade")
    if grade_slug:
        courses = courses.filter(grade__slug=grade_slug)
    if query:
        courses = courses.filter(title__icontains=query)

    enrolled_ids = set()
    if request.user.is_authenticated:
        enrolled_ids = set(
            request.user.enrollments.filter(status="active").values_list("course_id", flat=True)
        )

    context = {
        "courses": courses,
        "grades": Grade.objects.filter(is_active=True),
        "active_grade": grade_slug,
        "query": query,
        "enrolled_ids": enrolled_ids,
    }
    return render(request, "pages/courses.html", context)


def contact(request):
    if request.method != "POST":
        return redirect("academy:home")
    form = ContactForm(request.POST)
    if form.is_valid():
        form.save()
        messages.success(request, "وصلتنا رسالتك، هنكلمك في أقرب وقت 👌")
    else:
        messages.error(request, "من فضلك راجع البيانات المكتوبة.")
    return redirect("/#contact")


def parent_report_view(request, token):
    """
    صفحة تقرير ولي الأمر العامة الآمنة (بدون تسجيل دخول).
    ترصد فتح الرابط من قبل ولي الأمر فوراً وتحدث توقيت وتاريخ أول وآخر مشاهدة وعدد مرات الفتح.
    """
    parent_report = get_object_or_404(ParentReportView, token=token)

    # رصد فتح الرابط وتحديث سجل المشاهدة لحظياً
    parent_report.mark_as_viewed()

    data = get_student_weekly_data(
        student=parent_report.student,
        course=parent_report.course,
        start_date=parent_report.week_start,
        end_date=parent_report.week_end,
        request=request,
    )

    context = {
        "parent_report": parent_report,
        "student_obj": parent_report.student,
        **data,
    }
    return render(request, "public/parent_report.html", context)
