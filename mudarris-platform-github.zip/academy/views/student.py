"""صفحات الطالب: لوحة التحكم، الدروس، الامتحانات."""

from datetime import timedelta
import os
import re
from urllib.parse import urlparse

from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.signing import BadSignature, SignatureExpired, TimestampSigner
from django.http import Http404, HttpResponseForbidden, JsonResponse, StreamingHttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone

from ..forms import ActivationCodeForm
from ..models import (
    Announcement,
    AttemptAnswer,
    Choice,
    Course,
    Enrollment,
    Exam,
    ExamAttempt,
    Lecture,
    Lesson,
    LessonProgress,
)

VIDEO_TOKEN_SALT = "academy.secure.video.stream.v3"
VIDEO_TOKEN_MAX_AGE = 3600  # صلاحية الرابط المشفر: ساعة لبث الفيديو داخل الجلسة

BLOCKED_DOWNLOAD_AGENTS = [
    "idman", "internet download manager", "fdm", "freedownloadmanager",
    "aria2", "curl", "wget", "python", "postman", "ffmpeg",
    "videodownloadhelper", "jdownloader", "yt-dlp", "youtube-dl", "eagleget",
    "downloader", "grabber", "teleport"
]


def generate_signed_video_token(request, user, lesson):
    """توليد توكن مشفر وموقع رقمياً مرتبط بجلسة الطالب وعنوان IP ومعرف الدرس ووقت الصلاحية."""
    if hasattr(request, "session") and not request.session.session_key:
        try:
            request.session.save()
        except Exception:
            pass
    signer = TimestampSigner(salt=VIDEO_TOKEN_SALT)
    user_id = str(user.pk) if (user and user.is_authenticated) else "guest"
    session_key = getattr(request.session, "session_key", "") or "sess"
    ip = request.META.get("REMOTE_ADDR", "")
    payload = f"{user_id}:{lesson.pk}:{session_key}:{ip}"
    return signer.sign(payload)


def verify_signed_video_token(token, request, user, lesson):
    """التحقق المشدد من صحة التوقيع الرقمي وصلاحية التوكن وهوية المستخدم المشترك والجلسة."""
    if not token:
        return False
    signer = TimestampSigner(salt=VIDEO_TOKEN_SALT)
    try:
        payload = signer.unsign(token, max_age=VIDEO_TOKEN_MAX_AGE)
        parts = payload.split(":")
        user_id = parts[0]
        lesson_id = parts[1]
        token_sess = parts[2] if len(parts) > 2 else ""

        expected_user_id = str(user.pk) if (user and user.is_authenticated) else "guest"
        if user_id != expected_user_id or str(lesson.pk) != str(lesson_id):
            return False

        # إذا تم تمرير الجلسة، نتحقق من تطابقها لمنع نسخ الرابط لجهاز آخر
        if token_sess and token_sess != "sess":
            current_sess = getattr(request.session, "session_key", "")
            if current_sess and current_sess != token_sess:
                return False

        return True
    except (BadSignature, SignatureExpired, ValueError):
        return False


# ---------------------------------------------------------------------------
# أدوات مساعدة
# ---------------------------------------------------------------------------
def get_enrollment(user, course):
    if not user.is_authenticated:
        return None
    return Enrollment.objects.filter(student=user, course=course).first()


def has_access(user, course):
    if not user.is_authenticated:
        return False
    if user.is_teacher:
        return True
    enrollment = get_enrollment(user, course)
    return bool(enrollment and enrollment.is_active)


def completed_lesson_ids(user, lesson_ids):
    if not user.is_authenticated or not lesson_ids:
        return set()
    return set(
        LessonProgress.objects.filter(
            student=user, lesson_id__in=list(lesson_ids), is_completed=True
        ).values_list("lesson_id", flat=True)
    )


def course_progress(user, course):
    lesson_ids = list(Lesson.objects.filter(lecture__course=course).values_list("id", flat=True))
    total = len(lesson_ids)
    done = len(completed_lesson_ids(user, lesson_ids))
    percent = round(done * 100 / total) if total else 0
    return {"total": total, "done": done, "percent": percent}


# ---------------------------------------------------------------------------
# لوحة الطالب
# ---------------------------------------------------------------------------
@login_required
def dashboard(request):
    if request.user.is_teacher:
        return redirect("academy:teacher_dashboard")

    enrollments = (
        Enrollment.objects.filter(student=request.user)
        .select_related("course", "course__grade")
        .order_by("-created_at")
    )
    active = [e for e in enrollments if e.is_active]
    cards = []
    for enrollment in active:
        cards.append({"enrollment": enrollment, "progress": course_progress(request.user, enrollment.course)})

    course_ids = [e.course_id for e in active]
    exams = Exam.objects.filter(course_id__in=course_ids, is_published=True).select_related("course")
    attempts = (
        ExamAttempt.objects.filter(student=request.user, submitted_at__isnull=False)
        .select_related("exam")
        .order_by("-submitted_at")[:5]
    )
    attempted_exam_ids = set(
        ExamAttempt.objects.filter(student=request.user, submitted_at__isnull=False)
        .values_list("exam_id", flat=True)
    )

    announcements = Announcement.objects.filter(grade__isnull=True)[:5]
    if request.user.grade_id:
        announcements = list(
            Announcement.objects.filter(grade_id=request.user.grade_id)[:5]
        ) + list(announcements)

    avg = 0
    submitted = [a for a in ExamAttempt.objects.filter(student=request.user, submitted_at__isnull=False)]
    if submitted:
        avg = round(sum(a.percent for a in submitted) / len(submitted))

    context = {
        "cards": cards,
        "pending": [e for e in enrollments if not e.is_active],
        "exams": [e for e in exams if e.pk not in attempted_exam_ids][:5],
        "attempts": attempts,
        "announcements": announcements[:5],
        "avg_score": avg,
        "stats": {
            "courses": len(active),
            "lessons_done": LessonProgress.objects.filter(student=request.user).count(),
            "exams_done": len(submitted),
            "avg": avg,
        },
    }
    return render(request, "student/dashboard.html", context)


def course_detail(request, slug):
    course = get_object_or_404(Course.objects.select_related("grade"), slug=slug)
    if not course.is_published and not (request.user.is_authenticated and request.user.is_teacher):
        messages.error(request, "الكورس ده مش متاح حالياً.")
        return redirect("academy:courses")

    lectures = list(course.lectures.prefetch_related("lessons").all())
    all_lessons = []
    for lec in lectures:
        all_lessons.extend(list(lec.lessons.all()))
    
    access = has_access(request.user, course)
    enrollment = get_enrollment(request.user, course)
    done_ids = completed_lesson_ids(request.user, [lesson.pk for lesson in all_lessons])

    context = {
        "course": course,
        "lectures": lectures,
        "all_lessons": all_lessons,
        "access": access,
        "enrollment": enrollment,
        "done_ids": done_ids,
        "progress": course_progress(request.user, course) if access else None,
        "exams": course.exams.filter(is_published=True) if access else [],
    }
    return render(request, "student/course_detail.html", context)


@login_required
def enroll(request, slug):
    course = get_object_or_404(Course, slug=slug)
    enrollment = get_enrollment(request.user, course)
    if enrollment and enrollment.is_active:
        return redirect(course.get_absolute_url())

    form = ActivationCodeForm(request.POST or None, course=course)
    if request.method == "POST":
        if form.is_valid():
            if getattr(form, "is_master_code", False):
                # 1. تفعيل بواسطة كود الكورس الموحد (يظل فعالاً ولا يستهلك)
                Enrollment.objects.update_or_create(
                    student=request.user, course=course,
                    defaults={"status": Enrollment.STATUS_ACTIVE},
                )
                messages.success(request, f"تم تفعيل اشتراكك في كورس «{course.title}» بنجاح بالكود الموحد ✅")
                return redirect(course.get_absolute_url())

            # 2. تفعيل بواسطة أحد أكواد التفعيل الفردية (كارت شحن يُستخدم لمرة واحدة)
            code = form.access_code
            code.is_used = True
            code.used_by = request.user
            code.used_at = timezone.now()
            code.save()
            Enrollment.objects.update_or_create(
                student=request.user, course=course,
                defaults={"status": Enrollment.STATUS_ACTIVE},
            )
            messages.success(request, f"تم تفعيل اشتراكك في كورس «{course.title}» بنجاح بكود التفعيل ✅")
            return redirect(course.get_absolute_url())

    return render(request, "student/enroll.html", {"course": course, "form": form, "enrollment": enrollment})


def lesson_detail(request, slug, pk):
    course = get_object_or_404(Course, slug=slug)
    lesson = get_object_or_404(Lesson.objects.select_related("lecture"), pk=pk, lecture__course=course)
    access = has_access(request.user, course)
    if not access:
        messages.warning(request, "لا يمكن الدخول على هذا الدرس إلا بعد تفعيل الكورس باستخدام كود التفعيل الموحد أو كود الشحن.")
        return redirect("academy:enroll", slug=course.slug)

    # تسجيل المشاهدة والتقدم تلقائياً للطالب
    if request.user.is_authenticated and not request.user.is_teacher and access:
        LessonProgress.objects.get_or_create(
            student=request.user,
            lesson=lesson,
            defaults={"is_completed": True, "completed_at": timezone.now()},
        )

    # Get all lessons across all lectures, ordered by lecture order then lesson order
    all_lessons = list(
        Lesson.objects.filter(lecture__course=course)
        .select_related("lecture")
        .order_by("lecture__order", "lecture__id", "order", "id")
    )
    index = next((i for i, item in enumerate(all_lessons) if item.pk == lesson.pk), 0)
    done_ids = completed_lesson_ids(request.user, [item.pk for item in all_lessons])

    signed_video_url = None
    if lesson.video_source == Lesson.VIDEO_SOURCE_FILE and lesson.video_file:
        token = generate_signed_video_token(request, request.user, lesson)
        signed_video_url = reverse("academy:lesson_video_stream", args=[lesson.pk]) + f"?token={token}"

    user_is_locked = False
    lock_seconds = 0
    if request.user.is_authenticated and not request.user.is_teacher:
        if request.user.is_currently_locked:
            user_is_locked = True
            lock_seconds = request.user.lock_remaining_seconds

    context = {
        "course": course,
        "lesson": lesson,
        "lecture": lesson.lecture,
        "all_lessons": all_lessons,
        "prev_lesson": all_lessons[index - 1] if index > 0 else None,
        "next_lesson": all_lessons[index + 1] if index + 1 < len(all_lessons) else None,
        "done_ids": done_ids,
        "is_done": lesson.pk in done_ids,
        "access": access,
        "signed_video_url": signed_video_url,
        "attachments": lesson.attachments.all(),
        "progress": course_progress(request.user, course) if request.user.is_authenticated else None,
        "user_is_locked": user_is_locked,
        "lock_seconds": lock_seconds,
    }
    return render(request, "student/lesson_detail.html", context)


def video_stream(request, pk):
    """بث محمي وموقع رقمياً لملف الفيديو مع حظر برامج التحميل وتشفير البث."""
    lesson = get_object_or_404(Lesson.objects.select_related("lecture", "lecture__course"), pk=pk)

    # 1. منع برامج وأدوات التحميل التلقائية (IDM / Scrapers / Bots)
    user_agent = request.META.get("HTTP_USER_AGENT", "").lower()
    for blocked in BLOCKED_DOWNLOAD_AGENTS:
        if blocked in user_agent:
            return HttpResponseForbidden("⛔ برامج وأدوات التحميل محظورة تماماً لحماية حقوق المحتوى.")

    # 2. التحقق من صلاحية الوصول للكورس أو المعاينة
    if not has_access(request.user, lesson.course) and not lesson.is_preview:
        raise PermissionDenied("لا تملك صلاحية الوصول لهذا الفيديو.")

    # 3. التحقق من التوقيع الرقمي وصلاحية الرابط المرتبط بالجلسة
    token = request.GET.get("token")
    if not verify_signed_video_token(token, request, request.user, lesson):
        return HttpResponseForbidden(
            "🔒 انتهت صلاحية رابط المشاهدة أو تم الوصول من جلسة غير مصرح بها. يرجى تحديث الصفحة لمتابعة المشاهدة."
        )

    # 4. التحقق من الـ Referer لمنع فتح الرابط في نافذة خارجية أو إرساله لأي برنامج
    referer = request.META.get("HTTP_REFERER", "")
    host = request.get_host()
    referer_netloc = urlparse(referer).netloc if referer else ""
    if not referer or (host != referer_netloc and host not in referer):
        return HttpResponseForbidden("⛔ الدخول المباشر لرابط البث محظور. يتم عرض الفيديو من داخل المشغل فقط.")

    if not lesson.video_file or not lesson.video_file.name:
        raise Http404("ملف الفيديو غير موجود.")

    file_path = lesson.video_file.path
    if not os.path.exists(file_path):
        raise Http404("ملف الفيديو غير متوفر على السيرفر.")

    file_size = os.path.getsize(file_path)
    content_type = "video/mp4"
    if file_path.lower().endswith(".webm"):
        content_type = "video/webm"
    elif file_path.lower().endswith(".mkv"):
        content_type = "video/x-matroska"
    elif file_path.lower().endswith(".mov"):
        content_type = "video/quicktime"

    range_header = request.META.get("HTTP_RANGE", "").strip()
    range_match = re.match(r"bytes=(\d+)-(\d+)?", range_header)

    if range_match:
        first_byte = int(range_match.group(1))
        last_byte = int(range_match.group(2)) if range_match.group(2) else file_size - 1
        if first_byte >= file_size:
            first_byte = file_size - 1
        if last_byte >= file_size:
            last_byte = file_size - 1
        length = last_byte - first_byte + 1

        def file_iterator(path, offset, size, chunk_size=131072):
            with open(path, "rb") as f:
                f.seek(offset)
                remaining = size
                while remaining > 0:
                    read_size = min(chunk_size, remaining)
                    data = f.read(read_size)
                    if not data:
                        break
                    remaining -= len(data)
                    yield data

        response = StreamingHttpResponse(
            file_iterator(file_path, first_byte, length),
            status=206,
            content_type=content_type,
        )
        response["Content-Range"] = f"bytes {first_byte}-{last_byte}/{file_size}"
        response["Content-Length"] = str(length)
    else:
        def full_iterator(path, chunk_size=131072):
            with open(path, "rb") as f:
                while True:
                    data = f.read(chunk_size)
                    if not data:
                        break
                    yield data

        response = StreamingHttpResponse(
            full_iterator(file_path),
            content_type=content_type,
        )
        response["Content-Length"] = str(file_size)

    # ترويسات الحماية القصوى ومنع التخزين أو التقاط الملف
    response["Accept-Ranges"] = "bytes"
    response["Content-Disposition"] = "inline; filename=lecture.dat"
    response["Cache-Control"] = "no-cache, no-store, must-revalidate, private, max-age=0"
    response["Pragma"] = "no-cache"
    response["Expires"] = "0"
    response["X-Content-Type-Options"] = "nosniff"
    response["X-Robots-Tag"] = "noindex, nofollow, noarchive, nosnippet"
    return response


@login_required
def toggle_lesson_done(request, pk):
    lesson = get_object_or_404(Lesson.objects.select_related("lecture", "lecture__course"), pk=pk)
    if request.method != "POST":
        return redirect(lesson.get_absolute_url())
    existing = LessonProgress.objects.filter(student=request.user, lesson=lesson).first()
    if existing:
        existing.delete()
        state = False
    else:
        LessonProgress.objects.create(student=request.user, lesson=lesson)
        state = True
    if request.headers.get("x-requested-with") == "XMLHttpRequest":
        return JsonResponse({"done": state})
    return redirect(lesson.get_absolute_url())


# ---------------------------------------------------------------------------
# الامتحانات
# ---------------------------------------------------------------------------
@login_required
def exam_list(request):
    course_ids = list(
        request.user.enrollments.filter(status=Enrollment.STATUS_ACTIVE).values_list("course_id", flat=True)
    )
    exams = Exam.objects.filter(course_id__in=course_ids, is_published=True).select_related("course")
    all_user_attempts = list(
        ExamAttempt.objects.filter(student=request.user).order_by("-started_at")
    )
    rows = []
    for exam in exams:
        exam_attempts = [a for a in all_user_attempts if a.exam_id == exam.pk]
        completed_attempts = [a for a in exam_attempts if a.is_submitted]
        last_attempt = exam_attempts[0] if exam_attempts else None

        if not exam.allow_retake and len(completed_attempts) >= 1:
            can_take = False
        elif exam.max_attempts > 0 and len(completed_attempts) >= exam.max_attempts:
            can_take = False
        else:
            can_take = True

        rows.append({
            "exam": exam,
            "attempt": last_attempt,
            "completed_count": len(completed_attempts),
            "can_take": can_take,
        })
    return render(request, "student/exams.html", {"rows": rows})


@login_required
def exam_start(request, pk):
    exam = get_object_or_404(Exam.objects.select_related("course"), pk=pk, is_published=True)
    if not has_access(request.user, exam.course):
        messages.warning(request, "لازم تشترك في الكورس الأول.")
        return redirect(exam.course.get_absolute_url())

    completed_count = ExamAttempt.objects.filter(
        student=request.user, exam=exam, submitted_at__isnull=False
    ).count()

    last_attempt = ExamAttempt.objects.filter(
        student=request.user, exam=exam, submitted_at__isnull=False
    ).order_by("-submitted_at").first()

    if not exam.allow_retake and completed_count >= 1:
        messages.info(request, "لقد أديت هذا الامتحان مسبقاً وغير متاح إعادة المحاولة.")
        if last_attempt:
            return redirect("academy:attempt_result", pk=last_attempt.pk)
        return redirect("academy:exams")

    if exam.max_attempts > 0 and completed_count >= exam.max_attempts:
        messages.warning(
            request,
            f"لقد استنفدت الحد الأقصى للمحاولات المسموح بها في هذا الامتحان ({exam.max_attempts_label})."
        )
        if last_attempt:
            return redirect("academy:attempt_result", pk=last_attempt.pk)
        return redirect("academy:exams")

    running = ExamAttempt.objects.filter(
        student=request.user, exam=exam, submitted_at__isnull=True
    ).first()
    attempt = running or ExamAttempt.objects.create(
        student=request.user, exam=exam, max_score=exam.max_score
    )
    return redirect("academy:exam_take", pk=attempt.pk)


@login_required
def exam_take(request, pk):
    attempt = get_object_or_404(
        ExamAttempt.objects.select_related("exam", "exam__course"), pk=pk, student=request.user
    )
    if attempt.is_submitted:
        return redirect("academy:attempt_result", pk=attempt.pk)

    questions = list(attempt.exam.questions.prefetch_related("choices"))
    if attempt.exam.shuffle_questions:
        import random
        rng = random.Random(attempt.pk)
        rng.shuffle(questions)

    context = {
        "attempt": attempt,
        "exam": attempt.exam,
        "questions": questions,
        "seconds_left": attempt.seconds_left,
    }
    return render(request, "student/exam_take.html", context)


@login_required
def exam_submit(request, pk):
    attempt = get_object_or_404(ExamAttempt, pk=pk, student=request.user)
    if attempt.is_submitted:
        return redirect("academy:attempt_result", pk=attempt.pk)
    if request.method != "POST":
        return redirect("academy:exam_take", pk=attempt.pk)

    questions = list(attempt.exam.questions.prefetch_related("choices"))
    score = 0
    total = 0
    AttemptAnswer.objects.filter(attempt=attempt).delete()
    for question in questions:
        total += question.points
        if question.is_essay:
            essay_text = request.POST.get(f"q_essay_{question.pk}", "").strip()
            # فحص وتصحيح السؤال المقالي تلقائياً إذا توفر نموذج الإجابة
            from ..services.grading import check_essay_answer
            is_correct = False
            awarded = 0
            feedback = ""
            if question.explanation and check_essay_answer(essay_text, question.explanation):
                is_correct = True
                awarded = question.points
                feedback = "تم التصحيح التلقائي: إجابة صحيحة ومطابقة لنموذج الإجابة ✅"

            score += awarded
            AttemptAnswer.objects.create(
                attempt=attempt,
                question=question,
                text_answer=essay_text,
                is_correct=is_correct,
                score_awarded=awarded,
                teacher_feedback=feedback,
            )
        else:
            raw = request.POST.get(f"q_{question.pk}")
            choice = None
            if raw:
                try:
                    choice = Choice.objects.filter(pk=raw, question=question).first()
                except (ValueError, TypeError, ValidationError):
                    choice = None
            is_correct = bool(choice and choice.is_correct)
            awarded = question.points if is_correct else 0
            score += awarded
            AttemptAnswer.objects.create(
                attempt=attempt,
                question=question,
                choice=choice,
                is_correct=is_correct,
                score_awarded=awarded,
            )

    attempt.score = score
    attempt.max_score = total
    attempt.percent = round(score * 100 / total, 1) if total else 0
    try:
        attempt.infractions_count = int(request.POST.get("infractions_count", 0))
    except (ValueError, TypeError):
        attempt.infractions_count = 0
    attempt.submitted_at = timezone.now()
    attempt.save()

    # إرسال نتيجة الامتحان تلقائياً في الخلفية (واتساب / إيميل) إذا كان سويتش المعلم مفعلاً
    try:
        from ..services.notifications import send_automatic_exam_results
        send_automatic_exam_results(attempt, request=request)
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"Error auto-sending exam results: {e}", exc_info=True)

    return redirect("academy:attempt_result", pk=attempt.pk)


@login_required
def attempt_result(request, pk):
    if request.user.is_teacher:
        attempt = get_object_or_404(
            ExamAttempt.objects.select_related("exam", "exam__course", "student"), pk=pk
        )
    else:
        attempt = get_object_or_404(
            ExamAttempt.objects.select_related("exam", "exam__course", "student"), pk=pk, student=request.user
        )

    # تصحيح السؤال المقالي بواسطة المعلم
    if request.method == "POST" and request.user.is_teacher and "grade_essay" in request.POST:
        answer_id = request.POST.get("answer_id")
        ans = get_object_or_404(AttemptAnswer, pk=answer_id, attempt=attempt)
        try:
            pts = int(request.POST.get("score_awarded", 0))
        except (ValueError, TypeError):
            pts = 0
        pts = max(0, min(pts, ans.question.points))
        feedback = request.POST.get("teacher_feedback", "").strip()
        ans.score_awarded = pts
        ans.is_correct = (pts > 0)
        ans.teacher_feedback = feedback
        ans.save()

        # إعادة احتساب مجموع درجات المحاولة والنسبة
        total_score = sum(a.score_awarded for a in attempt.answers.all())
        attempt.score = total_score
        attempt.percent = round(total_score * 100 / attempt.max_score, 1) if attempt.max_score else 0
        attempt.save()
        messages.success(request, f"تم حفظ درجة السؤال المقالي ({pts}/{ans.question.points}) وتحديث النتيجة الإجمالية بنجاح ✅")
        return redirect("academy:attempt_result", pk=attempt.pk)

    completed_count = ExamAttempt.objects.filter(
        student=attempt.student, exam=attempt.exam, submitted_at__isnull=False
    ).count()
    can_retake = attempt.exam.allow_retake and (
        attempt.exam.max_attempts == 0 or completed_count < attempt.exam.max_attempts
    )
    answers = {
        answer.question_id: answer
        for answer in attempt.answers.select_related("choice", "question")
    }
    rows = []
    has_unmarked_essays = False
    for question in attempt.exam.questions.prefetch_related("choices"):
        answer = answers.get(question.pk)
        if question.is_essay and answer and answer.score_awarded == 0 and not answer.teacher_feedback:
            has_unmarked_essays = True
        rows.append({
            "question": question,
            "answer": answer,
            "chosen_id": answer.choice_id if answer and answer.choice_id else None,
            "correct": question.correct_choice,
        })
    from ..services.whatsapp import get_whatsapp_buttons_data
    whatsapp_data = get_whatsapp_buttons_data(attempt, request=request)

    return render(request, "student/exam_result.html", {
        "attempt": attempt,
        "rows": rows,
        "can_retake": can_retake,
        "completed_count": completed_count,
        "whatsapp_data": whatsapp_data,
        "has_unmarked_essays": has_unmarked_essays,
    })


@login_required
def resend_attempt_email(request, pk):
    """إعادة إرسال نتيجة الامتحان بالبريد الإلكتروني للأب والأم والطالب يدوياً."""
    attempt = get_object_or_404(
        ExamAttempt.objects.select_related("exam", "exam__course", "student"), pk=pk
    )
    if not request.user.is_teacher and attempt.student != request.user:
        raise PermissionDenied

    from ..services.notifications import send_exam_result_emails
    sent = send_exam_result_emails(attempt, request=request)
    if sent:
        messages.success(request, "تم إرسال نتيجة الامتحان إلى البريد الإلكتروني (الطالب / الأب / الأم) بنجاح ✉️")
    else:
        messages.warning(request, "لم يتم العثور على أي بريد إلكتروني مسجل للطالب أو ولي أمره. يُرجى تسجيل الإيميل أولاً من صفحة الإعدادات.")

    referer = request.META.get("HTTP_REFERER")
    if referer:
        return redirect(referer)
    return redirect("academy:attempt_result", pk=attempt.pk)


@login_required
def my_results(request):
    attempts = (
        ExamAttempt.objects.filter(student=request.user, submitted_at__isnull=False)
        .select_related("exam", "exam__course")
        .order_by("-submitted_at")
    )
    attempts = list(attempts)
    avg = round(sum(a.percent for a in attempts) / len(attempts)) if attempts else 0
    return render(request, "student/results.html", {"attempts": attempts, "avg": avg})


def record_screenshot_violation(request):
    """تسجيل مخالفة تصوير الشاشة وتطبيق العقوبات (ساعة للمرة الأولى، وسنة للمرة الثانية)."""
    if request.method != "POST":
        return JsonResponse({"error": "طريقة غير مسموحة"}, status=405)

    if not request.user.is_authenticated:
        return JsonResponse({
            "status": "locked",
            "strikes": 1,
            "remaining_seconds": 3600,
            "message": "⚠️ تم قفل المشغل لمدة ساعة بسبب محاولة تصوير الشاشة.",
        })

    user = request.user
    user.screenshot_strikes += 1

    if user.screenshot_strikes == 1:
        # المخالفة الأولى: قفل المشغل لمدة ساعة كاملة
        user.locked_until = timezone.now() + timedelta(hours=1)
        user.save(update_fields=["screenshot_strikes", "locked_until"])
        return JsonResponse({
            "status": "locked",
            "strikes": 1,
            "remaining_seconds": 3600,
            "message": "⚠️ تم رصد محاولة تصوير شاشة. تم قفل المشغل لمدة ساعة واحدة لحماية المحتوى.",
        })
    else:
        # المخالفة الثانية: حظر الحساب بالكامل لمدة سنة
        user.is_security_banned = True
        user.banned_until = timezone.now() + timedelta(days=365)
        user.save(update_fields=["screenshot_strikes", "is_security_banned", "banned_until"])
        logout(request)
        return JsonResponse({
            "status": "banned",
            "strikes": user.screenshot_strikes,
            "message": "🚫 تم حظر حسابك لمدة عام كامل لتكرار تصوير الشاشة. يجب التواصل مع المدرس لإعادة التفعيل.",
        })


def camera_check(request):
    """صفحة فحص واختبار الكاميرا للمنظومة الذكية."""
    return render(request, "student/camera_check.html")


@login_required
def my_weekly_report(request):
    """تقرير المتابعة الأسبوعي للطالب الخاص به وإنجازاته."""
    if request.user.is_teacher:
        return redirect("academy:teacher_reports_overview")

    course_id = request.GET.get("course", "")
    try:
        week_offset = int(request.GET.get("offset", 0))
    except (ValueError, TypeError):
        week_offset = 0

    from ..services.reports import get_student_weekly_data
    data = get_student_weekly_data(
        student=request.user,
        course=course_id or None,
        week_offset=week_offset,
        request=request,
    )
    all_courses = Course.objects.all().order_by("title")

    context = {
        "student_obj": request.user,
        "all_courses": all_courses,
        "prev_offset": week_offset - 1,
        "next_offset": week_offset + 1,
        **data,
    }
    return render(request, "student/my_report.html", context)

