from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.db.models import Q

from .models import (
    AccessCode,
    Announcement,
    Attachment,
    Choice,
    ContactMessage,
    Course,
    Exam,
    Grade,
    Lecture,
    Lesson,
    Question,
    User,
)

INPUT = "form-control"
CHECK = "form-check"


class StyledFormMixin:
    """بيحط كلاسات Tailwind على كل الحقول تلقائياً."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            widget = field.widget
            if isinstance(widget, (forms.CheckboxInput,)):
                widget.attrs.setdefault("class", CHECK)
            elif isinstance(widget, forms.RadioSelect):
                continue
            else:
                widget.attrs.setdefault("class", INPUT)
            if isinstance(widget, forms.Textarea):
                widget.attrs.setdefault("rows", 4)


class LoginForm(StyledFormMixin, AuthenticationForm):
    username = forms.CharField(label="اسم المستخدم أو رقم الموبايل")
    password = forms.CharField(label="كلمة السر", widget=forms.PasswordInput)

    error_messages = {
        "invalid_login": "اسم المستخدم أو كلمة السر غير صحيحة.",
        "inactive": "هذا الحساب موقوف حالياً.",
    }


class RegisterForm(StyledFormMixin, UserCreationForm):
    first_name = forms.CharField(label="الاسم الأول", max_length=60)
    last_name = forms.CharField(label="اسم العائلة", max_length=60)
    phone = forms.CharField(label="رقم واتساب الطالب", max_length=20, help_text="للتواصل واستلام إشعارات الامتحانات")
    parent_phone = forms.CharField(label="رقم واتساب الأب (ولي الأمر)", max_length=20, required=False, help_text="لاستلام نتائج الامتحانات عبر الواتساب")
    mother_phone = forms.CharField(label="رقم واتساب الأم", max_length=20, required=False, help_text="لاستلام نتائج الامتحانات عبر الواتساب")
    email = forms.EmailField(label="البريد الإلكتروني للطالب (اختياري)", required=False)
    city = forms.CharField(label="المحافظة / المركز", max_length=60, required=False)
    grade = forms.ModelChoiceField(
        label="الصف الدراسي",
        queryset=Grade.objects.filter(is_active=True),
        empty_label="اختر الصف",
    )

    class Meta:
        model = User
        fields = [
            "first_name", "last_name", "username", "phone",
            "parent_phone", "mother_phone", "email", "city", "grade",
        ]
        labels = {"username": "اسم المستخدم (بالإنجليزية)"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["password1"].label = "كلمة السر"
        self.fields["password2"].label = "تأكيد كلمة السر"
        self.fields["password1"].help_text = "٦ أحرف على الأقل."
        self.fields["password2"].help_text = ""
        self.fields["username"].help_text = "حروف إنجليزية وأرقام بدون مسافات."

    def clean_phone(self):
        phone = (self.cleaned_data.get("phone") or "").strip()
        if phone and User.objects.filter(phone=phone).exists():
            raise forms.ValidationError("الرقم ده مسجّل قبل كده.")
        return phone

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = User.ROLE_STUDENT
        for field in ("phone", "parent_phone", "mother_phone", "email", "city", "grade"):
            setattr(user, field, self.cleaned_data.get(field))
        if commit:
            user.save()
        return user


class ProfileForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = User
        fields = [
            "first_name", "last_name", "phone", "parent_phone", "mother_phone",
            "father_telegram_chat_id", "mother_telegram_chat_id", "telegram_chat_id",
            "email", "city", "grade", "bio",
        ]
        labels = {
            "first_name": "الاسم الأول",
            "last_name": "اسم العائلة",
            "phone": "رقم واتساب الطالب",
            "parent_phone": "رقم واتساب الأب (ولي الأمر)",
            "mother_phone": "رقم واتساب الأم",
            "father_telegram_chat_id": "معرف تيليجرام الأب (Chat ID)",
            "mother_telegram_chat_id": "معرف تيليجرام الأم (Chat ID)",
            "telegram_chat_id": "معرف تيليجرام الطالب (Chat ID)",
            "email": "البريد الإلكتروني",
            "bio": "نبذة عنك",
        }


class ContactForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = ContactMessage
        fields = ["name", "phone", "message"]


class ActivationCodeForm(StyledFormMixin, forms.Form):
    code = forms.CharField(
        label="كود التفعيل أو الكود الموحد للكورس",
        max_length=50,
        widget=forms.TextInput(attrs={"placeholder": "اكتب الكود هنا (مثال: PH-XXXXXX أو الكود الموحد)..."}),
    )

    def __init__(self, *args, course=None, **kwargs):
        self.course = course
        super().__init__(*args, **kwargs)

    def clean_code(self):
        code = self.cleaned_data["code"].strip().upper()
        # 1. التحقق أولاً من كود الكورس الموحد (Master Access Code)
        if self.course and self.course.master_access_code:
            master = self.course.master_access_code.strip().upper()
            if code == master:
                self.is_master_code = True
                self.access_code = None
                return code

        # 2. التحقق من أكواد التفعيل الفردية (Single-use AccessCode)
        self.is_master_code = False
        obj = AccessCode.objects.filter(code=code, is_used=False).first()
        if not obj:
            raise forms.ValidationError("الكود غير صحيح أو مستخدم قبل كده.")
        if obj.course_id and self.course and obj.course_id != self.course.pk:
            raise forms.ValidationError("الكود ده مخصص لكورس تاني.")
        self.access_code = obj
        return code


# ---------------------------------------------------------------------------
# فورمات لوحة تحكم المدرس
# ---------------------------------------------------------------------------
class GradeForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Grade
        fields = ["name", "order", "is_active"]


class CourseForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Course
        fields = [
            "title", "grade", "master_access_code", "summary", "description", "price",
            "is_free", "is_published", "enable_watermark", "emoji", "accent", "order",
        ]
        widgets = {
            "master_access_code": forms.TextInput(attrs={
                "class": INPUT,
                "placeholder": "مثال: BIO-2026 أو MATH-101 (كود موحد يدخل به كل الطلبة ويفضل شغال)",
            }),
        }


class LectureForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Lecture
        fields = ["title", "description", "order"]


class LessonForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Lesson
        fields = [
            "title", "description", "video_source",
            "video_file", "youtube_id", "drive_url",
            "duration_minutes", "order", "is_preview", "enable_watermark",
        ]
        labels = {
            "video_source": "طريقة إضافة الفيديو",
            "video_file": "اختر ملف الفيديو من جهازك (MP4 / WebM / MKV)",
            "youtube_id": "رابط أو كود فيديو يوتيوب",
            "drive_url": "رابط المشاركة من جوجل درايف",
            "enable_watermark": "تفعيل العلامة المائية ببيانات الطالب على هذا الدرس",
        }

    def clean(self):
        import re
        data = super().clean()
        source = data.get("video_source")
        video_file = data.get("video_file")
        youtube_id = (data.get("youtube_id") or "").strip()
        drive_url = (data.get("drive_url") or "").strip()

        if source == Lesson.VIDEO_SOURCE_FILE:
            if not video_file and not (self.instance and self.instance.pk and self.instance.video_file):
                self.add_error("video_file", "من فضلك اختر ملف الفيديو لرفعه.")
            elif video_file:
                allowed_extensions = (".mp4", ".webm", ".mkv", ".mov", ".m4v", ".avi")
                if not any(video_file.name.lower().endswith(ext) for ext in allowed_extensions):
                    self.add_error("video_file", f"صيغة الملف غير مدعومة. الصيغ المسموحة: {', '.join(allowed_extensions)}")
        elif source == Lesson.VIDEO_SOURCE_YOUTUBE:
            if not youtube_id:
                self.add_error("youtube_id", "من فضلك اكتب رابط أو كود فيديو يوتيوب.")
            else:
                iframe_match = re.search(r'src=["\']([^"\']+)["\']', youtube_id)
                val = iframe_match.group(1) if iframe_match else youtube_id
                match = re.search(r"(?:v=|\/embed\/|youtu\.be\/|\/v\/|\/shorts\/|\/live\/|e\/)([a-zA-Z0-9_-]{11})", val)
                if match:
                    data["youtube_id"] = match.group(1)
                elif len(val) == 11 and re.match(r"^[a-zA-Z0-9_-]{11}$", val):
                    data["youtube_id"] = val
        elif source == Lesson.VIDEO_SOURCE_DRIVE:
            if not drive_url:
                self.add_error("drive_url", "من فضلك اكتب رابط أو كود ملف جوجل درايف.")
            else:
                iframe_match = re.search(r'src=["\']([^"\']+)["\']', drive_url)
                if iframe_match:
                    data["drive_url"] = iframe_match.group(1)
        return data


class AttachmentForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Attachment
        fields = ["title", "kind", "file", "url"]

    def clean(self):
        data = super().clean()
        if data.get("kind") == Attachment.KIND_FILE and not data.get("file"):
            raise forms.ValidationError("اختر ملف من فضلك.")
        if data.get("kind") == Attachment.KIND_LINK and not data.get("url"):
            raise forms.ValidationError("اكتب الرابط من فضلك.")
        return data


class ExamForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Exam
        fields = [
            "title", "course", "lesson", "description", "duration_minutes",
            "pass_percent", "max_attempts", "allow_retake", "is_published",
            "auto_send_result", "max_infractions",
            "require_webcam", "require_fullscreen", "prevent_copy_paste",
            "shuffle_questions", "ai_multi_person_detection", "ai_absence_and_camera_block",
            "prevent_multiple_screens",
        ]
        widgets = {
            "max_infractions": forms.NumberInput(attrs={"min": 1, "max": 20, "class": INPUT}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["lesson"].required = False
        self.fields["lesson"].empty_label = "-- كويز عام على الكورس كله (بدون درس محدد) --"
        course_id = self.initial.get("course") or (self.instance.course_id if self.instance.pk else None)
        if course_id:
            self.fields["lesson"].queryset = Lesson.objects.filter(lecture__course_id=course_id)
        else:
            self.fields["lesson"].queryset = Lesson.objects.select_related("lecture", "lecture__course").all()


class QuestionForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Question
        fields = ["question_type", "text", "image", "points", "order", "explanation"]
        widgets = {
            "question_type": forms.Select(attrs={"class": INPUT, "id": "id_question_type"}),
            "image": forms.FileInput(attrs={"class": INPUT, "accept": "image/*"}),
            "text": forms.Textarea(attrs={"rows": 3, "placeholder": "اكتب نص السؤال هنا..."}),
            "explanation": forms.Textarea(attrs={
                "rows": 3,
                "id": "id_explanation",
                "placeholder": "اكتب الإجابة النموذجية الصحيحة (للتصحيح التلقائي الكامل) أو الشرح...",
            }),
        }


ChoiceFormSet = forms.inlineformset_factory(
    Question,
    Choice,
    fields=["text", "is_correct", "order"],
    extra=4,
    max_num=6,
    can_delete=True,
    widgets={
        "text": forms.TextInput(attrs={"class": INPUT, "placeholder": "نص الاختيار"}),
        "order": forms.NumberInput(attrs={"class": INPUT}),
        "is_correct": forms.CheckboxInput(attrs={"class": CHECK}),
    },
    labels={"text": "الاختيار", "is_correct": "صحيح", "order": "الترتيب"},
)


class AnnouncementForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ["title", "body", "grade", "is_pinned"]


class CodeGenerateForm(StyledFormMixin, forms.Form):
    count = forms.IntegerField(
        label="عدد الأكواد المطلوبة",
        min_value=1,
        max_value=1000,
        initial=50,
        help_text="يمكنك توليد حتى 1000 كود دفعة واحدة (مثلاً: 200 كود)",
    )
    course = forms.ModelChoiceField(
        label="الكورس المخصص",
        queryset=Course.objects.all(),
        required=False,
        empty_label="أي كورس (كود عام)",
    )
    prefix = forms.CharField(
        label="بادئة الكود (Prefix)",
        max_length=8,
        required=False,
        initial="PH",
        help_text="مثال: PH أو BIO أو CAM",
    )
    download_excel = forms.BooleanField(
        label="تحميل شيت إكسيل بالأكواد فوراً بعد التوليد 📥",
        required=False,
        initial=True,
    )


class StudentPasswordResetForm(StyledFormMixin, forms.Form):
    """نموذج استعادة كلمة المرور للطالب عبر التحقق من رقم ولي الأمر."""

    identifier = forms.CharField(
        label="اسم المستخدم أو رقم هاتف الطالب",
        help_text="أدخل اسم المستخدم أو رقم الموبايل المسجل بحسابك",
    )
    parent_phone = forms.CharField(
        label="رقم هاتف ولي الأمر (للتحقق الأمني)",
        help_text="أدخل رقم هاتف الأب أو الأم المسجل في بيانات حسابك",
    )
    new_password1 = forms.CharField(
        label="كلمة المرور الجديدة",
        widget=forms.PasswordInput,
        min_length=6,
        help_text="6 أحرف أو أرقام على الأقل",
    )
    new_password2 = forms.CharField(
        label="تأكيد كلمة المرور الجديدة",
        widget=forms.PasswordInput,
    )

    def clean(self):
        cleaned_data = super().clean()
        p1 = cleaned_data.get("new_password1")
        p2 = cleaned_data.get("new_password2")
        if p1 and p2 and p1 != p2:
            self.add_error("new_password2", "كلمتا المرور غير متطابقتين.")

        identifier = (cleaned_data.get("identifier") or "").strip()
        parent_phone = (cleaned_data.get("parent_phone") or "").strip()

        if identifier and parent_phone:
            import re
            user = User.objects.filter(
                Q(username__iexact=identifier) | Q(phone=identifier),
                role=User.ROLE_STUDENT,
            ).first()

            if not user:
                raise forms.ValidationError(
                    "لم يتم العثور على حساب طالب بهذه البيانات. يرجى التأكد من اسم المستخدم أو رقم الموبايل."
                )

            def norm(p):
                return re.sub(r"\D", "", str(p or ""))

            entered_norm = norm(parent_phone)
            father_norm = norm(user.parent_phone)
            mother_norm = norm(user.mother_phone)

            # مطابقة تامة أو مطابقة لآخر 9 أرقام لتجاوز بادئات الدول (0020 أو 01...)
            match_father = False
            if father_norm and entered_norm:
                match_father = (father_norm == entered_norm) or (
                    len(father_norm) >= 9 and len(entered_norm) >= 9 and father_norm[-9:] == entered_norm[-9:]
                )

            match_mother = False
            if mother_norm and entered_norm:
                match_mother = (mother_norm == entered_norm) or (
                    len(mother_norm) >= 9 and len(entered_norm) >= 9 and mother_norm[-9:] == entered_norm[-9:]
                )

            if not match_father and not match_mother:
                raise forms.ValidationError(
                    "رقم هاتف ولي الأمر غير مطابق للبيانات المسجلة في هذا الحساب. يرجى التأكد من الرقم أو التواصل مع المدرس."
                )

            self.target_user = user

        return cleaned_data

