from django import template

register = template.Library()

GRADIENTS = {
    "brand": "from-brand-600 to-brand-400",
    "emerald": "from-emerald-600 to-emerald-400",
    "amber": "from-amber-500 to-amber-300",
    "rose": "from-rose-600 to-rose-400",
    "violet": "from-violet-600 to-violet-400",
}

SOLID = {
    "brand": "bg-brand-600",
    "emerald": "bg-emerald-500",
    "amber": "bg-amber-500",
    "rose": "bg-rose-500",
    "violet": "bg-violet-500",
}


@register.filter
def accent_gradient(value):
    return GRADIENTS.get(value, GRADIENTS["brand"])


@register.filter
def accent_solid(value):
    return SOLID.get(value, SOLID["brand"])


@register.filter
def get_item(dictionary, key):
    try:
        return dictionary.get(key)
    except AttributeError:
        return None


@register.filter
def percent_of(value, total):
    try:
        return round(float(value) * 100 / float(total))
    except (ValueError, ZeroDivisionError, TypeError):
        return 0
