from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend
from django.db.models import Q


class UsernameOrPhoneBackend(ModelBackend):
    """يسمح للطالب يسجّل دخول باسم المستخدم أو برقم الموبايل."""

    def authenticate(self, request, username=None, password=None, **kwargs):
        User = get_user_model()
        if username is None or password is None:
            return None
        try:
            user = User.objects.filter(
                Q(username__iexact=username) | Q(phone=username)
            ).first()
        except Exception:
            user = None
        if user and user.check_password(password) and self.user_can_authenticate(user):
            return user
        return None
