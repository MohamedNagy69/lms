"""حماية الجلسات ومنع تسجيل الدخول المتزامن من أكثر من جهاز."""

from django.contrib import messages
from django.contrib.auth import logout
from django.shortcuts import redirect


class SingleSessionMiddleware:
    """منع تسجيل الدخول المتزامن (Single Active Session) للطلاب."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated and not request.user.is_teacher:
            # 1. فحص حظر تصوير الشاشة السنوي
            if getattr(request.user, "is_security_banned", False):
                from django.utils import timezone
                banned_until = getattr(request.user, "banned_until", None)
                if banned_until and banned_until > timezone.now():
                    logout(request)
                    messages.error(
                        request,
                        "🚫 تم حظر حسابك لمدة عام كامل بسبب تكرار محاولة تصوير الشاشة. لإعادة التفعيل يجب مراجعة المدرس مباشرة.",
                    )
                    return redirect("academy:login")
                else:
                    request.user.is_security_banned = False
                    request.user.screenshot_strikes = 0
                    request.user.save(update_fields=["is_security_banned", "screenshot_strikes"])

            # 2. فحص صلاحية جلسة الجهاز (بحد أقصى جهازين مصرح بهما مع الخروج التلقائي)
            current_key = request.session.session_key
            if current_key:
                # التحقق مما إذا كانت هذه الجلسة تتبع جهازاً نشطاً ومصرحاً به للطالب
                has_active_devices = request.user.devices.filter(is_active=True).exists()
                if has_active_devices:
                    is_valid_device_session = request.user.devices.filter(
                        session_key=current_key, is_active=True
                    ).exists()

                    if not is_valid_device_session:
                        logout(request)
                        messages.warning(
                            request,
                            "⚠️ تم إنهاء جلستك هنا تلقائياً: تم تسجيل الدخول إلى حسابك من جهاز جديد.",
                        )
                        return redirect("academy:login")

        return self.get_response(request)
