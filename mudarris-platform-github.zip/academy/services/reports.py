"""
خدمة تقارير المتابعة الأسبوعية للطلاب مع رصد قراءة واطلاع أولياء الأمور عبر الواتساب.
"""

from datetime import datetime, timedelta
import logging
import urllib.parse

from django.conf import settings
from django.urls import reverse
from django.utils import timezone

from ..models import (
    Course,
    Enrollment,
    Exam,
    ExamAttempt,
    Lecture,
    Lesson,
    LessonProgress,
    ParentReportView,
    User,
)
from .whatsapp import clean_phone_for_whatsapp

logger = logging.getLogger(__name__)


def get_week_bounds(offset: int = 0, start_date=None, end_date=None):
    """
    حساب بداية ونهاية الأسبوع الدراسي (من السبت إلى الجمعة المعتمد في مصر والمنطقة العربية).
    offset: 0 = الأسبوع الحالي، -1 = الأسبوع الماضي، وهكذا.
    """
    if start_date and end_date:
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
        return start_date, end_date

    today = timezone.now().date()
    # حساب المسافة من أقرب يوم سبت سابق (في بايثون الاثنين=0، السبت=5)
    # (today.weekday() + 2) % 7 تعطي: السبت -> 0, الأحد -> 1, ... الجمعة -> 6
    days_since_saturday = (today.weekday() + 2) % 7
    this_saturday = today - timedelta(days=days_since_saturday)

    start = this_saturday + timedelta(weeks=offset)
    end = start + timedelta(days=6)
    return start, end


def format_arabic_date(d) -> str:
    """تنسيق التاريخ بصيغة عربية واضحة."""
    if not d:
        return ""
    months_ar = [
        "", "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    ]
    days_ar = {
        "Saturday": "السبت", "Sunday": "الأحد", "Monday": "الاثنين",
        "Tuesday": "الثلاثاء", "Wednesday": "الأربعاء", "Thursday": "الخميس", "Friday": "الجمعة"
    }
    day_name = days_ar.get(d.strftime("%A"), "")
    return f"{day_name} {d.day} {months_ar[d.month]} {d.year}"


def build_parent_report_message(
    student: User,
    course: Course,
    week_start,
    week_end,
    course_data: dict,
    exams_data: list,
    parent_report_url: str,
    recipient_role: str = "parent",
) -> str:
    """
    صياغة رسالة واتساب أنيقة ومؤثرة لولي الأمر تتضمن ملخص الأسبوع ورابط التقرير الكامل مع PDF.
    """
    site_info = getattr(settings, "SITE_INFO", {
        "site_name": "منصة الغيطي التعليمية",
        "teacher_name": "د. ناجي الغيطي",
        "subject": "اللغة العربية",
        "phone": "+201005209526",
    })
    site_title = site_info.get("site_name", "منصة الغيطي التعليمية")
    teacher_name = site_info.get("teacher_name", "د. ناجي الغيطي")
    subject_name = site_info.get("subject", "اللغة العربية")

    start_str = format_arabic_date(week_start)
    end_str = format_arabic_date(week_end)

    divider = "━━━━━━━━━━━━━━━━━━━━━"

    if recipient_role == "father":
        greeting = (
            "السلام عليكم ورحمة الله وبركاته 🌹\n"
            "حضرة الفاضل ولي أمر الطالب (والد الطالب المحترم) 👨‍💼\n\n"
            f"يسعدنا موافاة سيادتكم بـ *التقرير الأسبوعي الشامل* لمتابعة أداء والتزام ابننا البطل:"
        )
    elif recipient_role == "mother":
        greeting = (
            "السلام عليكم ورحمة الله وبركاته 🌹\n"
            "حضرة الفاضلة ولية أمر الطالب (والدة الطالب الكريمة) 👩‍💼\n\n"
            f"يسعدنا موافاة سيادتكِ بـ *التقرير الأسبوعي الشامل* لمتابعة أداء والتزام ابننا البطل:"
        )
    else:
        greeting = (
            "أهلاً بك يا بطل 🌟\n"
            f"عزيزنا الطالب المتميز: *{student.display_name}*،\n\n"
            "إليك تقرير أدائك وإنجازك الأسبوعي:"
        )

    # ملخص الدروس المشاهدة
    total_lessons = course_data.get("total_lessons", 0)
    total_watched = course_data.get("total_watched", 0)
    watched_this_week = course_data.get("watched_this_week_count", 0)
    percent = course_data.get("progress_percent", 0)

    if percent >= 90:
        progress_icon = "🔥 عبقري ومتقدم جداً"
    elif percent >= 65:
        progress_icon = "👏 مستوى متميز ومتقدم"
    elif percent >= 40:
        progress_icon = "👍 يسير بخطى جيدة"
    else:
        progress_icon = "⚠️ يحتاج للمزيد من الالتزام"

    lessons_summary = (
        f"📚 *الكورس الدراسي:* {course.title if course else 'المحتوى العام'}\n"
        f"📊 *إجمالي المحاضرات المشاهدة من الكورس:* {total_watched} من أصل {total_lessons} محاضرة ({percent}%)\n"
        f"🎬 *المحاضرات التي شاهدها هذا الأسبوع:* {watched_this_week} محاضرة\n"
        f"📈 *حالة الإنجاز:* {progress_icon}"
    )

    # ملخص الامتحانات خلال الأسبوع
    if exams_data:
        exams_lines = []
        for ex in exams_data:
            pass_mark = "ناجح ومجتاز ✅" if ex["is_passed"] else "يحتاج إعادة وتكثيف ❌"
            exams_lines.append(
                f"▫️ *{ex['exam_title']}* : نتيجته ({ex['score']}/{ex['max_score']}) بنسبة *%{ex['percent']}* — {pass_mark}"
            )
        exams_summary = "📝 *امتحانات واختبارات هذا الأسبوع:*\n" + "\n".join(exams_lines)
    else:
        exams_summary = "📝 *امتحانات هذا الأسبوع:* لم يؤدِّ امتحانات خلال هذه الفترة أو لا توجد اختبارات مقررة."

    # خاتمة ورابط التقرير
    footer = (
        "📑 *للإطلاع على التقرير التفصيلي الكامل مع كشف الإجابات وتحميل ملف PDF:* 👇\n"
        f"{parent_report_url}\n\n"
        "*(الرابط مباشر وخاص بولي الأمر ولا يتطلب أي تسجيل دخول)*\n\n"
        "مع تمنياتنا لابننا الغالي بدوام التفوق والدرجات العالية 🌟\n"
        f"مع خالص تحيات / *{teacher_name}* ({site_title})"
    )

    message = (
        f"*{site_title}* 🎓\n"
        f"مادة: *{subject_name}* | أسبوع: {week_start.strftime('%d/%m')} - {week_end.strftime('%d/%m/%Y')}\n"
        f"{divider}\n\n"
        f"{greeting}\n"
        f"👤 *الطالب:* {student.display_name}\n\n"
        f"{divider}\n"
        f"{lessons_summary}\n\n"
        f"{divider}\n"
        f"{exams_summary}\n\n"
        f"{divider}\n"
        f"{footer}"
    )
    return message


def get_student_weekly_data(
    student: User,
    course=None,
    week_offset: int = 0,
    start_date=None,
    end_date=None,
    request=None,
):
    """
    تجميع وتحليل بيانات الأسبوع بالكامل للطالب:
    1. حساب نطاق الأسبوع.
    2. كشف المحاضرات والدروس: المشاهدة، غير المشاهدة، ونسبة الإنجاز الإجمالية.
    3. كشف الامتحانات الأسبوعية وإجابات الطالب وردوده.
    4. إنشاء/جلب سجل اطلاع ولي الأمر ورابط المشاهدة الخاص.
    5. توليد رسائل الواتساب الجاهزة للإرسال للأب والأم والطالب.
    """
    week_start, week_end = get_week_bounds(offset=week_offset, start_date=start_date, end_date=end_date)

    # الكورسات المتاحة والمشترك بها الطالب
    enrollments = (
        Enrollment.objects.filter(student=student, status="active")
        .select_related("course")
        .order_by("-created_at")
    )
    enrolled_courses = [e.course for e in enrollments]

    # تحديد الكورس المطلوب
    selected_course = None
    if course:
        if isinstance(course, (int, str)):
            try:
                selected_course = Course.objects.filter(pk=course).first()
                if not selected_course:
                    selected_course = Course.objects.filter(slug=course).first()
            except Exception:
                selected_course = None
        else:
            selected_course = course

    if not selected_course and enrolled_courses:
        selected_course = enrolled_courses[0]
    elif not selected_course:
        selected_course = Course.objects.filter(is_published=True).first()

    # -------------------------------------------------------------
    # 1. تفاصيل المحاضرات والدروس في الكورس
    # -------------------------------------------------------------
    lectures_data = []
    total_course_lessons = 0
    total_watched_lessons = 0
    lessons_watched_this_week_count = 0

    if selected_course:
        # جلب جميع محاضرات الكورس ودروسها
        lectures = (
            Lecture.objects.filter(course=selected_course)
            .prefetch_related("lessons")
            .order_by("order", "id")
        )

        # جلب كافة سجلات تقدم الطالب في هذا الكورس
        student_progress = {
            lp.lesson_id: lp
            for lp in LessonProgress.objects.filter(
                student=student,
                lesson__lecture__course=selected_course,
            )
        }

        for lecture in lectures:
            lecture_lessons = []
            lec_watched = 0
            lessons_list = list(lecture.lessons.all().order_by("order", "id"))

            for lesson in lessons_list:
                total_course_lessons += 1
                prog = student_progress.get(lesson.id)
                is_completed = bool(prog and prog.is_completed)
                completed_at = prog.completed_at if is_completed else None

                watched_this_week = False
                if is_completed and completed_at:
                    watched_date = completed_at.date()
                    if week_start <= watched_date <= week_end:
                        watched_this_week = True
                        lessons_watched_this_week_count += 1

                if is_completed:
                    total_watched_lessons += 1
                    lec_watched += 1

                lecture_lessons.append({
                    "lesson": lesson,
                    "is_completed": is_completed,
                    "completed_at": completed_at,
                    "watched_this_week": watched_this_week,
                    "duration_minutes": lesson.duration_minutes,
                    "status_label": (
                        "شوهد هذا الأسبوع ✅"
                        if watched_this_week
                        else ("شوهد سابقاً 👁️" if is_completed else "لم يشاهد بعد ⏳")
                    ),
                    "badge_color": (
                        "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                        if watched_this_week
                        else (
                            "bg-sky-500/10 text-sky-400 border border-sky-500/20"
                            if is_completed
                            else "bg-slate-500/10 text-slate-400 border border-slate-500/20"
                        )
                    ),
                })

            lectures_data.append({
                "lecture": lecture,
                "lessons": lecture_lessons,
                "total_lessons": len(lessons_list),
                "watched_lessons": lec_watched,
                "is_completed": (lec_watched == len(lessons_list)) if lessons_list else False,
            })

    progress_percent = (
        round((total_watched_lessons / total_course_lessons) * 100, 1)
        if total_course_lessons > 0
        else 0
    )

    course_data = {
        "course": selected_course,
        "total_lessons": total_course_lessons,
        "total_watched": total_watched_lessons,
        "remaining_lessons": max(0, total_course_lessons - total_watched_lessons),
        "watched_this_week_count": lessons_watched_this_week_count,
        "progress_percent": progress_percent,
        "lectures": lectures_data,
    }

    # -------------------------------------------------------------
    # 2. تفاصيل الامتحانات وإجابات الطالب خلال الأسبوع
    # -------------------------------------------------------------
    # نبحث عن الامتحانات التي سلمها الطالب في نطاق الأسبوع
    attempts_qs = ExamAttempt.objects.filter(
        student=student,
        submitted_at__isnull=False,
        submitted_at__date__gte=week_start,
        submitted_at__date__lte=week_end,
    ).select_related("exam", "exam__course").order_by("-submitted_at")

    if selected_course:
        course_attempts = attempts_qs.filter(exam__course=selected_course)
        if course_attempts.exists():
            attempts_qs = course_attempts

    exams_data = []
    total_score_sum = 0
    total_max_sum = 0

    for attempt in attempts_qs:
        total_score_sum += attempt.score
        total_max_sum += attempt.max_score

        # جلب الإجابات والردود التفصيلية
        answers = (
            attempt.answers.select_related("question", "choice")
            .prefetch_related("question__choices")
            .order_by("question__order", "question__id")
        )

        answers_list = []
        correct_count = 0
        incorrect_count = 0
        essay_count = 0

        for ans in answers:
            q = ans.question
            if ans.is_correct:
                correct_count += 1
            elif q.is_mcq:
                incorrect_count += 1

            if q.is_essay:
                essay_count += 1

            # الإجابة المختارة أو النصية
            user_ans_text = ""
            if q.is_mcq:
                user_ans_text = ans.choice.text if ans.choice else "لم يجب"
            else:
                user_ans_text = ans.text_answer or "لم يكتب إجابة"

            correct_ans_text = ""
            if q.is_mcq and q.correct_choice:
                correct_ans_text = q.correct_choice.text

            answers_list.append({
                "answer_obj": ans,
                "question": q,
                "user_answer": user_ans_text,
                "correct_answer": correct_ans_text,
                "is_correct": ans.is_correct,
                "is_mcq": q.is_mcq,
                "is_essay": q.is_essay,
                "score_awarded": ans.score_awarded,
                "points": q.points,
                "teacher_feedback": ans.teacher_feedback,
                "explanation": q.explanation,
            })

        exams_data.append({
            "attempt": attempt,
            "exam": attempt.exam,
            "exam_title": attempt.exam.title,
            "submitted_at": attempt.submitted_at,
            "score": attempt.score,
            "max_score": attempt.max_score,
            "percent": round(attempt.percent, 1),
            "is_passed": attempt.is_passed,
            "infractions_count": attempt.infractions_count,
            "answers": answers_list,
            "total_questions": len(answers_list),
            "correct_count": correct_count,
            "incorrect_count": incorrect_count,
            "essay_count": essay_count,
        })

    exams_count = len(exams_data)
    avg_exam_percent = (
        round(sum(e["percent"] for e in exams_data) / exams_count, 1)
        if exams_count > 0
        else 0
    )

    # -------------------------------------------------------------
    # 3. سجل اطلاع ولي الأمر والرابط الآمن
    # -------------------------------------------------------------
    parent_report = ParentReportView.get_or_create_report(
        student=student,
        week_start=week_start,
        week_end=week_end,
        course=selected_course,
        recipient_role="parent",
    )

    # رابط التقرير المباشر لولي الأمر
    try:
        parent_path = reverse("academy:parent_report_view", kwargs={"token": parent_report.token})
    except Exception:
        parent_path = f"/report/parent/{parent_report.token}/"

    if request:
        try:
            parent_report_url = request.build_absolute_uri(parent_path)
        except Exception:
            base_url = getattr(settings, "SITE_URL", "http://127.0.0.1:8000").rstrip("/")
            parent_report_url = f"{base_url}{parent_path}"
    else:
        base_url = getattr(settings, "SITE_URL", "http://127.0.0.1:8000").rstrip("/")
        parent_report_url = f"{base_url}{parent_path}"

    # -------------------------------------------------------------
    # 4. توليد رسائل الواتساب المجهزة للأب والأم والطالب
    # -------------------------------------------------------------
    father_msg = build_parent_report_message(
        student=student,
        course=selected_course,
        week_start=week_start,
        week_end=week_end,
        course_data=course_data,
        exams_data=exams_data,
        parent_report_url=parent_report_url,
        recipient_role="father",
    )
    mother_msg = build_parent_report_message(
        student=student,
        course=selected_course,
        week_start=week_start,
        week_end=week_end,
        course_data=course_data,
        exams_data=exams_data,
        parent_report_url=parent_report_url,
        recipient_role="mother",
    )
    student_msg = build_parent_report_message(
        student=student,
        course=selected_course,
        week_start=week_start,
        week_end=week_end,
        course_data=course_data,
        exams_data=exams_data,
        parent_report_url=parent_report_url,
        recipient_role="student",
    )

    father_phone = clean_phone_for_whatsapp(student.parent_phone)
    mother_phone = clean_phone_for_whatsapp(getattr(student, "mother_phone", ""))
    student_phone = clean_phone_for_whatsapp(student.phone)

    father_whatsapp_url = (
        f"https://wa.me/{father_phone}?text={urllib.parse.quote(father_msg)}"
        if father_phone
        else ""
    )
    mother_whatsapp_url = (
        f"https://wa.me/{mother_phone}?text={urllib.parse.quote(mother_msg)}"
        if mother_phone
        else ""
    )
    student_whatsapp_url = (
        f"https://wa.me/{student_phone}?text={urllib.parse.quote(student_msg)}"
        if student_phone
        else ""
    )

    return {
        "student": student,
        "selected_course": selected_course,
        "enrolled_courses": enrolled_courses,
        "week_start": week_start,
        "week_end": week_end,
        "week_start_str": format_arabic_date(week_start),
        "week_end_str": format_arabic_date(week_end),
        "week_offset": week_offset,
        "course_data": course_data,
        "exams_data": exams_data,
        "exams_count": exams_count,
        "avg_exam_percent": avg_exam_percent,
        "parent_report": parent_report,
        "parent_report_url": parent_report_url,
        "father_whatsapp_url": father_whatsapp_url,
        "mother_whatsapp_url": mother_whatsapp_url,
        "student_whatsapp_url": student_whatsapp_url,
        "father_msg": father_msg,
        "mother_msg": mother_msg,
        "student_msg": student_msg,
    }
