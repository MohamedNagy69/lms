import io
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from django.http import HttpResponse


def export_codes_to_excel(codes_qs, filename="activation_codes.xlsx", title="أكواد تفعيل المنصة") -> HttpResponse:
    """
    تصدير قائمة أكواد التفعيل إلى ملف Excel بصيغة .xlsx منسّق ومنظّم مع دعم كامل للغة العربية (RTL).
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "أكواد التفعيل"

    # تفعيل اتجاه الورقة من اليمين إلى اليسار (Right-to-Left)
    ws.views.sheetView[0].rightToLeft = True

    # تعريف الألوان والتنسيقات
    header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid") # كحلي داكن
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    
    available_fill = PatternFill(start_color="ECFDF5", end_color="ECFDF5", fill_type="solid") # أخضر فاتح
    available_font = Font(name="Segoe UI", size=10, bold=True, color="047857")
    
    used_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid") # رمادي فاتح
    used_font = Font(name="Segoe UI", size=10, color="64748B")

    code_font = Font(name="Consolas", size=12, bold=True, color="0F172A")
    regular_font = Font(name="Segoe UI", size=10, color="1E293B")
    
    thin_border = Border(
        left=Side(style="thin", color="E2E8F0"),
        right=Side(style="thin", color="E2E8F0"),
        top=Side(style="thin", color="E2E8F0"),
        bottom=Side(style="thin", color="E2E8F0"),
    )

    align_center = Alignment(horizontal="center", vertical="center")
    align_right = Alignment(horizontal="right", vertical="center")

    # كتابة ترويسة الأعمدة
    headers = [
        "م",
        "كود التفعيل (Code)",
        "الكورس المخصص",
        "حالة الكود",
        "اسم الطالب المستخدم",
        "رقم هاتف الطالب",
        "تاريخ ووقت الاستخدام",
        "تاريخ التوليد",
    ]

    ws.append(headers)

    # تنسيق صف العناوين
    ws.row_dimensions[1].height = 28
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = align_center
        cell.border = thin_border

    # كتابة صفوف الأكواد
    for idx, item in enumerate(codes_qs, start=1):
        row_num = idx + 1
        ws.row_dimensions[row_num].height = 22

        course_name = item.course.title if item.course else "أي كورس (عام)"
        status_text = "مستخدم" if item.is_used else "متاح للاستخدام"
        student_name = item.used_by.display_name if item.used_by else "—"
        student_phone = getattr(item.used_by, "phone", "") if item.used_by else "—"
        used_at_str = item.used_at.strftime("%Y-%m-%d %I:%M %p") if item.used_at else "—"
        created_at_str = item.created_at.strftime("%Y-%m-%d %I:%M %p") if item.created_at else "—"

        row_data = [
            idx,
            item.code,
            course_name,
            status_text,
            student_name,
            student_phone,
            used_at_str,
            created_at_str,
        ]
        ws.append(row_data)

        # تنسيق الخلايا في الصف
        ws.cell(row=row_num, column=1).alignment = align_center
        ws.cell(row=row_num, column=1).font = regular_font

        # خلية الكود
        code_cell = ws.cell(row=row_num, column=2)
        code_cell.alignment = align_center
        code_cell.font = code_font

        # خلية اسم الكورس
        ws.cell(row=row_num, column=3).alignment = align_right
        ws.cell(row=row_num, column=3).font = regular_font

        # خلية الحالة
        status_cell = ws.cell(row=row_num, column=4)
        status_cell.alignment = align_center
        if item.is_used:
            status_cell.fill = used_fill
            status_cell.font = used_font
        else:
            status_cell.fill = available_fill
            status_cell.font = available_font

        # باقي الخلايا
        for col_idx in (5, 6, 7, 8):
            c = ws.cell(row=row_num, column=col_idx)
            c.alignment = align_center if col_idx != 5 else align_right
            c.font = regular_font

        # حدود الخلايا
        for col_idx in range(1, len(headers) + 1):
            ws.cell(row=row_num, column=col_idx).border = thin_border

    # ضبط العرض التلقائي للأعمدة
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val = str(cell.value or "")
            max_len = max(max_len, len(val))
        ws.column_dimensions[col_letter].width = max(max_len + 4, 14)

    # حفظ في الذاكرة وإرجاع كملف للتحميل
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    response = HttpResponse(
        buffer.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    import urllib.parse
    ascii_filename = "activation_codes.xlsx"
    encoded_filename = urllib.parse.quote(filename)
    response["Content-Disposition"] = f"attachment; filename=\"{ascii_filename}\"; filename*=UTF-8''{encoded_filename}"
    return response
