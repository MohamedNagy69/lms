"""Services package for academy app."""
