import re


def normalize_answer_text(text: str) -> str:
    """
    تنظيف وتوحيد النص للمقارنة الدقيقة:
    1. تحويل الأرقام العربية والفارسية إلى أرقام إنجليزية (1, 2, 3...)
    2. إزالة التشكيل والتنوين والتطويل (ـ)
    3. توحيد أشكال الهمزات والألف (أ, إ, آ, ٱ -> ا)
    4. توحيد التاء المربوطة والهاء (ة -> ه)
    5. توحيد الألف المقصورة والياء (ى -> ي)
    6. إزالة علامات الترقيم والرموز
    7. تحويل الحروف الإنجليزية إلى أحرف صغيرة (lowercase)
    8. إزالة المسافات الزائدة في البداية والنهاية والوسط
    """
    if not text:
        return ""

    # تحويل الأرقام المشرقية والفارسية إلى أرقام لاتينية
    eastern_digits = "٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹"
    western_digits = "01234567890123456789"
    trans_table = str.maketrans(eastern_digits, western_digits)
    text = text.translate(trans_table)

    # إزالة حركات التشكيل (الفتحة، الضمة، الكسرة، السكون، التنوين...) والتطويل
    text = re.sub(r"[\u064B-\u0652\u0670\u0640]", "", text)

    # توحيد أشكال الألف والهمزات
    text = re.sub(r"[إأآٱ]", "ا", text)

    # توحيد التاء المربوطة والألف المقصورة
    text = text.replace("ة", "ه").replace("ى", "ي")

    # تحويل الإنجليزي لحروف صغيرة
    text = text.lower()

    # استبدال علامات الترقيم بمسافة
    text = re.sub(r"[.,!?:;\"'()\[\]{}،؟؛\-_/\\|]", " ", text)

    # توحيد المسافات
    text = re.sub(r"\s+", " ", text).strip()

    return text


def check_essay_answer(student_answer: str, model_answer: str) -> bool:
    """
    التحقق مما إذا كانت إجابة الطالب مطابقة للنموذج أو لأحد البدائل المقبولة.
    يمكن للمعلم فصل البدائل بـ:
    - سطر جديد
    - علامة /
    - علامة فاصلة , أو ،
    - علامة فاصلة منقوطة ; أو ؛
    """
    if not student_answer or not model_answer:
        return False

    norm_student = normalize_answer_text(student_answer)
    if not norm_student:
        return False

    # تقسيم الإجابة النموذجية إلى بدائل مقبولة
    raw_alternatives = re.split(r"[\n\r/؛;,،]+", model_answer)
    alternatives = []
    for raw_alt in raw_alternatives:
        cleaned = normalize_answer_text(raw_alt)
        if cleaned and cleaned not in alternatives:
            alternatives.append(cleaned)

    # إضافة النص الكامل من الإجابة النموذجية كبديل أيضاً إن لم يكن موجوداً
    full_cleaned = normalize_answer_text(model_answer)
    if full_cleaned and full_cleaned not in alternatives:
        alternatives.append(full_cleaned)

    for alt in alternatives:
        # تطابق تام بعد التوحيد
        if norm_student == alt:
            return True

        # إذا كانت الإجابة عبارة نصية وليست مجرد رقم، والبديل موجود ككلمة/عبارة كاملة داخل إجابة الطالب
        if not alt.isdigit() and len(alt) >= 3:
            pattern = rf"(?:^|\s){re.escape(alt)}(?:$|\s)"
            if re.search(pattern, norm_student):
                return True

    return False
