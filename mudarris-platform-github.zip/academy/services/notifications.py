"""
خدمات الإشعارات والبريد الإلكتروني للطلاب وأولياء الأمور.
"""

import logging
import threading

from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.html import strip_tags

logger = logging.getLogger(__name__)


def _send_email_worker(subject, html_content, text_content, recipient_email):
    """إرسال البريد الإلكتروني في خيط خلفي بأمان دون تعطيل استجابة المتصفح."""
    try:
        from_email = getattr(settings, "DEFAULT_FROM_EMAIL", None) or "منصة الأستاذ <noreply@mudarris.com>"
        msg = EmailMultiAlternatives(
            subject=subject,
            body=text_content,
            from_email=from_email,
            to=[recipient_email],
        )
        msg.attach_alternative(html_content, "text/html")
        msg.send(fail_silently=False)
        print(f"[✅ البريد الإلكتروني] تم إرسال نتيجة الامتحان بنجاح إلى: {recipient_email}")
        logger.info(f"Exam result email successfully sent to: {recipient_email}")
    except Exception as e:
        print(f"[❌ خطأ في إرسال البريد الإلكتروني] إلى {recipient_email}: {e}")
        logger.error(f"Failed to send exam result email to {recipient_email}: {e}", exc_info=True)


def send_exam_result_emails(attempt, request=None):
    """
    إرسال تقرير نتيجة الامتحان فورياً للأب والأم والطالب فور انتهاء الامتحان.
    """
    student = attempt.student
    exam = attempt.exam
    course = exam.course

    result_url = None
    if request:
        try:
            result_url = request.build_absolute_uri(
                reverse("academy:attempt_result", kwargs={"pk": attempt.pk})
            )
        except Exception:
            pass

    site_info = getattr(settings, "SITE_INFO", {
        "site_name": "منصة الأستاذ",
        "teacher_name": "د. ناجي الغيطي",
        "subject": "اللغة العربية",
        "phone": "",
        "whatsapp": "",
        "email": "",
    })

    # قائمة المستلمين الثلاثة: الأب، الأم، الطالب
    recipients = []

    # 1. إيميل الأب
    if student.father_email and student.father_email.strip():
        recipients.append({
            "email": student.father_email.strip(),
            "type": "father",
            "title_prefix": "ولي أمر الطالب (الأب)",
        })

    # 2. إيميل الأم
    if student.mother_email and student.mother_email.strip():
        recipients.append({
            "email": student.mother_email.strip(),
            "type": "mother",
            "title_prefix": "ولية أمر الطالب (الأم)",
        })

    # 3. إيميل الطالب
    if student.email and student.email.strip():
        recipients.append({
            "email": student.email.strip(),
            "type": "student",
            "title_prefix": "الطالب",
        })

    if not recipients:
        logger.info(f"No email addresses configured for student: {student.username} (Attempt: {attempt.pk})")
        return False

    status_str = "ناجح ✅" if attempt.is_passed else "يحتاج لمراجعة ⚠️"
    subject = f"نتيجة امتحان: {exam.title} — الطالب {student.display_name} ({status_str})"

    for r in recipients:
        context = {
            "recipient_type": r["type"],
            "recipient_title": r["title_prefix"],
            "student": student,
            "exam": exam,
            "course": course,
            "attempt": attempt,
            "score": attempt.score,
            "max_score": attempt.max_score,
            "percent": attempt.percent,
            "is_passed": attempt.is_passed,
            "pass_percent": exam.pass_percent,
            "infractions_count": attempt.infractions_count,
            "submitted_at": attempt.submitted_at,
            "result_url": result_url,
            "site_info": site_info,
        }

        try:
            html_content = render_to_string("emails/exam_result.html", context)
            text_content = strip_tags(html_content)

            thread = threading.Thread(
                target=_send_email_worker,
                args=(subject, html_content, text_content, r["email"]),
                daemon=True,
            )
            thread.start()
        except Exception as e:
            logger.error(f"Error preparing email for {r['email']}: {e}", exc_info=True)

    return True


def send_automatic_exam_results(attempt, request=None):
    """
    إرسال تقرير نتيجة الامتحان تلقائياً في الخلفية لولي الأمر فور تسليم الطالب للامتحان.
    يتحقق أولاً من تفعيل المعلم لخيار (auto_send_result).
    """
    exam = attempt.exam
    student = attempt.student

    # التحقق من سويتش المعلم
    if not getattr(exam, "auto_send_result", True):
        print(f"[ℹ️ إرسال النتائج] المعلم قام بتعطيل خيار الإرسال التلقائي للامتحان «{exam.title}». لن يتم الإرسال.")
        return False

    print(f"\n[🚀 بدء الإرسال التلقائي] جاري إرسال نتيجة امتحان «{exam.title}» للطالب «{student.display_name}»...")

    # 1. إرسال عبر الواتساب الآلي (إذا توفرت بوابة واتساب مفعلة)
    try:
        from .whatsapp import send_automatic_whatsapp_result
        send_automatic_whatsapp_result(attempt, request=request)
    except Exception as e:
        logger.error(f"Error in automatic whatsapp dispatch: {e}", exc_info=True)

    # 2. إرسال عبر البريد الإلكتروني
    try:
        send_exam_result_emails(attempt, request=request)
    except Exception as e:
        logger.error(f"Error in automatic email dispatch: {e}", exc_info=True)

    # 3. إرسال عبر بوت التيليجرام الرسمي (Telegram Bot)
    try:
        from .telegram import send_automatic_telegram_results
        send_automatic_telegram_results(attempt, request=request)
    except Exception as e:
        logger.error(f"Error in automatic telegram dispatch: {e}", exc_info=True)

    return True
