"""
خدمة بوت التيليجرام الرسمي (Telegram Bot API)
لإرسال نتائج الامتحانات وتقارير المراقبة والإنذارات لأولياء الأمور والمعلم تلقائياً.
"""

import json
import logging
import threading
import urllib.parse
import urllib.request
from django.conf import settings
from django.urls import reverse
from django.utils import timezone

logger = logging.getLogger(__name__)


def get_telegram_token() -> str:
    return getattr(
        settings,
        "TELEGRAM_BOT_TOKEN",
        "8761069661:AAHtaCK05vGyQdlvEU_yU-l286nwT9zAWWU",
    ).strip()


def get_telegram_bot_username() -> str:
    return getattr(settings, "TELEGRAM_BOT_USERNAME", "ElGheityExamBot").strip()


def send_telegram_message(chat_id: str, text: str, reply_markup: dict = None, parse_mode: str = "HTML") -> bool:
    """
    إرسال رسالة تيليجرام برمجياً لأي Chat ID عبر Telegram Bot API الرسمي.
    """
    if not chat_id:
        return False

    token = get_telegram_token()
    if not token:
        logger.warning("Telegram Bot Token is not configured.")
        return False

    endpoint = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": str(chat_id).strip(),
        "text": text,
        "parse_mode": parse_mode,
        "disable_web_page_preview": False,
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            endpoint,
            data=data,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "Mudarris-Telegram-Bot/1.0",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp_data = json.loads(resp.read().decode("utf-8"))
            if resp_data.get("ok"):
                logger.info(f"Telegram message sent to {chat_id} successfully.")
                print(f"[✅ تيليجرام] تم إرسال الرسالة بنجاح إلى Chat ID: {chat_id}")
                return True
            else:
                logger.error(f"Telegram API returned error: {resp_data}")
                return False
    except Exception as e:
        logger.error(f"Error sending telegram message to {chat_id}: {e}")
        print(f"[❌ خطأ تيليجرام] فشل الإرسال إلى {chat_id}: {e}")
        return False


def build_telegram_exam_result_message(attempt, recipient_role: str = "father", request=None) -> tuple[str, dict]:
    """
    توليد نص التقرير المفصل والأزرار التفاعلية الموجهة لتيليجرام بصيغة HTML.
    """
    student = attempt.student
    exam = attempt.exam
    course = exam.course

    result_url = ""
    if request:
        try:
            result_url = request.build_absolute_uri(
                reverse("academy:attempt_result", kwargs={"pk": attempt.pk})
            )
        except Exception:
            pass
    if not result_url:
        result_url = f"http://127.0.0.1:8000/attempt/{attempt.pk}/result/"

    site_info = getattr(settings, "SITE_INFO", {
        "site_name": "منصة الغيطي",
        "teacher_name": "د. ناجي الغيطي",
        "subject": "اللغة العربية IGCSE",
        "phone": "+201005209526",
    })

    if recipient_role == "father":
        role_header = "حضرة الفاضل ولي أمر الطالب (الأب المحترم) 🌹"
    elif recipient_role == "mother":
        role_header = "حضرة الفاضلة ولية أمر الطالب (الأم الكريمة) 🌹"
    elif recipient_role == "teacher":
        role_header = "🔔 إشعار للمعلم — تم إنهاء جلسة امتحان جديدة"
    else:
        role_header = "أهلاً بك يا بطل 🌟"

    eval_status = "اجتياز بنجاح ممتاز 🎉" if attempt.is_passed else "يحتاج لمزيد من المتابعة والتركيز ⚠️"

    if attempt.infractions_count == 0:
        infractions_text = "0 إنذارات (التزام تام بالتعليمات ✅)"
    else:
        infractions_text = f"تم رصد {attempt.infractions_count} إنذار أمني أثناء الامتحان ⚠️"

    submitted_str = attempt.submitted_at.strftime("%Y-%m-%d %H:%M") if attempt.submitted_at else ""

    text = (
        f"🎓 <b>{site_info.get('site_name', 'المنصة')} — تقرير نتيجة امتحان</b>\n"
        f"👨‍🏫 <b>المدرس:</b> {site_info.get('teacher_name', '')}\n\n"
        f"<b>{role_header}</b>\n\n"
        f"نحيطكم علماً بنتيجة أداء الطالب: <b>{student.display_name}</b>\n"
        f"📚 <b>المادة:</b> {course.title}\n"
        f"📝 <b>عنوان الامتحان:</b> {exam.title}\n\n"
        f"📊 <b>تفاصيل النتيجة:</b>\n"
        f"• الدرجة المحققة: <b>{attempt.score} من {attempt.max_score} درجة</b>\n"
        f"• النسبة المئوية: <b>{attempt.percent:.0f}%</b>\n"
        f"• التقييم: <b>{eval_status}</b>\n"
        f"• نسبة النجاح المطلوبة: {exam.pass_percent}%\n"
        f"• سجل المراقبة والنزاهة: <b>{infractions_text}</b>\n"
        f"• وقت التسليم: <code>{submitted_str}</code>\n\n"
        f"🔍 يمكنك الضغط على الزر أدناه لمراجعة ورقة الإجابات والتصحيح النموذجي بالتفصيل:\n"
    )

    reply_markup = {
        "inline_keyboard": [
            [
                {
                    "text": "🔍 مراجعة ورقة الإجابات والتصحيح",
                    "url": result_url,
                }
            ]
        ]
    }

    return text, reply_markup


def _send_telegram_worker(chat_id, text, reply_markup):
    """عامل الإرسال في خيط خلفي."""
    send_telegram_message(chat_id, text, reply_markup=reply_markup)


def send_automatic_telegram_results(attempt, request=None) -> bool:
    """
    إرسال النتيجة تلقائياً في الخلفية لجميع معرفات التيليجرام المسجلة:
    - الأب
    - الأم
    - الطالب
    - شات أو قناة المدرس
    """
    student = attempt.student
    threads = []
    sent_any = False

    # 1. إرسال لتيليجرام الأب
    if getattr(student, "father_telegram_chat_id", None):
        text, markup = build_telegram_exam_result_message(attempt, recipient_role="father", request=request)
        t = threading.Thread(
            target=_send_telegram_worker,
            args=(student.father_telegram_chat_id, text, markup),
            daemon=True,
        )
        threads.append(t)
        sent_any = True

    # 2. إرسال لتيليجرام الأم
    if getattr(student, "mother_telegram_chat_id", None):
        text, markup = build_telegram_exam_result_message(attempt, recipient_role="mother", request=request)
        t = threading.Thread(
            target=_send_telegram_worker,
            args=(student.mother_telegram_chat_id, text, markup),
            daemon=True,
        )
        threads.append(t)
        sent_any = True

    # 3. إرسال لتيليجرام الطالب
    if getattr(student, "telegram_chat_id", None):
        text, markup = build_telegram_exam_result_message(attempt, recipient_role="student", request=request)
        t = threading.Thread(
            target=_send_telegram_worker,
            args=(student.telegram_chat_id, text, markup),
            daemon=True,
        )
        threads.append(t)
        sent_any = True

    # 4. إرسال لشات أو قناة المعلم الإدارية
    teacher_chat_id = getattr(settings, "TELEGRAM_TEACHER_CHAT_ID", "").strip()
    if teacher_chat_id:
        text, markup = build_telegram_exam_result_message(attempt, recipient_role="teacher", request=request)
        t = threading.Thread(
            target=_send_telegram_worker,
            args=(teacher_chat_id, text, markup),
            daemon=True,
        )
        threads.append(t)
        sent_any = True

    for t in threads:
        t.start()

    return sent_any


def link_telegram_chat(user, chat_id: str, role: str = "father") -> str:
    """
    ربط الـ Chat ID بالمستخدم في قاعدة البيانات وتحديث الحقل المناسب.
    """
    chat_id = str(chat_id).strip()
    if role == "father":
        user.father_telegram_chat_id = chat_id
        user.save(update_fields=["father_telegram_chat_id"])
        return f"تم ربط حسابك كـ (ولي أمر الطالب - الأب) للطالب {user.display_name} بنجاح ✅"
    elif role == "mother":
        user.mother_telegram_chat_id = chat_id
        user.save(update_fields=["mother_telegram_chat_id"])
        return f"تم ربط حسابك كـ (ولية أمر الطالب - الأم) للطالب {user.display_name} بنجاح ✅"
    elif role == "student":
        user.telegram_chat_id = chat_id
        user.save(update_fields=["telegram_chat_id"])
        return f"أهلاً بك يا بطل! تم ربط حسابك الشخصي {user.display_name} بنجاح ✅"
    return "تم استلام الطلب بنجاح."


def handle_telegram_start_command(chat_id: str, text: str, user_info: dict = None) -> bool:
    """
    معالجة رسائل /start القادمة من البوت وربط الحساب تلقائياً عند الضغط على رابط الربط.
    مثال: /start father_15 أو /start mother_15 أو /start student_15
    """
    from academy.models import User

    parts = text.strip().split()
    if len(parts) >= 2:
        payload = parts[1]
        try:
            role, user_id_str = payload.split("_", 1)
            target_user = User.objects.filter(pk=int(user_id_str)).first()
            if target_user:
                msg = link_telegram_chat(target_user, chat_id, role=role)
                welcome_text = (
                    f"🎉 <b>أهلاً بك في بوت منصة الغيطي الرسمي!</b>\n\n"
                    f"{msg}\n\n"
                    f"من الآن فصاعداً، ستصلك هنا تقارير نتائج جميع الامتحانات وسجل المراقبة والإنذارات فور انتهائها تلقائياً وبشكل فوري 🚀"
                )
                send_telegram_message(chat_id, welcome_text)
                return True
        except Exception as e:
            logger.error(f"Error handling telegram start payload '{payload}': {e}")

    # إذا كانت /start عادية بدون كود
    help_text = (
        f"👋 <b>مرحباً بك في بوت منصة الغيطي الرسمي!</b>\n\n"
        f"معرف الشات الخاص بك (Chat ID) هو:\n"
        f"<code>{chat_id}</code>\n\n"
        f"يمكنك نسخ هذا الرقم ووضعه في صفحة إعدادات الحساب بالمنصة لربط الإشعارات الفورية لنتائج الامتحانات 🎓"
    )
    send_telegram_message(chat_id, help_text)
    return True


_POLLER_STARTED = False
_LAST_UPDATE_ID = 0


def poll_telegram_updates_once():
    """جلب التحديثات الجديدة من Telegram ومعالجتها فورياً."""
    global _LAST_UPDATE_ID
    token = get_telegram_token()
    if not token:
        return

    url = f"https://api.telegram.org/bot{token}/getUpdates?offset={_LAST_UPDATE_ID + 1}&timeout=2"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mudarris-Telegram-Bot"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if data.get("ok"):
                for update in data.get("result", []):
                    _LAST_UPDATE_ID = max(_LAST_UPDATE_ID, update.get("update_id", 0))
                    msg = update.get("message") or {}
                    chat = msg.get("chat") or {}
                    chat_id = str(chat.get("id", ""))
                    text = msg.get("text", "")
                    if chat_id and text:
                        if text.startswith("/start"):
                            handle_telegram_start_command(chat_id, text, user_info=msg.get("from"))
    except Exception as e:
        # إخفاء أخطاء انتهاء المهلة المعتادة أثناء السحب
        pass


def start_telegram_poller_background():
    """تشغيل خيط خلفي يقوم بالاستماع للتحديثات ومزامنة أرقام الـ Chat ID."""
    global _POLLER_STARTED
    if _POLLER_STARTED:
        return
    _POLLER_STARTED = True

    import time

    def _loop():
        while True:
            try:
                poll_telegram_updates_once()
            except Exception:
                pass
            time.sleep(3)

    t = threading.Thread(target=_loop, daemon=True)
    t.start()
    logger.info("Telegram background poller started successfully.")
