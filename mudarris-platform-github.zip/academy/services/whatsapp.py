"""
خدمة تجهيز وإرسال نتائج الامتحانات عبر الواتساب (WhatsApp).
"""

import logging
import re
import threading
import urllib.parse
from django.conf import settings
from django.urls import reverse

logger = logging.getLogger(__name__)


def clean_phone_for_whatsapp(phone: str) -> str:
    """تنظيف وتنسيق رقم الهاتف ليتوافق مع رابط wa.me الدولي."""
    if not phone:
        return ""
    # استخراج الأرقام فقط
    digits = re.sub(r"\D", "", str(phone))
    if not digits:
        return ""

    # إزالة الأصفار الدولية في البداية مثل 0020
    if digits.startswith("00"):
        digits = digits[2:]

    # الأرقام المصرية التي تبدأ بـ 01 (11 رقماً) تحول إلى 201...
    if len(digits) == 11 and digits.startswith("01"):
        digits = "2" + digits
    elif len(digits) == 10 and digits.startswith("1"):
        digits = "20" + digits

    return digits


def build_whatsapp_result_message(attempt, recipient_role: str = "father", request=None) -> str:
    """توليد نص رسالة الواتساب المنسقة باحترافية وتوافق فائق مع ماركداون الواتساب."""
    student = attempt.student
    exam = attempt.exam
    course = exam.course

    result_url = ""
    if request:
        try:
            result_url = request.build_absolute_uri(
                reverse("academy:attempt_result", kwargs={"pk": attempt.pk})
            )
        except Exception:
            pass
    if not result_url:
        base_url = getattr(settings, "SITE_URL", "http://127.0.0.1:8000").rstrip("/")
        result_url = f"{base_url}/attempt/{attempt.pk}/result/"

    site_info = getattr(settings, "SITE_INFO", {
        "site_name": "منصة الغيطي",
        "teacher_name": "د. ناجي الغيطي",
        "subject": "اللغة العربية IGCSE",
        "phone": "+201005209526",
        "whatsapp": "201005209526",
    })

    # 1. ترويسة المنصة وبيانات التواصل
    site_title = site_info.get("site_name", "منصة الغيطي")
    teacher_name = site_info.get("teacher_name", "د. ناجي الغيطي")
    subject_name = site_info.get("subject", "اللغة العربية IGCSE")
    teacher_phone = site_info.get("phone", "+201005209526")
    teacher_wa = site_info.get("whatsapp", "201005209526")

    divider = "━━━━━━━━━━━━━━━━━━━━━"

    # 2. تحية مخصصة ومحترمة لكل من الأب والأم
    if recipient_role == "father":
        greeting = (
            "السلام عليكم ورحمة الله وبركاته 🌹\n"
            "حضرة الفاضل ولي أمر الطالب (والد الطالب المحترم)،\n\n"
            "يسرّنا موافاة سيادتكم بتقرير نتيجة الاختبار الإلكتروني الأخير:"
        )
    elif recipient_role == "mother":
        greeting = (
            "السلام عليكم ورحمة الله وبركاته 🌹\n"
            "حضرة الفاضلة ولية أمر الطالب (والدة الطالب الكريمة) 🌹\n\n"
            "يسرّنا موافاة سيادتكِ بتقرير نتيجة الاختبار الإلكتروني الأخير:"
        )
    else:
        greeting = (
            "أهلاً بك يا بطل 🌟\n"
            f"عزيزنا الطالب المتميز: *{student.display_name}*،\n\n"
            "إليك تقرير نتيجتك في الاختبار الإلكتروني الأخير:"
        )

    # 3. تقييم النتيجة وتحديد حالة الاجتياز
    if attempt.percent >= 90:
        eval_status = "ممتاز بنجاح فائق وتفوق 🌟"
    elif attempt.percent >= 75:
        eval_status = "جيد جداً بنجاح مميز 👏"
    elif attempt.is_passed:
        eval_status = "اجتياز بنجاح جيد ✅"
    else:
        eval_status = "يحتاج لمزيد من المتابعة والتركيز ⚠️"

    pass_badge = "ناجح ومجتاز للاختبار بنجاح ✅" if attempt.is_passed else "لم يحقق نسبة الاجتياز المطلوبة ❌"

    # 4. تاريخ ووقت التسليم
    if attempt.submitted_at:
        date_str = attempt.submitted_at.strftime("%d/%m/%Y (%I:%M %p)").replace("AM", "ص").replace("PM", "م")
    else:
        date_str = "مكتمل الآن"

    # 5. الصف الدراسي إن وجد
    grade_name = student.grade.name if getattr(student, "grade", None) else ""

    # 6. سجل المراقبة والإنذارات
    if attempt.infractions_count == 0:
        infractions_text = "التزام تام بالتعليمات ونزاهة الاختبار (0 إنذارات) ✅"
    else:
        infractions_text = f"تم رصد {attempt.infractions_count} إنذار أمني أثناء الاختبار ⚠️"

    # 7. بطاقة بيانات الطالب والاختبار
    student_info_lines = [
        f"▫️ *اسم الطالب:* {student.display_name}",
    ]
    if grade_name:
        student_info_lines.append(f"▫️ *الصف الدراسي:* {grade_name}")
    student_info_lines.extend([
        f"▫️ *المادة:* {course.title}",
        f"▫️ *عنوان الاختبار:* {exam.title}",
        f"▫️ *تاريخ الإجراء:* {date_str}",
    ])
    student_info_block = "\n".join(student_info_lines)

    # 8. بطاقة النتيجة والدرجات
    score_info_block = (
        f"▫️ *الدرجة المستحقة:* {attempt.score} من أصل {attempt.max_score}\n"
        f"▫️ *النسبة المئوية:* {attempt.percent:.0f}%\n"
        f"▫️ *حالة النتيجة:* {pass_badge}\n"
        f"▫️ *التقدير العام:* {eval_status}\n"
        f"▫️ *نسبة النجاح المطلوبة:* {exam.pass_percent}%"
    )

    msg = (
        f"🎓 *{site_title} التعليمية*\n"
        f"👨‍🏫 *{teacher_name} — {subject_name}*\n"
        f"{divider}\n\n"
        f"{greeting}\n\n"
        f"📋 *بيانات الطالب والاختبار:*\n"
        f"{student_info_block}\n\n"
        f"📊 *بطاقة النتيجة والتقييم:*\n"
        f"{score_info_block}\n\n"
        f"🛡️ *انضباط جلسة الامتحان:*\n"
        f"▫️ *الحالة:* {infractions_text}\n\n"
        f"{divider}\n"
        f"🔍 *رابط ورقة الإجابة والتصحيح بالتفصيل:*\n"
        f"{result_url}\n"
        f"{divider}\n\n"
        f"مع أطيب تمنياتنا بدوام التفوق والتميز الدراسي 🌟\n"
        f"📞 *للاستفسار والمتابعة:* {teacher_phone}\n"
        f"💬 *واتساب مباشر:* https://wa.me/{teacher_wa}"
    )
    return msg


def get_whatsapp_buttons_data(attempt, request=None) -> dict:
    """
    تجهيز روابط الواتساب المباشرة (wa.me) لكل من الأب والأم والطالب.
    """
    student = attempt.student

    father_raw_phone = student.parent_phone or ""
    mother_raw_phone = getattr(student, "mother_phone", "") or ""
    student_raw_phone = student.phone or ""

    father_clean = clean_phone_for_whatsapp(father_raw_phone)
    mother_clean = clean_phone_for_whatsapp(mother_raw_phone)
    student_clean = clean_phone_for_whatsapp(student_raw_phone)

    father_msg = build_whatsapp_result_message(attempt, recipient_role="father", request=request)
    mother_msg = build_whatsapp_result_message(attempt, recipient_role="mother", request=request)
    student_msg = build_whatsapp_result_message(attempt, recipient_role="student", request=request)

    father_url = f"https://wa.me/{father_clean}?text={urllib.parse.quote(father_msg)}" if father_clean else ""
    mother_url = f"https://wa.me/{mother_clean}?text={urllib.parse.quote(mother_msg)}" if mother_clean else ""
    student_url = f"https://wa.me/{student_clean}?text={urllib.parse.quote(student_msg)}" if student_clean else ""

    return {
        "father": {
            "title": "واتساب الأب (ولي الأمر)",
            "raw_phone": father_raw_phone,
            "clean_phone": father_clean,
            "has_phone": bool(father_clean),
            "url": father_url,
            "message": father_msg,
        },
        "mother": {
            "title": "واتساب الأم",
            "raw_phone": mother_raw_phone,
            "clean_phone": mother_clean,
            "has_phone": bool(mother_clean),
            "url": mother_url,
            "message": mother_msg,
        },
        "student": {
            "title": "واتساب الطالب",
            "raw_phone": student_raw_phone,
            "clean_phone": student_clean,
            "has_phone": bool(student_clean),
            "url": student_url,
            "message": student_msg,
        },
    }


def send_whatsapp_message_via_api(phone: str, message: str) -> bool:
    """
    إرسال رسالة واتساب برمجياً عبر API في الخلفية.
    يدعم:
    - UltraMsg (api.ultramsg.com)
    - Generic Webhook (POST JSON)
    """
    import json
    import urllib.request
    import urllib.parse

    clean_phone = clean_phone_for_whatsapp(phone)
    if not clean_phone:
        return False

    api_url = getattr(settings, "WHATSAPP_API_URL", "").strip()
    instance_id = getattr(settings, "ULTRAMSG_INSTANCE_ID", "").strip()
    token = getattr(settings, "ULTRAMSG_TOKEN", "").strip()

    # 1. إذا تم ضبط UltraMsg
    if instance_id and token:
        endpoint = f"https://api.ultramsg.com/{instance_id}/messages/chat"
        payload = {
            "token": token,
            "to": clean_phone,
            "body": message,
        }
        data = urllib.parse.urlencode(payload).encode("utf-8")
        req = urllib.request.Request(
            endpoint,
            data=data,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "Mudarris-Platform/1.0",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                resp_data = resp.read().decode("utf-8")
                logger.info(f"UltraMsg WhatsApp sent to {clean_phone}: {resp_data}")
                print(f"[✅ WhatsApp API] تم إرسال رسالة الواتساب تلقائياً بنجاح إلى: {clean_phone}")
                return True
        except Exception as e:
            logger.error(f"UltraMsg WhatsApp send error to {clean_phone}: {e}")
            print(f"[❌ خطأ WhatsApp API] فشل الإرسال التلقائي للواتساب إلى {clean_phone}: {e}")
            return False

    # 2. إذا تم ضبط Webhook مخصص
    elif api_url:
        payload = json.dumps({"phone": clean_phone, "message": message}).encode("utf-8")
        req = urllib.request.Request(
            api_url,
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                logger.info(f"Custom WhatsApp API sent to {clean_phone}: {resp.status}")
                print(f"[✅ WhatsApp Webhook] تم إرسال الرسالة إلى {clean_phone}")
                return True
        except Exception as e:
            logger.error(f"Custom WhatsApp API send error to {clean_phone}: {e}")
            print(f"[❌ خطأ WhatsApp Webhook] إلى {clean_phone}: {e}")
            return False

    return False


def send_automatic_whatsapp_result(attempt, request=None):
    """
    إرسال النتيجة تلقائياً لواتساب الأب والأم في خيوط خلفية إذا تم تفعيل بوابة الواتساب.
    """
    student = attempt.student
    threads = []

    # إرسال للأب
    if student.parent_phone:
        father_msg = build_whatsapp_result_message(attempt, recipient_role="father", request=request)
        t = threading.Thread(
            target=send_whatsapp_message_via_api,
            args=(student.parent_phone, father_msg),
            daemon=True,
        )
        threads.append(t)

    # إرسال للأم
    if getattr(student, "mother_phone", None):
        mother_msg = build_whatsapp_result_message(attempt, recipient_role="mother", request=request)
        t = threading.Thread(
            target=send_whatsapp_message_via_api,
            args=(student.mother_phone, mother_msg),
            daemon=True,
        )
        threads.append(t)

    for t in threads:
        t.start()
