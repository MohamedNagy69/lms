"""خدمة التعرف على الأجهزة وإدارة الحد الأقصى لجهازين مع الخروج التلقائي."""

import uuid
from django.contrib.sessions.models import Session
from django.utils import timezone
from ..models import StudentDevice

DEVICE_COOKIE_NAME = "mudarris_device_id"
DEVICE_COOKIE_MAX_AGE = 365 * 24 * 60 * 60  # سنة كاملة


def parse_device_name(user_agent):
    """استخراج نوع الجهاز والمتصفح بصيغة عربية واضحة ومقروءة."""
    ua = (user_agent or "").lower()

    # نظام التشغيل
    if "iphone" in ua:
        os_name = "iPhone"
    elif "ipad" in ua:
        os_name = "iPad"
    elif "android" in ua:
        os_name = "Android"
    elif "windows nt 10" in ua or "windows nt 11" in ua or "windows" in ua:
        os_name = "Windows"
    elif "macintosh" in ua or "mac os" in ua:
        os_name = "Mac"
    elif "linux" in ua:
        os_name = "Linux"
    else:
        os_name = "جهاز غير معروف"

    # المتصفح
    if "edg" in ua or "edge" in ua:
        browser_name = "Edge"
    elif "opr" in ua or "opera" in ua:
        browser_name = "Opera"
    elif "chrome" in ua and "crios" not in ua:
        browser_name = "Chrome"
    elif "firefox" in ua or "fxios" in ua:
        browser_name = "Firefox"
    elif "safari" in ua and "chrome" not in ua:
        browser_name = "Safari"
    else:
        browser_name = "المتصفح"

    return f"{browser_name} على {os_name}"


def get_or_create_device_id(request):
    """الحصول على معرّف الجهاز من الكوكيز أو حقل الفورم أو إنشاء معرّف جديد."""
    device_id = request.COOKIES.get(DEVICE_COOKIE_NAME, "").strip()
    if not device_id:
        device_id = request.POST.get("client_device_id", "").strip()
    if not device_id:
        device_id = uuid.uuid4().hex
        return device_id, True
    return device_id, False


def handle_student_device_login(student, request):
    """
    إدارة تسجيل دخول أجهزة الطالب:
    - الحد الأقصى المسموح به: جهازين نشطين في نفس الوقت.
    - عند الدخول من جهاز ثالث: الخروج التلقائي من الجهازين السابقين فوراً.
    - إرجاع: (device, logged_out_others)
    """
    device_id, _ = get_or_create_device_id(request)
    user_agent = request.META.get("HTTP_USER_AGENT", "")
    ip_address = request.META.get("REMOTE_ADDR", "")
    device_name = parse_device_name(user_agent)
    session_key = getattr(request.session, "session_key", "")

    # الأجهزة النشطة حالياً للطالب
    active_devices = list(
        StudentDevice.objects.filter(student=student, is_active=True).order_by("-last_login")
    )

    # 1. هل هذا الجهاز مسجل ونشط بالفعل؟
    matching_device = next((d for d in active_devices if d.device_id == device_id), None)
    if matching_device:
        matching_device.session_key = session_key
        matching_device.last_login = timezone.now()
        matching_device.ip_address = ip_address
        matching_device.device_name = device_name
        matching_device.is_active = True
        matching_device.save()
        return matching_device, False

    # 2. إذا كان جهازاً جديداً وعدد الأجهزة النشطة أقل من 2 (الجهاز 1 أو 2)
    if len(active_devices) < 2:
        device, _ = StudentDevice.objects.update_or_create(
            student=student,
            device_id=device_id,
            defaults={
                "device_name": device_name,
                "ip_address": ip_address,
                "user_agent": user_agent,
                "session_key": session_key,
                "last_login": timezone.now(),
                "is_active": True,
            },
        )
        return device, False

    # 3. إذا كان جهازاً جديداً وعدد الأجهزة النشطة = 2 (الدخول من جهاز ثالث)
    # نقوم بتسجيل الخروج التلقائي من الجهازين السابقين فوراً
    for old_device in active_devices:
        if old_device.session_key:
            try:
                Session.objects.filter(session_key=old_device.session_key).delete()
            except Exception:
                pass
        old_device.is_active = False
        old_device.session_key = ""
        old_device.save(update_fields=["is_active", "session_key"])

    # تسجيل الجهاز الجديد كجهاز وحيد نشط حالياً
    new_device, _ = StudentDevice.objects.update_or_create(
        student=student,
        device_id=device_id,
        defaults={
            "device_name": device_name,
            "ip_address": ip_address,
            "user_agent": user_agent,
            "session_key": session_key,
            "last_login": timezone.now(),
            "is_active": True,
        },
    )
    return new_device, True


def set_device_cookie(response, device_id):
    """تثبيت كوكي معرف الجهاز لمدة سنة كاملة."""
    response.set_cookie(
        DEVICE_COOKIE_NAME,
        device_id,
        max_age=DEVICE_COOKIE_MAX_AGE,
        httponly=False,  # لتمكين JavaScript من نسخ المعرف إلى localStorage للاحتياط
        samesite="Lax",
    )
    return response
