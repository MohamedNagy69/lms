import sys
from django.apps import AppConfig


class AcademyConfig(AppConfig):
    name = "academy"
    verbose_name = "المنصة التعليمية"

    def ready(self):
        if "runserver" in sys.argv:
            try:
                from .services.telegram import start_telegram_poller_background
                start_telegram_poller_background()
            except Exception:
                pass

