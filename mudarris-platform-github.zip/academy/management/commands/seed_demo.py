"""
أمر تعبئة المنصة ببيانات تجريبية:

    python manage.py seed_demo

بيمسح البيانات القديمة (غير حساب المدير) ويحط مدرس + طلبة + كورسات + امتحانات.
"""

import random
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from academy.models import (
    AccessCode,
    Announcement,
    Attachment,
    AttemptAnswer,
    Choice,
    ContactMessage,
    Course,
    Enrollment,
    Exam,
    ExamAttempt,
    Grade,
    Lecture,
    Lesson,
    LessonProgress,
    Question,
    Testimonial,
    User,
)

STUDENT_NAMES = [
    ("سيف", "الدين طارق"), ("ملك", "يوسف"), ("عمر", "الشاذلي"),
    ("مريم", "أحمد"), ("كريم", "مصطفى"), ("نور", "الهدى فاروق"),
    ("ياسين", "خالد"), ("جنى", "محمود"), ("حمزة", "إبراهيم"),
    ("فريدة", "أشرف"), ("علي", "حسن"), ("زينة", "عمرو"),
]

CITIES = ["القاهرة", "الجيزة", "الإسكندرية", "المنصورة", "دبي", "الرياض"]

VIDEO_IDS = ["aircAruvnKk", "kYB8IZa5AuE", "9vJRopau0g0", "ZM8ECpBuQYE", "p7bzE1E5PMY"]

COURSES = [
    {
        "title": "Cambridge OL — الورقة الأولى: القراءة والتعبير الموجه (0508)",
        "grade": 0,
        "emoji": "📖",
        "accent": "brand",
        "price": 350,
        "summary": "تغطية شاملة لأسئلة استيعاب المقروء، مهارات التلخيص، وقوالب التعبير الموجه (الخطاب والمقال والتقرير) مع تصحيح فردي.",
        "lectures": [
            {
                "title": "مهارات استيعاب المقروء والتلخيص",
                "lessons": [
                    ("استراتيجية استخراج الأفكار الرئيسية بدقة", 25),
                    ("فنيات إعادة الصياغة بدون نقل مباشر (Paraphrasing)", 30),
                    ("كتابة ملخص احترافي وفق معايير Mark Scheme", 28),
                ],
            },
            {
                "title": "التعبير الموجه (Directed Writing)",
                "lessons": [
                    ("قوالب كتابة المقال الإقناعي والتواصلي", 32),
                    ("فنيات الخطاب الرسمي وغير الرسمي والحوار", 27),
                    ("كتابة التقرير الصحفي والمقال الافتتاحي", 29),
                ],
            },
        ],
    },
    {
        "title": "Cambridge OL — الورقة الثانية: التعبير الإنشائي والسردي",
        "grade": 0,
        "emoji": "✍️",
        "accent": "emerald",
        "price": 350,
        "summary": "أسرار الحصول على الدرجة النهائية في القصة والوصف والنقاش، مع بنك المفردات والصور البلاغية الراقية.",
        "lectures": [
            {
                "title": "الكتابة السردية (القصة)",
                "lessons": [
                    ("بناء الحبكة والشخصيات وتصاعد الأحداث", 35),
                    ("توظيف الحوار الداخلي والخارجي في السرد", 26),
                    ("نهايات القصة المبتكرة وكيفية تجنب الابتذال", 24),
                ],
            },
            {
                "title": "الكتابة الوصفية والنقاشية",
                "lessons": [
                    ("الوصف الحسي وتوظيف الحواس الخمس في النص", 30),
                    ("بناء الحجة والمقابلة المنطقية في المقال النقاشي", 28),
                ],
            },
        ],
    },
    {
        "title": "Edexcel OL — المنهج الشامل وحل Past Papers (4AA1)",
        "grade": 2,
        "emoji": "🎯",
        "accent": "amber",
        "price": 400,
        "summary": "شرح وتحليل النصوص الأدبية، مهارات القراءة والنحو والإملاء، وحل وتصحيح امتحانات السنوات السابقة.",
        "lectures": [
            {
                "title": "تحليل النصوص الأدبية والأسئلة المقالية",
                "lessons": [
                    ("تحليل النص النثري والشعري واستخراج الدلالات", 33),
                    ("الإجابة النموذجية على أسئلة المقارنة بين نصين", 35),
                ],
            },
            {
                "title": "قواعد النحو وتطبيقات الإملاء لـ Edexcel",
                "lessons": [
                    ("أهم القواعد النحوية المتكررة في امتحانات إيديكسل", 28),
                    ("علاج الأخطاء الإملائية الشائعة وعلامات الترقيم", 22),
                ],
            },
        ],
    },
    {
        "title": "Cambridge & Edexcel AL — المستوى المتقدم والأدب العربي",
        "grade": 1,
        "emoji": "🏛️",
        "accent": "rose",
        "price": 500,
        "summary": "دراسة متعمقة للنصوص الأدبية المقررة، مناهج النقد الأدبي، وكتابة المقالات الموسعة لطلاب A-Level.",
        "lectures": [
            {
                "title": "الدراسات النقدية وتحليل الرواية والمسرحية",
                "lessons": [
                    ("منهجية تحليل العمل الأدبي والأبعاد النفسية والاجتماعية", 42),
                    ("تحليل القصائد الشعرية وعناصر البلاغة المتقدمة", 38),
                ],
            },
            {
                "title": "المقال النقدي الموسع",
                "lessons": [
                    ("هيكلة المقال الأكاديمي والتوثيق والتحليل المقارن", 45),
                    ("نماذج مقالات حاصلة على A* مع تعليقات الممتحنين", 50),
                ],
            },
        ],
    },
    {
        "title": "كورس تأسيسي مجاني: مهارات الإعراب والبلاغة لـ IGCSE",
        "grade": 0,
        "emoji": "📗",
        "accent": "violet",
        "price": 0,
        "is_free": True,
        "summary": "كورس مجاني بالكامل يضع لك الأساس الصلب في النحو والبلاغة والإملاء لتفادي خسارة أي درجات لغوية.",
        "lectures": [
            {
                "title": "مفاتيح الإعراب وضبط الكلمات",
                "lessons": [
                    ("المفاتيح الذهبية لتحديد الموقع الإعرابي والعلامة", 20),
                    ("الصور البيانية (التشبيه والاستعارة والكناية) بأسهل طريقة", 24),
                    ("قواعد الهمزات والألف اللينة التي يحاسب عليها المصحح", 18),
                ],
            },
        ],
    },
]

EXAMS = [
    {
        "course": 0,
        "title": "امتحان تجريبي Cambridge OL — الورقة الأولى",
        "duration": 45,
        "questions": [
            ("المقصود بإعادة الصياغة (Paraphrasing) في سؤال التلخيص هو:",
             ["التعبير عن المعنى بأسلوب الطالب الخاص مع الحفاظ على الفكرة",
              "نقل الجمل كما هي من النص الأصلي",
              "حذف الكلمات الصعبة فقط",
              "إضافة معلومات خارجية غير موجودة في النص"], 0,
             "معايير كامبريدج تشترط التعبير بأسلوبك لتجنب خسارة درجات المهارة اللغوية."),
            ("أي العبارات الآتية تناسب خاتمة خطاب رسمي موجه إلى رئيس تحرير صحيفة؟",
             ["وتفضلوا بقبول فائق الاحترام والتقدير، مقدمه لسيادتكم...",
              "يلا أشوفك على خير يا صاحبي مع السلامة",
              "شكراً جزيلاً وإلى اللقاء قريباً جداً",
              "أراك لاحقاً إن شاء الله"], 0,
             "الخطاب الرسمي يتطلب عبارات ختامية تتسم بالأدب والرسمية."),
            ("علامة الترقيم المناسبة بعد جملة مقول القول (مثل: قال المعلم...) هي:",
             ["النقطتان الرأسيتان (:)", "الفاصلة المنقوطة (;)", "علامة الاستفهام (?)", "النقطة (.)"], 0,
             "توضع النقطتان الرأسيتان (:) بعد القول أو ما يفيد معناه."),
        ],
    },
    {
        "course": 2,
        "title": "اختبار البلاغة والنصوص — Edexcel OL",
        "duration": 30,
        "questions": [
            ("نوع الصورة البيانية في قول الشاعر: «أقبل البحر يمشي في البساط»:",
             ["استعارة تصريحية (حيث شُبّه الممدوح بالبحر وحُذف المشبه)",
              "تشبيه بليغ",
              "كناية عن صفة",
              "استعارة مكنية"], 0,
             "حُذف المشبه وصُرّح بلفظ المشبه به فهي استعارة تصريحية."),
            ("الطباق الإيجاب هو:",
             ["الجمع بين الكلمة وضدها في المعنى (مثل: الليل والنهار)",
              "الجمع بين الفعل ونفيه (مثل: يعلم ولا يعلم)",
              "اتفاق كلمتين في اللفظ واختلافهما في المعنى",
              "توافق الفواصل في الحرف الأخير"], 0,
             "طباق الإيجاب يكون بين كلمتين متضادتين بدون أداة نفي."),
        ],
    },
    {
        "course": 4,
        "title": "كويز سريع في النحو والإملاء لـ IGCSE",
        "duration": 15,
        "questions": [
            ("كتابة الهمزة في كلمة «مَسْؤُول» على واو لأنها:",
             ["مضمومة وما قبلها ساكن", "مفتوحة وما قبلها مضموم", "مكسورة وما قبلها مفتوح", "ساكنة وما قبلها مضموم"], 0,
             "قاعدة أقوى الحركات: الضمة أقوى من السكون فتكتب على واو."),
            ("إعراب كلمة (كتاباً) في جملة «اشتريتُ عشرينَ كتاباً»:",
             ["تمييز منصوب وعلامة نصبه الفتحة", "مفعول به ثانٍ", "مضاف إليه مجرور", "حال منصوب"], 0,
             "الاسم النكرة بعد ألفاظ العقود يعرب تمييزاً مفردًا منصوباً."),
        ],
    },
]

TESTIMONIALS = [
    ("سيف الدين طارق", "Cambridge OL - Grade 11", "بفضل الله ثم متابعة د. ناجي الغيطي وتصحيحه الدوري لكل موضوعات التعبير، حققت A* (Grade 9) في العربي من أول محاولة.", 5),
    ("ملك يوسف", "Edexcel OL - Grade 10", "كورس الباست بيبرز نظّم لي الأفكار وعلمني إزاي أكتب موضوع تعبير متكامل في الوقت المحدد بالظبط.", 5),
    ("عمر الشاذلي", "Cambridge AL - Grade 12", "تحليل الروايات والنصوص الأدبية مع دكتور ناجي ممتع جداً ومطابق لتقارير الممتحنين في كامبريدج.", 5),
    ("فريدة أشرف", "IGCSE Student", "كنت بستصعب التلخيص والنحو، كورس الأساسيات المجاني حل لي المشكلة دي تماماً.", 5),
]


class Command(BaseCommand):
    help = "تعبئة قاعدة البيانات ببيانات تجريبية جاهزة للعرض"

    @transaction.atomic
    def handle(self, *args, **options):
        self.stdout.write("🧹 مسح البيانات القديمة...")
        for model in (
            AttemptAnswer, ExamAttempt, Choice, Question, Exam, LessonProgress,
            Attachment, Lesson, Lecture, Enrollment, AccessCode, Course, Announcement,
            Testimonial, ContactMessage, Grade,
        ):
            model.objects.all().delete()
        User.objects.filter(is_superuser=False).delete()

        # -------------------------------------------------- الصفوف
        self.stdout.write("🎓 إضافة المناهج والصفوف الدراسية...")
        grades = []
        curricula = [
            ("Cambridge OL (0508 / 0544)", "cambridge-ol"),
            ("Cambridge AL (9680 / 8680)", "cambridge-al"),
            ("Edexcel OL (4AA1)", "edexcel-ol"),
            ("Edexcel AL (WAA01 / WAA02)", "edexcel-al"),
        ]
        for order, (name, slug) in enumerate(curricula):
            grades.append(Grade.objects.create(name=name, order=order, slug=slug))

        # -------------------------------------------------- المدرس
        self.stdout.write("👨‍🏫 إنشاء حساب د. ناجي الغيطي...")
        teacher = User.objects.filter(username="teacher").first()
        if not teacher:
            teacher = User(username="teacher")
        teacher.first_name = "د. ناجي"
        teacher.last_name = "الغيطي"
        teacher.role = User.ROLE_TEACHER
        teacher.phone = "+201005209526"
        teacher.city = "القاهرة"
        teacher.is_staff = True
        teacher.is_superuser = True
        teacher.bio = "د. ناجي الغيطي — خبير ومحاضر اللغة العربية لشهادات IGCSE الدولية (Cambridge & Edexcel) للمستويين العادي والمتقدم (OL & AL)."
        teacher.set_password("teacher123")
        teacher.save()

        # -------------------------------------------------- الطلبة
        self.stdout.write("👥 إنشاء حسابات الطلبة...")
        students = []
        for index, (first, last) in enumerate(STUDENT_NAMES, start=1):
            student = User(
                username=f"student{index}",
                first_name=first,
                last_name=last,
                role=User.ROLE_STUDENT,
                phone=f"0100000{index:04d}",
                parent_phone=f"0111000{index:04d}",
                city=random.choice(CITIES),
                grade=random.choice(grades),
                created_at=timezone.now() - timedelta(days=random.randint(0, 40)),
            )
            student.set_password("student123")
            student.save()
            students.append(student)

        # -------------------------------------------------- الكورسات والدروس
        self.stdout.write("📚 إضافة الكورسات والدروس...")
        courses = []
        for order, data in enumerate(COURSES):
            course = Course.objects.create(
                title=data["title"],
                grade=grades[data["grade"]],
                summary=data["summary"],
                description=(
                    f"{data['summary']}\n\n"
                    "الكورس مقسّم لحصص قصيرة مركّزة، كل حصة بعدها مذكرة PDF وواجب، "
                    "وفي آخر الكورس امتحان شامل بيتصحّح فوراً وتشوف فيه مستواك بالتفصيل."
                ),
                price=data["price"],
                is_free=data.get("is_free", False),
                emoji=data["emoji"],
                accent=data["accent"],
                order=order,
            )
            courses.append(course)
            for lec_order, lec_data in enumerate(data["lectures"]):
                lecture = Lecture.objects.create(
                    course=course,
                    title=lec_data["title"],
                    description=f"محاضرة تفصيلية عن {lec_data['title']}.",
                    order=lec_order,
                )
                for lesson_order, (title, duration) in enumerate(lec_data["lessons"]):
                    if lesson_order % 2 == 0:
                        source = Lesson.VIDEO_SOURCE_YOUTUBE
                        yt_id = random.choice(VIDEO_IDS)
                        drive_url = ""
                    else:
                        source = Lesson.VIDEO_SOURCE_DRIVE
                        yt_id = ""
                        drive_url = "https://drive.google.com/file/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/view?usp=sharing"

                    lesson = Lesson.objects.create(
                        lecture=lecture,
                        title=title,
                        description=f"شرح تفصيلي لـ«{title}» مع أمثلة محلولة خطوة بخطوة.",
                        video_source=source,
                        youtube_id=yt_id,
                        drive_url=drive_url,
                        duration_minutes=duration,
                        order=lesson_order,
                        is_preview=(lec_order == 0 and lesson_order == 0),
                    )
                    Attachment.objects.create(
                        lesson=lesson,
                        title=f"مذكرة {title} (PDF)",
                        kind=Attachment.KIND_LINK,
                        url="https://example.com/notes.pdf",
                    )

        # -------------------------------------------------- الاشتراكات والتقدّم
        self.stdout.write("🔗 تسجيل الطلبة في الكورسات...")
        for student in students:
            for course in random.sample(courses, random.randint(1, 3)):
                status = random.choices(
                    [Enrollment.STATUS_ACTIVE, Enrollment.STATUS_PENDING], weights=[85, 15]
                )[0]
                Enrollment.objects.get_or_create(
                    student=student, course=course, defaults={"status": status}
                )
                if status == Enrollment.STATUS_ACTIVE:
                    lessons = list(Lesson.objects.filter(lecture__course=course))
                    for lesson in lessons[: random.randint(0, len(lessons))]:
                        LessonProgress.objects.get_or_create(student=student, lesson=lesson)

        # -------------------------------------------------- الامتحانات
        self.stdout.write("📝 إضافة الامتحانات والأسئلة...")
        exams = []
        for data in EXAMS:
            exam = Exam.objects.create(
                course=courses[data["course"]],
                title=data["title"],
                description="اقرأ السؤال كويس، ومتنساش إن الوقت محسوب. بالتوفيق ✨",
                duration_minutes=data["duration"],
                pass_percent=50,
            )
            exams.append(exam)
            for order, (text, choices, correct, explanation) in enumerate(data["questions"]):
                question = Question.objects.create(
                    exam=exam, text=text, order=order, points=1, explanation=explanation
                )
                shuffled = list(enumerate(choices))
                random.shuffle(shuffled)
                for choice_order, (original_index, choice_text) in enumerate(shuffled):
                    Choice.objects.create(
                        question=question,
                        text=choice_text,
                        is_correct=(original_index == correct),
                        order=choice_order,
                    )

        # -------------------------------------------------- محاولات الامتحانات
        self.stdout.write("📊 توليد نتائج امتحانات...")
        for exam in exams:
            enrolled = Enrollment.objects.filter(
                course=exam.course, status=Enrollment.STATUS_ACTIVE
            ).select_related("student")
            questions = list(exam.questions.prefetch_related("choices"))
            for enrollment in enrolled:
                if random.random() < 0.35:
                    continue
                attempt = ExamAttempt.objects.create(
                    student=enrollment.student,
                    exam=exam,
                    started_at=timezone.now() - timedelta(days=random.randint(1, 20)),
                )
                score = 0
                for question in questions:
                    choices = list(question.choices.all())
                    correct = next((c for c in choices if c.is_correct), None)
                    picked = correct if random.random() < 0.68 else random.choice(choices)
                    is_correct = bool(picked and picked.is_correct)
                    if is_correct:
                        score += question.points
                    AttemptAnswer.objects.create(
                        attempt=attempt, question=question, choice=picked, is_correct=is_correct
                    )
                total = sum(q.points for q in questions)
                attempt.score = score
                attempt.max_score = total
                attempt.percent = round(score * 100 / total, 1) if total else 0
                attempt.submitted_at = attempt.started_at + timedelta(minutes=random.randint(5, 15))
                attempt.save()

        # -------------------------------------------------- أكواد التفعيل
        self.stdout.write("🎟️ توليد أكواد تفعيل...")
        for _ in range(15):
            AccessCode.objects.create(code=AccessCode.generate_code(), course=random.choice(courses))

        # -------------------------------------------------- إعلانات وآراء ورسائل
        self.stdout.write("📢 إضافة الإعلانات والآراء...")
        Announcement.objects.create(
            title="بدء ورشة تصحيح موضوعات التعبير لـ Cambridge OL",
            body="أبنائي الطلاب، تم فتح رفع موضوعات التعبير للورقة الأولى والثانية، وسيتم التصحيح والتقييم طبقاً لمعايير كامبريدج مع ملحوظات أكاديمية مفصلة.",
            is_pinned=True,
        )
        Announcement.objects.create(
            title="حل امتحانات Past Papers 2024 (June & Nov)",
            body="تمت إضافة حلول امتحانات 2024 لطلاب Edexcel OL و Cambridge OL مع شرح نموذج الإجابة وتوزيع الدرجات.",
            grade=grades[0],
        )
        Announcement.objects.create(
            title="جلسة بث مباشر لمراجعة القواعد والنحو",
            body="جلسة زووم تفاعلية مجانية لجميع طلاب المنصة للإجابة على الأسئلة الشائعة في الورقة الأولى.",
        )

        for name, grade_name, text, rating in TESTIMONIALS:
            Testimonial.objects.create(
                student_name=name, grade_name=grade_name, text=text, rating=rating
            )

        ContactMessage.objects.create(
            name="ولي أمر الطالبة نور",
            phone="01122334455",
            message="السلام عليكم دكتور ناجي، ابنتي مسجلة Cambridge OL دور مايو/يونيو وأريد الاستفسار عن كورس مراجعة الباست بيبرز.",
        )
        ContactMessage.objects.create(
            name="ياسين خالد",
            phone="01099887766",
            message="مساء الخير دكتور، دفعت رسوم كورس Edexcel OL ومحتاج كود التفعيل للدخول على المحاضرات.",
        )

        self.stdout.write(self.style.SUCCESS("\n✅ تمت التعبئة بنجاح!\n"))
        self.stdout.write("  المدرس:  teacher / teacher123")
        self.stdout.write("  طالب:    student1 / student123")
        self.stdout.write(f"  عدد الطلبة: {len(students)} — الكورسات: {len(courses)} — الامتحانات: {len(exams)}\n")
