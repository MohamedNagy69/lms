from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import (
    AccessCode,
    Announcement,
    Attachment,
    AttemptAnswer,
    Choice,
    ContactMessage,
    Course,
    Enrollment,
    Exam,
    ExamAttempt,
    Grade,
    Lecture,
    Lesson,
    LessonProgress,
    Question,
    Testimonial,
    User,
)


@admin.register(User)
class AcademyUserAdmin(UserAdmin):
    list_display = ("username", "first_name", "last_name", "role", "phone", "parent_phone", "mother_phone", "grade")
    list_filter = ("role", "grade", "is_active")
    search_fields = ("username", "first_name", "last_name", "phone", "parent_phone", "mother_phone", "email")
    fieldsets = UserAdmin.fieldsets + (
        ("بيانات المنصة والتواصل مع ولي الأمر (واتساب وتيليجرام)", {"fields": ("role", "phone", "parent_phone", "mother_phone", "father_telegram_chat_id", "mother_telegram_chat_id", "telegram_chat_id", "father_email", "mother_email", "city", "grade", "bio")}),
    )


class LessonInline(admin.TabularInline):
    model = Lesson
    extra = 1


class LectureInline(admin.TabularInline):
    model = Lecture
    extra = 1


class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 4


class QuestionInline(admin.StackedInline):
    model = Question
    extra = 1


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ("title", "grade", "price", "is_free", "is_published")
    list_filter = ("grade", "is_free", "is_published")
    search_fields = ("title",)
    inlines = [LectureInline]


@admin.register(Lecture)
class LectureAdmin(admin.ModelAdmin):
    list_display = ("title", "course", "order")
    list_filter = ("course",)
    inlines = [LessonInline]


@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display = ("title", "lecture", "duration_minutes", "is_preview")
    list_filter = ("lecture__course",)


@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ("title", "course", "duration_minutes", "max_infractions", "is_published", "created_at")
    list_editable = ("max_infractions", "is_published")
    list_filter = ("course", "is_published", "require_webcam", "require_fullscreen")
    search_fields = ("title", "course__title")
    fieldsets = (
        ("البيانات الأساسية للامتحان", {
            "fields": ("title", "course", "description", "duration_minutes", "pass_percent", "max_attempts", "allow_retake", "is_published")
        }),
        ("إعدادات الأمان والمراقبة والإنذارات", {
            "fields": (
                "max_infractions",
                "require_webcam",
                "ai_multi_person_detection",
                "ai_absence_and_camera_block",
                "require_fullscreen",
                "prevent_copy_paste",
                "prevent_multiple_screens",
                "shuffle_questions",
            )
        }),
    )
    inlines = [QuestionInline]


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ("__str__", "exam", "points")
    inlines = [ChoiceInline]


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ("student", "course", "status", "created_at")
    list_filter = ("status", "course")


@admin.register(ExamAttempt)
class ExamAttemptAdmin(admin.ModelAdmin):
    list_display = ("student", "exam", "score", "max_score", "percent", "infractions_count", "submitted_at")
    list_filter = ("exam", "exam__course")
    search_fields = ("student__username", "student__first_name", "student__last_name", "exam__title")


admin.site.register([
    Grade,
    Attachment,
    AccessCode,
    LessonProgress,
    AttemptAnswer,
    Announcement,
    Testimonial,
    ContactMessage,
])
