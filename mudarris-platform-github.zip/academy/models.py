"""كل موديلات المنصة: المستخدمين، الكورسات، الدروس، الامتحانات ..."""

import random
import secrets
import string
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.urls import reverse
from django.utils import timezone
from django.utils.text import slugify


# ---------------------------------------------------------------------------
# المستخدمون
# ---------------------------------------------------------------------------
class User(AbstractUser):
    """مستخدم المنصة: إما طالب أو المدرس (صاحب المنصة)."""

    ROLE_STUDENT = "student"
    ROLE_TEACHER = "teacher"
    ROLE_CHOICES = [
        (ROLE_STUDENT, "طالب"),
        (ROLE_TEACHER, "مدرس"),
    ]

    role = models.CharField("الصفة", max_length=10, choices=ROLE_CHOICES, default=ROLE_STUDENT)
    phone = models.CharField("رقم موبايل الطالب (واتساب)", max_length=20, blank=True)
    parent_phone = models.CharField("رقم واتساب الأب (ولي الأمر)", max_length=20, blank=True)
    mother_phone = models.CharField("رقم واتساب الأم", max_length=20, blank=True)
    father_email = models.EmailField("البريد الإلكتروني للأب", blank=True)
    mother_email = models.EmailField("البريد الإلكتروني للأم", blank=True)
    telegram_chat_id = models.CharField("معرف تيليجرام الطالب (Chat ID)", max_length=50, blank=True)
    father_telegram_chat_id = models.CharField("معرف تيليجرام الأب (Chat ID)", max_length=50, blank=True)
    mother_telegram_chat_id = models.CharField("معرف تيليجرام الأم (Chat ID)", max_length=50, blank=True)
    city = models.CharField("المحافظة / المركز", max_length=60, blank=True)
    grade = models.ForeignKey(
        "Grade",
        verbose_name="الصف الدراسي",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="students",
    )
    bio = models.TextField("نبذة", blank=True)
    avatar_color = models.CharField(max_length=20, default="brand")
    active_session_key = models.CharField("مفتاح الجلسة النشطة", max_length=40, blank=True)
    screenshot_strikes = models.IntegerField("مخالفات تصوير الشاشة", default=0)
    locked_until = models.DateTimeField("تاريخ فك القفل المؤقت", null=True, blank=True)
    is_security_banned = models.BooleanField("محظور أمنياً", default=False)
    banned_until = models.DateTimeField("تاريخ انتهاء الحظر السنوي", null=True, blank=True)
    created_at = models.DateTimeField("تاريخ التسجيل", default=timezone.now)

    class Meta:
        verbose_name = "مستخدم"
        verbose_name_plural = "المستخدمون"

    def __str__(self):
        return self.display_name

    @property
    def display_name(self):
        full = f"{self.first_name} {self.last_name}".strip()
        return full or self.username

    @property
    def is_teacher(self):
        return self.role == self.ROLE_TEACHER or self.is_superuser

    @property
    def is_currently_locked(self):
        if self.is_teacher:
            return False
        if self.is_security_banned:
            return True
        if self.locked_until and self.locked_until > timezone.now():
            return True
        return False

    @property
    def lock_remaining_seconds(self):
        if self.locked_until and self.locked_until > timezone.now():
            return int((self.locked_until - timezone.now()).total_seconds())
        return 0

    @property
    def initials(self):
        name = self.display_name.strip()
        parts = [p for p in name.split() if p]
        if len(parts) >= 2:
            return parts[0][0] + parts[1][0]
        return name[:2]

    @property
    def whatsapp_phone(self):
        from .services.whatsapp import clean_phone_for_whatsapp
        return clean_phone_for_whatsapp(self.phone)

    @property
    def whatsapp_father_phone(self):
        from .services.whatsapp import clean_phone_for_whatsapp
        return clean_phone_for_whatsapp(self.parent_phone)

    @property
    def whatsapp_mother_phone(self):
        from .services.whatsapp import clean_phone_for_whatsapp
        return clean_phone_for_whatsapp(self.mother_phone)


# ---------------------------------------------------------------------------
# البنية التعليمية
# ---------------------------------------------------------------------------
class Grade(models.Model):
    """الصف الدراسي (أولى ثانوي، تانية ثانوي ...)."""

    name = models.CharField("اسم الصف", max_length=80, unique=True)
    slug = models.SlugField("الرابط", max_length=90, unique=True, allow_unicode=True, blank=True)
    order = models.IntegerField("الترتيب", default=0)
    is_active = models.BooleanField("مفعّل", default=True)

    class Meta:
        verbose_name = "صف دراسي"
        verbose_name_plural = "الصفوف الدراسية"
        ordering = ["order", "name"]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name, allow_unicode=True)
        super().save(*args, **kwargs)


class Course(models.Model):
    """كورس (مثلاً: الفصل الأول - الميكانيكا)."""

    ACCENTS = [
        ("brand", "أزرق"),
        ("emerald", "أخضر"),
        ("amber", "برتقالي"),
        ("rose", "أحمر"),
        ("violet", "بنفسجي"),
    ]

    title = models.CharField("اسم الكورس", max_length=150)
    slug = models.SlugField("الرابط", max_length=170, unique=True, allow_unicode=True, blank=True)
    grade = models.ForeignKey(
        Grade, verbose_name="الصف الدراسي", on_delete=models.CASCADE, related_name="courses"
    )
    summary = models.CharField("وصف مختصر", max_length=250, blank=True)
    description = models.TextField("الوصف الكامل", blank=True)
    price = models.PositiveIntegerField("السعر بالجنيه", default=0)
    is_free = models.BooleanField("كورس مجاني", default=False)
    is_published = models.BooleanField("منشور", default=True)
    enable_watermark = models.BooleanField("تفعيل العلامة المائية للدروس", default=True, help_text="عرض بيانات الطالب كعلامة مائية متحركة على جميع فيديوهات الكورس")
    master_access_code = models.CharField(
        "كود الاشتراك الموحد للكورس",
        max_length=50,
        blank=True,
        default="",
        help_text="كود ثابت مستمر يستطيع أي طالب استخدامه للاشتراك في الكورس ويفضل شغال. يمكنك تغييره متى شئت لإيقاف الكود القديم.",
    )
    emoji = models.CharField("أيقونة", max_length=8, default="📘")
    accent = models.CharField("اللون", max_length=20, choices=ACCENTS, default="brand")
    order = models.IntegerField("الترتيب", default=0)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "كورس"
        verbose_name_plural = "الكورسات"
        ordering = ["order", "-created_at"]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.title, allow_unicode=True) or "course"
            slug, i = base, 2
            while Course.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base}-{i}"
                i += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse("academy:course_detail", args=[self.slug])

    @property
    def lectures_count(self):
        return self.lectures.count()

    @property
    def lessons_count(self):
        return Lesson.objects.filter(lecture__course=self).count()

    @property
    def total_minutes(self):
        return Lesson.objects.filter(lecture__course=self).aggregate(total=models.Sum("duration_minutes"))["total"] or 0

    @property
    def students_count(self):
        return self.enrollments.filter(status=Enrollment.STATUS_ACTIVE).count()

    @property
    def price_label(self):
        return "مجاني" if self.is_free or self.price == 0 else f"{self.price} ج.م"

    @property
    def cover_image(self):
        """إرجاع مسار صورة الغلاف للكورس بناءً على الترتيب أو المعرّف."""
        img_index = (self.order % 5) + 1
        return f"img/courses/course_{img_index}.jpg"


class Lecture(models.Model):
    """محاضرة داخل كورس — تحتوي على مجموعة دروس (فيديوهات)."""

    course = models.ForeignKey(
        Course, verbose_name="الكورس", on_delete=models.CASCADE, related_name="lectures"
    )
    title = models.CharField("عنوان المحاضرة", max_length=150)
    description = models.TextField("وصف مختصر", blank=True)
    order = models.IntegerField("الترتيب", default=0)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "محاضرة"
        verbose_name_plural = "المحاضرات"
        ordering = ["order", "id"]

    def __str__(self):
        return f"{self.course.title} — {self.title}"


class Lesson(models.Model):
    """درس داخل كورس، يدعم الفيديو المرفوع محلياً أو من يوتيوب أو جوجل درايف + مرفقات."""

    VIDEO_SOURCE_YOUTUBE = "youtube"
    VIDEO_SOURCE_FILE = "file"
    VIDEO_SOURCE_DRIVE = "drive"

    VIDEO_SOURCE_CHOICES = [
        (VIDEO_SOURCE_YOUTUBE, "يوتيوب (YouTube)"),
        (VIDEO_SOURCE_FILE, "رفع ملف فيديو من جهازي (MP4/WebM)"),
        (VIDEO_SOURCE_DRIVE, "جوجل درايف (Google Drive)"),
    ]

    lecture = models.ForeignKey(
        Lecture, verbose_name="المحاضرة", on_delete=models.CASCADE, related_name="lessons"
    )
    title = models.CharField("عنوان الدرس", max_length=150)
    description = models.TextField("شرح مختصر", blank=True)
    video_source = models.CharField(
        "مصدر الفيديو", max_length=15, choices=VIDEO_SOURCE_CHOICES, default=VIDEO_SOURCE_YOUTUBE
    )
    video_file = models.FileField("ملف الفيديو", upload_to="videos/", blank=True, null=True)
    youtube_id = models.CharField(
        "كود أو رابط فيديو يوتيوب", max_length=150, blank=True,
        help_text="مثال: dQw4w9WgXcQ أو اللينك الكامل للفيديو",
    )
    drive_url = models.CharField(
        "رابط أو كود جوجل درايف", max_length=255, blank=True,
        help_text="مثال: رابط المشاركة من Google Drive",
    )
    duration_minutes = models.PositiveIntegerField("مدة الدرس بالدقائق", default=0)
    order = models.IntegerField("الترتيب", default=0)
    is_preview = models.BooleanField("درس مجاني للمعاينة", default=False)
    enable_watermark = models.BooleanField("تفعيل العلامة المائية لهذا الدرس", default=True, help_text="عرض العلامة المائية ببيانات الطالب فوق مشغل الفيديو")
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "درس"
        verbose_name_plural = "الدروس"
        ordering = ["order", "id"]

    @property
    def course(self):
        """وصول سريع للكورس عبر المحاضرة."""
        return self.lecture.course

    @property
    def show_watermark(self):
        """فحص ما إذا كانت العلامة المائية مفعلة للكورس وللدرس معاً."""
        course_setting = getattr(self.course, "enable_watermark", True)
        return self.enable_watermark and course_setting

    @property
    def youtube_embed_id(self):
        """استخراج كود يوتيوب بدقة من أي صيغة: رابط عادي، شورتس، لايف، أو كود iframe كامل."""
        val = (self.youtube_id or "").strip()
        if not val:
            return ""
        import re
        # 1. إذا تم لصق كود iframe كامل
        iframe_match = re.search(r'src=["\']([^"\']+)["\']', val)
        if iframe_match:
            val = iframe_match.group(1)
        # 2. استخراج الـ ID المكون من 11 حرف من كل صيغ يوتيوب المعروفة
        match = re.search(r"(?:v=|\/embed\/|youtu\.be\/|\/v\/|\/shorts\/|\/live\/|e\/)([a-zA-Z0-9_-]{11})", val)
        if match:
            return match.group(1)
        # 3. إذا كان الكود مدخل مباشرة كـ 11 حرف
        clean_match = re.search(r"([a-zA-Z0-9_-]{11})", val)
        if clean_match and len(val) == 11:
            return clean_match.group(1)
        return val

    @property
    def drive_embed_url(self):
        """استخراج كود جوجل درايف وإنشاء رابط التضمين الصحيح."""
        val = (self.drive_url or "").strip()
        if not val:
            return ""
        import re
        # 1. إذا تم لصق كود iframe كامل
        iframe_match = re.search(r'src=["\']([^"\']+)["\']', val)
        if iframe_match:
            val = iframe_match.group(1)
        # 2. استخراج المعرف ID
        match = re.search(r"(?:/file/d/|id=)([a-zA-Z0-9_-]{15,})", val)
        if match:
            file_id = match.group(1)
        elif len(val) >= 15 and "/" not in val and "?" not in val:
            file_id = val
        else:
            file_id = val
        return f"https://drive.google.com/file/d/{file_id}/preview"

    @property
    def has_video(self):
        if self.video_source == self.VIDEO_SOURCE_FILE:
            return bool(self.video_file)
        elif self.video_source == self.VIDEO_SOURCE_DRIVE:
            return bool(self.drive_url)
        return bool(self.youtube_embed_id)

    def __str__(self):
        return f"{self.lecture.course.title} — {self.title}"

    def get_absolute_url(self):
        return reverse("academy:lesson_detail", args=[self.lecture.course.slug, self.pk])


class Attachment(models.Model):
    """مذكرة أو ملف مرفق بالدرس."""

    KIND_FILE = "file"
    KIND_LINK = "link"
    KIND_CHOICES = [(KIND_FILE, "ملف"), (KIND_LINK, "رابط")]

    lesson = models.ForeignKey(
        Lesson, verbose_name="الدرس", on_delete=models.CASCADE, related_name="attachments"
    )
    title = models.CharField("اسم الملف", max_length=150)
    kind = models.CharField("النوع", max_length=10, choices=KIND_CHOICES, default=KIND_FILE)
    file = models.FileField("الملف", upload_to="attachments/", blank=True)
    url = models.URLField("الرابط", blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "مرفق"
        verbose_name_plural = "المرفقات"
        ordering = ["id"]

    def __str__(self):
        return self.title

    @property
    def download_url(self):
        if self.kind == self.KIND_LINK:
            return self.url
        return self.file.url if self.file else "#"


# ---------------------------------------------------------------------------
# الاشتراكات والتقدّم
# ---------------------------------------------------------------------------
class Enrollment(models.Model):
    """اشتراك طالب في كورس."""

    STATUS_ACTIVE = "active"
    STATUS_PENDING = "pending"
    STATUS_CHOICES = [(STATUS_ACTIVE, "مفعّل"), (STATUS_PENDING, "في انتظار التفعيل")]

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="enrollments"
    )
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="enrollments")
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=STATUS_PENDING)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "اشتراك"
        verbose_name_plural = "الاشتراكات"
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(fields=["student", "course"], name="unique_enrollment")
        ]

    def __str__(self):
        return f"{self.student} → {self.course}"

    @property
    def is_active(self):
        return self.status == self.STATUS_ACTIVE


class AccessCode(models.Model):
    """كود تفعيل يوزّعه المدرس للطلبة لفتح كورس مدفوع."""

    code = models.CharField("الكود", max_length=20, unique=True)
    course = models.ForeignKey(
        Course, on_delete=models.CASCADE, related_name="codes", null=True, blank=True,
        help_text="سيبه فاضي لو الكود يفتح أي كورس",
    )
    is_used = models.BooleanField("مستخدم", default=False)
    used_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="used_codes",
    )
    used_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "كود تفعيل"
        verbose_name_plural = "أكواد التفعيل"
        ordering = ["-created_at"]

    def __str__(self):
        return self.code

    @staticmethod
    def generate_code(prefix="PH", existing_set=None):
        prefix = (prefix or "PH").strip().upper()
        chars = string.ascii_uppercase + string.digits
        while True:
            code = prefix + "-" + "".join(random.choices(chars, k=6))
            if existing_set is not None:
                if code in existing_set:
                    continue
                if not AccessCode.objects.filter(code=code).exists():
                    existing_set.add(code)
                    return code
            else:
                if not AccessCode.objects.filter(code=code).exists():
                    return code


class LessonProgress(models.Model):
    """تتبّع مشاهدة الطالب للدرس."""

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="progress"
    )
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE, related_name="progress")
    is_completed = models.BooleanField(default=True)
    completed_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "تقدّم في درس"
        verbose_name_plural = "تقدّم الدروس"
        constraints = [
            models.UniqueConstraint(fields=["student", "lesson"], name="unique_progress")
        ]

    def __str__(self):
        return f"{self.student} — {self.lesson}"


# ---------------------------------------------------------------------------
# الامتحانات
# ---------------------------------------------------------------------------
class Exam(models.Model):
    """امتحان إلكتروني على كورس."""

    course = models.ForeignKey(
        Course, verbose_name="الكورس", on_delete=models.CASCADE, related_name="exams"
    )
    lesson = models.ForeignKey(
        "Lesson",
        verbose_name="الدرس التابع له (اختياري)",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="exams",
    )
    title = models.CharField("عنوان الامتحان", max_length=150)
    description = models.TextField("تعليمات الامتحان", blank=True)
    duration_minutes = models.PositiveIntegerField("مدة الامتحان بالدقائق", default=15)
    pass_percent = models.PositiveIntegerField("نسبة النجاح %", default=50)
    is_published = models.BooleanField("منشور", default=True)
    allow_retake = models.BooleanField("السماح بإعادة المحاولة", default=True)
    max_attempts = models.PositiveIntegerField(
        "أقصى عدد لمحاولات الامتحان",
        default=1,
        help_text="عدد المرات المسموح للطالب بدخول الامتحان فيها (1 تعني محاولة واحدة فقط، و 0 تعني محاولات غير محدودة)",
    )
    require_webcam = models.BooleanField(
        "إلزام المراقبة الحية بالكاميرا",
        default=False,
        help_text="يلزم الطالب بتشغيل الكاميرا وبث المراقبة أثناء الامتحان",
    )
    require_fullscreen = models.BooleanField(
        "إلزام وضع ملء الشاشة ورصد مغادرة التبويب",
        default=True,
        help_text="يقفل الشاشة ويسجل إنذارات عند تصغير المتصفح أو فتح برامج أخرى",
    )
    prevent_copy_paste = models.BooleanField(
        "منع النسخ والسيلكت وتصوير الشاشة",
        default=True,
        help_text="يعطل تحديد النصوص والزر الأيمن واختصارات تصوير الشاشة PRTSC",
    )
    shuffle_questions = models.BooleanField(
        "ترتيب الأسئلة عشوائياً لكل طالب",
        default=False,
        help_text="يغير ترتيب الأسئلة عشوائياً لمنع الغش وتبادل الإجابات",
    )
    ai_multi_person_detection = models.BooleanField(
        "رصد وجود أشخاص آخرين بالذكاء الاصطناعي (AI Multiple Person Detection)",
        default=True,
        help_text="يقوم نموذج الذكاء الاصطناعي بتحليل الكاميرا لحظياً وقفل الامتحان فوراً في حال رصد أي شخص بجوار الطالب",
    )
    ai_absence_and_camera_block = models.BooleanField(
        "رصد مغادرة الطالب وحجب الكاميرا بالذكاء الاصطناعي",
        default=True,
        help_text="يعطي إنذاراً أمنياً تلقائياً إذا قام الطالب وترك مكانه أو وضع إصبعه على الكاميرا لحجب الرؤية",
    )
    prevent_multiple_screens = models.BooleanField(
        "منع الشاشات المتعددة (إلزام شاشة واحدة فقط)",
        default=True,
        help_text="يمنع دخول الامتحان في حال وجود أكثر من شاشة متصلة بالجهاز (Dual Monitors)، ويطلق إنذاراً فورياً إذا تم توصيل شاشة إضافية.",
    )
    max_infractions = models.PositiveIntegerField(
        "الحد الأقصى للإنذارات الأمنية",
        default=3,
        help_text="عدد الإنذارات والمخالفات المسموح بها للطالب قبل إلغاء الجلسة وسحب الامتحان تلقائياً (الافتراضي: 3).",
    )
    auto_send_result = models.BooleanField(
        "إرسال النتيجة تلقائياً لأولياء الأمور فور انتهاء الامتحان",
        default=True,
        help_text="عند التفعيل، يقوم النظام تلقائياً وبشكل فوري بإرسال تقرير النتيجة (الدرجة، النسبة، الإنذارات، ورابط ورقة الإجابة) لولي الأمر (الأب / الأم) بمجرد تسليم الطالب للامتحان.",
    )
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "امتحان"
        verbose_name_plural = "الامتحانات"
        ordering = ["-created_at"]

    def __str__(self):
        return self.title

    @property
    def max_attempts_label(self):
        if self.max_attempts == 0:
            return "غير محدود"
        elif self.max_attempts == 1:
            return "محاولة واحدة"
        elif self.max_attempts == 2:
            return "محاولتان"
        else:
            return f"{self.max_attempts} محاولات"

    @property
    def questions_count(self):
        return self.questions.count()

    @property
    def max_score(self):
        return sum(q.points for q in self.questions.all())


class Question(models.Model):
    QUESTION_TYPE_MCQ = "mcq"
    QUESTION_TYPE_ESSAY = "essay"
    QUESTION_TYPE_CHOICES = [
        (QUESTION_TYPE_MCQ, "اختيار من متعدد (MCQ)"),
        (QUESTION_TYPE_ESSAY, "سؤال مقالي (Essay)"),
    ]

    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name="questions")
    question_type = models.CharField(
        "نوع السؤال", max_length=10, choices=QUESTION_TYPE_CHOICES, default=QUESTION_TYPE_MCQ
    )
    text = models.TextField("نص السؤال")
    image = models.ImageField("صورة السؤال (توضيحية أو رسم بياني)", upload_to="questions/", blank=True, null=True)
    points = models.PositiveIntegerField("الدرجة", default=1)
    order = models.IntegerField("الترتيب", default=0)
    explanation = models.TextField("تعليق / شرح الإجابة أو نموذج الإجابة", blank=True)

    class Meta:
        verbose_name = "سؤال"
        verbose_name_plural = "الأسئلة"
        ordering = ["order", "id"]

    def __str__(self):
        return self.text[:60]

    @property
    def is_essay(self):
        return self.question_type == self.QUESTION_TYPE_ESSAY

    @property
    def is_mcq(self):
        return self.question_type == self.QUESTION_TYPE_MCQ

    @property
    def correct_choice(self):
        return self.choices.filter(is_correct=True).first()


class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="choices")
    text = models.CharField("نص الاختيار", max_length=250)
    is_correct = models.BooleanField("إجابة صحيحة", default=False)
    order = models.IntegerField(default=0)

    class Meta:
        verbose_name = "اختيار"
        verbose_name_plural = "الاختيارات"
        ordering = ["order", "id"]

    def __str__(self):
        return self.text


class ExamAttempt(models.Model):
    """محاولة طالب في امتحان."""

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="attempts"
    )
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name="attempts")
    started_at = models.DateTimeField(default=timezone.now)
    submitted_at = models.DateTimeField(null=True, blank=True)
    score = models.PositiveIntegerField(default=0)
    max_score = models.PositiveIntegerField(default=0)
    percent = models.FloatField(default=0)
    infractions_count = models.PositiveIntegerField("عدد الإنذارات الأمنية", default=0)

    class Meta:
        verbose_name = "محاولة امتحان"
        verbose_name_plural = "محاولات الامتحانات"
        ordering = ["-started_at"]

    def __str__(self):
        return f"{self.student} — {self.exam} ({self.percent:.0f}%)"

    @property
    def is_submitted(self):
        return self.submitted_at is not None

    @property
    def is_passed(self):
        return self.percent >= self.exam.pass_percent

    @property
    def deadline(self):
        return self.started_at + timedelta(minutes=self.exam.duration_minutes)

    @property
    def seconds_left(self):
        return max(0, int((self.deadline - timezone.now()).total_seconds()))

    @property
    def whatsapp_father_msg(self):
        from .services.whatsapp import build_whatsapp_result_message
        return build_whatsapp_result_message(self, recipient_role="father")

    @property
    def whatsapp_mother_msg(self):
        from .services.whatsapp import build_whatsapp_result_message
        return build_whatsapp_result_message(self, recipient_role="mother")

    @property
    def whatsapp_father_url(self):
        from .services.whatsapp import clean_phone_for_whatsapp
        import urllib.parse
        phone = clean_phone_for_whatsapp(self.student.parent_phone)
        if not phone:
            return ""
        return f"https://wa.me/{phone}?text={urllib.parse.quote(self.whatsapp_father_msg)}"

    @property
    def whatsapp_mother_url(self):
        from .services.whatsapp import clean_phone_for_whatsapp
        import urllib.parse
        phone = clean_phone_for_whatsapp(getattr(self.student, "mother_phone", ""))
        if not phone:
            return ""
        return f"https://wa.me/{phone}?text={urllib.parse.quote(self.whatsapp_mother_msg)}"

    @property
    def whatsapp_student_url(self):
        from .services.whatsapp import clean_phone_for_whatsapp, build_whatsapp_result_message
        import urllib.parse
        phone = clean_phone_for_whatsapp(self.student.phone)
        if not phone:
            return ""
        msg = build_whatsapp_result_message(self, recipient_role="student")
        return f"https://wa.me/{phone}?text={urllib.parse.quote(msg)}"


class AttemptAnswer(models.Model):
    attempt = models.ForeignKey(ExamAttempt, on_delete=models.CASCADE, related_name="answers")
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice = models.ForeignKey(Choice, on_delete=models.SET_NULL, null=True, blank=True)
    text_answer = models.TextField("إجابة السؤال المقالي", blank=True)
    is_correct = models.BooleanField(default=False)
    score_awarded = models.PositiveIntegerField("الدرجة الممنوحة", default=0)
    teacher_feedback = models.TextField("ملاحظات المعلم", blank=True)

    class Meta:
        verbose_name = "إجابة"
        verbose_name_plural = "الإجابات"


# ---------------------------------------------------------------------------
# محتوى إضافي
# ---------------------------------------------------------------------------
class Announcement(models.Model):
    title = models.CharField("عنوان الإعلان", max_length=150)
    body = models.TextField("النص")
    grade = models.ForeignKey(
        Grade, on_delete=models.CASCADE, null=True, blank=True, related_name="announcements",
        verbose_name="مخصص لصف معيّن", help_text="سيبه فاضي علشان يظهر لكل الطلبة",
    )
    is_pinned = models.BooleanField("مثبّت", default=False)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "إعلان"
        verbose_name_plural = "الإعلانات"
        ordering = ["-is_pinned", "-created_at"]

    def __str__(self):
        return self.title


class Testimonial(models.Model):
    student_name = models.CharField("اسم الطالب", max_length=80)
    grade_name = models.CharField("الصف", max_length=80, blank=True)
    text = models.TextField("رأيه")
    rating = models.PositiveSmallIntegerField("التقييم من 5", default=5)
    is_visible = models.BooleanField("يظهر في الصفحة الرئيسية", default=True)

    class Meta:
        verbose_name = "رأي طالب"
        verbose_name_plural = "آراء الطلبة"

    def __str__(self):
        return self.student_name

    @property
    def stars(self):
        return range(self.rating)


class ContactMessage(models.Model):
    name = models.CharField("الاسم", max_length=80)
    phone = models.CharField("رقم الموبايل", max_length=20)
    message = models.TextField("الرسالة")
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "رسالة تواصل"
        verbose_name_plural = "رسائل التواصل"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name} — {self.phone}"


class StudentDevice(models.Model):
    """جهاز مصرح به للطالب (الحد الأقصى جهازين نشطين لكل طالب — الخروج التلقائي عند الدخول من جهاز ثالث)."""

    student = models.ForeignKey(
        User, verbose_name="الطالب", on_delete=models.CASCADE, related_name="devices"
    )
    device_id = models.CharField("معرّف الجهاز الفريد", max_length=64, db_index=True)
    device_name = models.CharField("نوع واسم الجهاز", max_length=150)
    ip_address = models.CharField("عنوان IP", max_length=45, blank=True)
    user_agent = models.TextField("وكيل المتصفح", blank=True)
    session_key = models.CharField("مفتاح الجلسة النشطة", max_length=40, blank=True)
    last_login = models.DateTimeField("آخر تسجيل دخول", default=timezone.now)
    created_at = models.DateTimeField("تاريخ تسجيل الجهاز لأول مرة", default=timezone.now)
    is_active = models.BooleanField("نشط حالياً", default=True)

    class Meta:
        verbose_name = "جهاز مصرح به"
        verbose_name_plural = "الأجهزة المصرح بها للطلاب"
        ordering = ["-last_login"]
        unique_together = [("student", "device_id")]

    def __str__(self):
        return f"{self.student.display_name} — {self.device_name}"


# ---------------------------------------------------------------------------
# سجلات اطلاع أولياء الأمور على تقارير المتابعة
# ---------------------------------------------------------------------------
class ParentReportView(models.Model):
    """سجل اطلاع ومتابعة ولي الأمر لتقرير الطالب الأسبوعي مع رصد فتح الرابط وتاريخ المشاهدة."""

    student = models.ForeignKey(
        User,
        verbose_name="الطالب",
        on_delete=models.CASCADE,
        related_name="parent_report_views",
    )
    course = models.ForeignKey(
        "Course",
        verbose_name="الكورس",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="parent_report_views",
    )
    week_start = models.DateField("بداية الأسبوع")
    week_end = models.DateField("نهاية الأسبوع")
    token = models.CharField("كود التقرير السري", max_length=64, unique=True, db_index=True)
    recipient_role = models.CharField(
        "المستلم",
        max_length=20,
        default="parent",
        choices=[
            ("parent", "ولي الأمر (الأب)"),
            ("mother", "الأم"),
            ("student", "الطالب"),
            ("general", "عام"),
        ],
    )
    is_viewed = models.BooleanField("تم الاطلاع عليه من قبل ولي الأمر", default=False)
    first_viewed_at = models.DateTimeField("تاريخ أول مشاهدة", null=True, blank=True)
    last_viewed_at = models.DateTimeField("تاريخ آخر مشاهدة", null=True, blank=True)
    view_count = models.PositiveIntegerField("عدد مرات الفتح", default=0)
    created_at = models.DateTimeField("تاريخ إنشاء التقرير", default=timezone.now)

    class Meta:
        verbose_name = "سجل اطلاع تقرير ولي الأمر"
        verbose_name_plural = "سجلات اطلاع تقارير أولياء الأمور"
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["student", "week_start", "week_end"]),
        ]

    def __str__(self):
        status = "شاهده" if self.is_viewed else "لم يشاهده"
        return f"تقرير {self.student.display_name} ({self.week_start} إلى {self.week_end}) — {status}"

    def mark_as_viewed(self):
        """تسجيل مشاهدة ولي الأمر للتقرير وتحديث العداد والتوقيت فوراً."""
        now = timezone.now()
        self.is_viewed = True
        if not self.first_viewed_at:
            self.first_viewed_at = now
        self.last_viewed_at = now
        self.view_count += 1
        self.save(update_fields=["is_viewed", "first_viewed_at", "last_viewed_at", "view_count"])

    @classmethod
    def get_or_create_report(cls, student, week_start, week_end, course=None, recipient_role="parent"):
        obj = cls.objects.filter(
            student=student,
            week_start=week_start,
            week_end=week_end,
            course=course,
            recipient_role=recipient_role,
        ).first()
        if not obj:
            token = secrets.token_urlsafe(24)
            obj = cls.objects.create(
                student=student,
                week_start=week_start,
                week_end=week_end,
                course=course,
                recipient_role=recipient_role,
                token=token,
            )
        return obj

