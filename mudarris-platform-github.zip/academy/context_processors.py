from django.conf import settings

from .models import Grade


def site_info(request):
    """بيانات ثابتة متاحة في كل القوالب."""
    return {
        "site": settings.SITE_INFO,
        "nav_grades": Grade.objects.filter(is_active=True),
    }
