from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

from django.http import HttpResponseForbidden

def protected_video_deny(request, path):
    return HttpResponseForbidden("⛔ تم حظر الدخول المباشر لملفات الفيديو. الفيديوهات محمية ومشفرة عبر المنصة فقط.")

urlpatterns = [
    path("admin/", admin.site.urls),
    path("media/videos/<path:path>", protected_video_deny),
    path("", include("academy.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.BASE_DIR / "static")

admin.site.site_header = "لوحة إدارة المنصة"
admin.site.site_title = "منصة الأستاذ"
admin.site.index_title = "إدارة المحتوى"
