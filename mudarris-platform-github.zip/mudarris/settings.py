"""
إعدادات مشروع "منصة الأستاذ" التعليمية.

قاعدة البيانات الأساسية هي MongoDB عن طريق django-mongodb-backend.
لو MongoDB مش شغّال على الجهاز، المشروع بيرجع تلقائياً لـ SQLite علشان
الموقع يفضل شغّال من غير ما تتعطّل (تقدر تتحكم في ده من ملف .env).
"""

import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


# ---------------------------------------------------------------------------
# تحميل ملف .env (من غير مكتبات خارجية)
# ---------------------------------------------------------------------------
def load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


load_dotenv(BASE_DIR / ".env")


SECRET_KEY = os.environ.get(
    "SECRET_KEY", "django-insecure-change-me-in-production-9d8f7s6d5f4g3h2j1k"
)
DEBUG = os.environ.get("DEBUG", "1") == "1"
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "*").split(",")
CSRF_TRUSTED_ORIGINS = [
    o for o in os.environ.get("CSRF_TRUSTED_ORIGINS", "").split(",") if o
]


# ---------------------------------------------------------------------------
# التطبيقات
# ---------------------------------------------------------------------------
DEFAULT_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "academy",
]

# نسخة MongoDB من نفس التطبيقات (مفتاح ObjectId بدل الأرقام)
MONGO_APPS = [
    "mongo_apps.MongoAdminConfig",
    "mongo_apps.MongoAuthConfig",
    "mongo_apps.MongoContentTypesConfig",
    "mongo_apps.MongoSessionsConfig",
    "mongo_apps.MongoMessagesConfig",
    "mongo_apps.MongoStaticFilesConfig",
    "django_mongodb_backend",
    "academy",
]

INSTALLED_APPS = DEFAULT_APPS

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "academy.middleware.SingleSessionMiddleware",
]

ROOT_URLCONF = "mudarris.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "academy.context_processors.site_info",
            ],
        },
    },
]

WSGI_APPLICATION = "mudarris.wsgi.application"


# ---------------------------------------------------------------------------
# قاعدة البيانات: MongoDB أولاً، و SQLite كخطة بديلة
# ---------------------------------------------------------------------------
MONGODB_URI = os.environ.get("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_NAME = os.environ.get("MONGODB_NAME", "mudarris_db")
DB_ENGINE = os.environ.get("DB_ENGINE", "auto").lower()  # auto | mongodb | sqlite
MONGODB_TIMEOUT_MS = int(os.environ.get("MONGODB_TIMEOUT_MS", "2500"))


def mongodb_is_reachable(uri: str) -> bool:
    try:
        from pymongo import MongoClient

        MongoClient(uri, serverSelectionTimeoutMS=MONGODB_TIMEOUT_MS).admin.command(
            "ping"
        )
        return True
    except Exception:  # pragma: no cover - بيعتمد على البيئة
        return False


if DB_ENGINE == "sqlite":
    USE_MONGODB = False
elif DB_ENGINE == "mongodb":
    USE_MONGODB = True
else:
    USE_MONGODB = mongodb_is_reachable(MONGODB_URI)
    if "test" not in sys.argv:
        if USE_MONGODB:
            sys.stderr.write(
                f"\n[✅] متصل بـ MongoDB على {MONGODB_URI} — قاعدة البيانات: {MONGODB_NAME}\n\n"
            )
        else:
            sys.stderr.write(
                "\n[⚠️ تنبيه] مفيش اتصال بـ MongoDB على "
                f"{MONGODB_URI} — هيتم استخدام SQLite مؤقتاً.\n"
                "           شغّل MongoDB ثم أعد تشغيل السيرفر لاستخدامه.\n\n"
            )

if USE_MONGODB:
    import django_mongodb_backend

    INSTALLED_APPS = MONGO_APPS
    DATABASES = {
        "default": django_mongodb_backend.parse_uri(MONGODB_URI, db_name=MONGODB_NAME)
    }
    DEFAULT_AUTO_FIELD = "django_mongodb_backend.fields.ObjectIdAutoField"
    DATABASE_ROUTERS = ["django_mongodb_backend.routers.MongoRouter"]
    # MongoDB محتاج نسخة خاصة من ملفات الـ migrations
    MIGRATION_MODULES = {
        "admin": "mongo_migrations.admin",
        "auth": "mongo_migrations.auth",
        "contenttypes": "mongo_migrations.contenttypes",
        "sessions": "mongo_migrations.sessions",
        "academy": "academy.mongo_migrations",
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }
    DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# ---------------------------------------------------------------------------
# المستخدمون والصلاحيات
# ---------------------------------------------------------------------------
AUTH_USER_MODEL = "academy.User"

AUTHENTICATION_BACKENDS = [
    "academy.auth_backends.UsernameOrPhoneBackend",
    "django.contrib.auth.backends.ModelBackend",
]

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 6}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LOGIN_URL = "academy:login"
LOGIN_REDIRECT_URL = "academy:dashboard"
LOGOUT_REDIRECT_URL = "academy:home"


# ---------------------------------------------------------------------------
# اللغة والوقت
# ---------------------------------------------------------------------------
LANGUAGE_CODE = "ar"
TIME_ZONE = "Africa/Cairo"
USE_I18N = True
USE_TZ = True


# ---------------------------------------------------------------------------
# الملفات الثابتة والمرفوعة
# ---------------------------------------------------------------------------
STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

STORAGES = {
    "default": {
        "BACKEND": "django.core.files.storage.FileSystemStorage",
    },
    "staticfiles": {
        "BACKEND": "whitenoise.storage.CompressedStaticFilesStorage",
    },
}

MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"


MESSAGE_STORAGE = "django.contrib.messages.storage.session.SessionStorage"

# السماح برفع ملفات فيديو حتى 2.5 جيجابايت
DATA_UPLOAD_MAX_MEMORY_SIZE = 2500 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 2500 * 1024 * 1024
DATA_UPLOAD_MAX_NUMBER_FIELDS = 10000


# ---------------------------------------------------------------------------
# بيانات المنصة (تقدر تغيّرها من هنا أو من ملف .env)
# ---------------------------------------------------------------------------
SITE_INFO = {
    "teacher_name": os.environ.get("TEACHER_NAME", "د. ناجي الغيطي"),
    "subject": os.environ.get("TEACHER_SUBJECT", "اللغة العربية IGCSE (OL & AL)"),
    "tagline": os.environ.get(
        "TEACHER_TAGLINE", "التميز في اللغة العربية IGCSE — كامبريدج وإيديكسل OL & AL بأقوى الطرق والمتابعة الفردية"
    ),
    "phone": os.environ.get("TEACHER_PHONE", "+201005209526"),
    "whatsapp": os.environ.get("TEACHER_WHATSAPP", "201005209526"),
    "email": os.environ.get("TEACHER_EMAIL", "dr.nagi@elgheity.com"),
    "address": os.environ.get("TEACHER_ADDRESS", "مصر — القاهرة والمنصورة و Online لجميع الدول"),
    "facebook": os.environ.get("TEACHER_FACEBOOK", "https://facebook.com/"),
    "youtube": os.environ.get("TEACHER_YOUTUBE", "https://youtube.com/"),
    "site_name": os.environ.get("SITE_NAME", "منصة الغيطي"),
}

# ---------------------------------------------------------------------------
# إعدادات البريد الإلكتروني (SMTP / Notifications)
# ---------------------------------------------------------------------------
EMAIL_BACKEND = os.environ.get(
    "EMAIL_BACKEND",
    "django.core.mail.backends.smtp.EmailBackend"
    if os.environ.get("EMAIL_HOST_USER")
    else "django.core.mail.backends.console.EmailBackend",
)
EMAIL_HOST = os.environ.get("EMAIL_HOST", "smtp.gmail.com")
EMAIL_PORT = int(os.environ.get("EMAIL_PORT", 587))
EMAIL_USE_TLS = os.environ.get("EMAIL_USE_TLS", "1") == "1"
EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD", "")
DEFAULT_FROM_EMAIL = os.environ.get(
    "DEFAULT_FROM_EMAIL",
    f"{SITE_INFO['site_name']} <{os.environ.get('EMAIL_HOST_USER') or SITE_INFO['email']}>",
)

# ---------------------------------------------------------------------------
# إعدادات بوابة الواتساب الآلية (WhatsApp Gateway API / UltraMsg)
# ---------------------------------------------------------------------------
WHATSAPP_API_ENABLED = os.environ.get("WHATSAPP_API_ENABLED", "0") == "1"
WHATSAPP_API_PROVIDER = os.environ.get("WHATSAPP_API_PROVIDER", "ultramsg")
WHATSAPP_API_URL = os.environ.get("WHATSAPP_API_URL", "")
ULTRAMSG_INSTANCE_ID = os.environ.get("ULTRAMSG_INSTANCE_ID", "")
ULTRAMSG_TOKEN = os.environ.get("ULTRAMSG_TOKEN", "")

# ---------------------------------------------------------------------------
# إعدادات بوت التيليجرام الرسمي (Telegram Bot API)
# ---------------------------------------------------------------------------
TELEGRAM_BOT_TOKEN = os.environ.get(
    "TELEGRAM_BOT_TOKEN", "8761069661:AAHtaCK05vGyQdlvEU_yU-l286nwT9zAWWU"
)
TELEGRAM_BOT_USERNAME = os.environ.get("TELEGRAM_BOT_USERNAME", "ElGheityExamBot")
TELEGRAM_TEACHER_CHAT_ID = os.environ.get("TELEGRAM_TEACHER_CHAT_ID", "")


