/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: ["./templates/**/*.html", "./academy/**/*.py"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Alexandria", "Inter", "sans-serif"],
      },
      colors: {
        brand: {
          50: "#f1f7ff",
          100: "#e0effe",
          200: "#bae0fd",
          300: "#7cc7fc",
          400: "#36aaf8",
          500: "#1B84FF",
          600: "#056EE9",
          700: "#0255b8",
          800: "#064898",
          900: "#0b3d7a",
          950: "#072752",
        },
        navy: {
          50: "#f4f6fa",
          100: "#e5e9f3",
          200: "#cbd5e7",
          300: "#a3b6d4",
          400: "#7491bd",
          500: "#5172a7",
          600: "#3d588a",
          700: "#324770",
          800: "#2c3c5d",
          900: "#071437",
          950: "#040b20",
        },
        surface: "rgb(var(--surface) / <alpha-value>)",
        card: "rgb(var(--card) / <alpha-value>)",
        ink: "rgb(var(--ink) / <alpha-value>)",
        muted: "rgb(var(--muted) / <alpha-value>)",
        line: "rgb(var(--line) / <alpha-value>)",
      },
      boxShadow: {
        soft: "0 8px 24px -6px rgba(7, 20, 55, 0.12)",
        card: "0 3px 6px -1px rgba(7, 20, 55, 0.04), 0 10px 20px -2px rgba(7, 20, 55, 0.06)",
        "card-hover": "0 16px 32px -6px rgba(7, 20, 55, 0.13), 0 6px 16px -2px rgba(27, 132, 255, 0.1)",
        "3d": "0 6px 0 0 #0255b8, 0 10px 20px rgba(7, 20, 55, 0.15)",
        "btn-3d": "0 4px 14px 0 rgba(27, 132, 255, 0.38), inset 0 1px 0 rgba(255, 255, 255, 0.3)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-8px)" },
        },
        "pulse-glow": {
          "0%, 100%": { opacity: "0.35", transform: "scale(1)" },
          "50%": { opacity: "0.7", transform: "scale(1.08)" },
        },
        shimmer: {
          "100%": { transform: "translateX(100%)" },
        },
      },
      animation: {
        float: "float 4s ease-in-out infinite",
        "float-slow": "float 7s ease-in-out infinite",
        "pulse-glow": "pulse-glow 5s ease-in-out infinite",
        shimmer: "shimmer 2.5s infinite",
      },
    },
  },
  plugins: [],
};
